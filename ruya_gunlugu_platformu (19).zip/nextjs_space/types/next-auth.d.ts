
import NextAuth from 'next-auth';

declare module 'next-auth' {
  interface Session {
    user: {
      id: string;
      email: string;
      name?: string | null;
      image?: string | null;
      isPremium?: boolean;
      isAdmin?: boolean;
      dreamCount?: number;
    };
  }

  interface User {
    id: string;
    email: string;
    name?: string | null;
    image?: string | null;
    isPremium?: boolean;
    isAdmin?: boolean;
    dreamCount?: number;
  }
}

declare module 'next-auth/jwt' {
  interface JWT {
    id: string;
    isPremium?: boolean;
    isAdmin?: boolean;
    dreamCount?: number;
  }
}
