
import { prisma } from '@/lib/db';

export async function createNotification({
  userId,
  type,
  title,
  message,
  link,
  fromUserId,
}: {
  userId: string;
  type: 'LIKE' | 'COMMENT' | 'FRIEND_REQUEST' | 'FRIEND_ACCEPTED' | 'MESSAGE' | 'SYSTEM';
  title: string;
  message: string;
  link?: string;
  fromUserId?: string;
}) {
  try {
    await prisma.notification.create({
      data: {
        userId,
        type,
        title,
        message,
        link,
        fromUserId,
      },
    });
  } catch (error) {
    console.error('Error creating notification:', error);
  }
}
