
import { prisma } from '@/lib/db';

// Kötü kelimeleri cache'le
let badWordsCache: { word: string; severity: number }[] | null = null;
let lastCacheUpdate = 0;
const CACHE_DURATION = 5 * 60 * 1000; // 5 dakika

async function getBadWords() {
  const now = Date.now();
  
  // Cache'i güncelle (5 dakikada bir)
  if (!badWordsCache || now - lastCacheUpdate > CACHE_DURATION) {
    badWordsCache = await prisma.badWord.findMany({
      where: { isActive: true },
      select: { word: true, severity: true }
    });
    lastCacheUpdate = now;
  }
  
  return badWordsCache;
}

export interface BadWordCheckResult {
  isClean: boolean;
  foundWords: string[];
  maxSeverity: number;
  filteredText: string;
}

/**
 * Metni kötü kelimeler için kontrol eder
 */
export async function checkBadWords(text: string): Promise<BadWordCheckResult> {
  if (!text) {
    return {
      isClean: true,
      foundWords: [],
      maxSeverity: 0,
      filteredText: text
    };
  }

  const badWords = await getBadWords();
  const foundWords: string[] = [];
  let maxSeverity = 0;
  let filteredText = text;

  // Türkçe karakterleri normalize et
  const normalizedText = text.toLowerCase()
    .replace(/ı/g, 'i')
    .replace(/ğ/g, 'g')
    .replace(/ü/g, 'u')
    .replace(/ş/g, 's')
    .replace(/ö/g, 'o')
    .replace(/ç/g, 'c');

  for (const badWord of badWords) {
    const normalizedBadWord = badWord.word.toLowerCase()
      .replace(/ı/g, 'i')
      .replace(/ğ/g, 'g')
      .replace(/ü/g, 'u')
      .replace(/ş/g, 's')
      .replace(/ö/g, 'o')
      .replace(/ç/g, 'c');

    // Kelime sınırlarını kontrol et (tam kelime eşleşmesi)
    const regex = new RegExp(`\\b${normalizedBadWord}\\b`, 'gi');
    
    if (regex.test(normalizedText)) {
      foundWords.push(badWord.word);
      maxSeverity = Math.max(maxSeverity, badWord.severity);
      
      // Kötü kelimeleri yıldızla
      const stars = '*'.repeat(badWord.word.length);
      const originalRegex = new RegExp(`\\b${badWord.word}\\b`, 'gi');
      filteredText = filteredText.replace(originalRegex, stars);
    }
  }

  return {
    isClean: foundWords.length === 0,
    foundWords,
    maxSeverity,
    filteredText
  };
}

/**
 * Cache'i temizle (yeni kötü kelime eklendiğinde çağrılır)
 */
export function clearBadWordsCache() {
  badWordsCache = null;
  lastCacheUpdate = 0;
}
