
export interface User {
  id: string;
  name?: string;
  email?: string;
  image?: string;
  isPremium?: boolean;
  dreamCount?: number;
}

declare module 'next-auth' {
  interface Session {
    user: User & {
      id: string;
      isPremium?: boolean;
      dreamCount?: number;
    };
  }
  
  interface JWT {
    isPremium?: boolean;
    dreamCount?: number;
  }
}

export interface Dream {
  id: string;
  title: string;
  content: string;
  date: string;
  dreamType: string;
  sleepQuality?: number;
  sleepHours?: number;
  moonPhase?: string;
  audioUrl?: string;
  analysis?: DreamAnalysis;
}

export interface DreamAnalysis {
  id: string;
  symbols: string[];
  emotions: string[];
  themes: string[];
  jungInterpretation?: string;
  freudInterpretation?: string;
  report: string;
  imageUrl?: string;
}

export interface DreamSymbol {
  id: string;
  symbol: string;
  meaning: string;
  category: string;
}

export interface SharedDream {
  id: string;
  dreamId: string;
  anonymousName: string;
  shareDate: string;
  dream: Dream;
  comments: Comment[];
}

export interface Comment {
  id: string;
  content: string;
  createdAt: string;
  user: {
    name: string;
    image?: string;
  };
}
