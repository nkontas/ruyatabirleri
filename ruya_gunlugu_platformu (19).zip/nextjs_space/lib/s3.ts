import { PutObjectCommand, GetObjectCommand, DeleteObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { createS3Client, getBucketConfig } from './aws-config';

export async function uploadFile(buffer: Buffer, fileName: string): Promise<string> {
  const s3Client = createS3Client();
  const { bucketName, folderPrefix } = getBucketConfig();
  
  const key = `${folderPrefix}uploads/${fileName}`;
  
  const command = new PutObjectCommand({
    Bucket: bucketName,
    Key: key,
    Body: buffer,
  });

  await s3Client.send(command);
  return key;
}

export async function downloadFile(key: string): Promise<string> {
  const s3Client = createS3Client();
  const { bucketName } = getBucketConfig();

  const command = new GetObjectCommand({
    Bucket: bucketName,
    Key: key,
  });

  const url = await getSignedUrl(s3Client, command, { expiresIn: 3600 });
  return url;
}

export async function deleteFile(key: string): Promise<void> {
  const s3Client = createS3Client();
  const { bucketName } = getBucketConfig();

  const command = new DeleteObjectCommand({
    Bucket: bucketName,
    Key: key,
  });

  await s3Client.send(command);
}

export async function renameFile(oldKey: string, newKey: string): Promise<void> {
  // S3 doesn't have rename, so we copy and delete
  const s3Client = createS3Client();
  const { bucketName } = getBucketConfig();
  
  // Get the file first
  const getCommand = new GetObjectCommand({
    Bucket: bucketName,
    Key: oldKey,
  });
  
  const { Body } = await s3Client.send(getCommand);
  const buffer = await Body?.transformToByteArray();
  
  // Upload with new key
  await uploadFile(Buffer.from(buffer || []), newKey);
  
  // Delete old file
  await deleteFile(oldKey);
}
