
'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Loader2,
  Brain,
  Sparkles,
  Calendar,
  Moon,
  Clock,
  Edit,
  Trash2,
  Volume2,
  ArrowLeft,
  Eye,
  Share2,
  Users
} from 'lucide-react';
import { motion } from 'framer-motion';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import DashboardHeader from './dashboard-header';
import { format } from 'date-fns';
import { tr } from 'date-fns/locale';
import toast from 'react-hot-toast';
import Image from 'next/image';

interface Dream {
  id: string;
  title: string;
  content: string;
  date: string;
  dreamType: string;
  sleepQuality?: number;
  sleepHours?: number;
  moonPhase?: string;
  audioUrl?: string;
  createdAt: string;
  analysis?: {
    symbols: string[];
    emotions: string[];
    themes: string[];
    characters: string[];
    jungInterpretation: string;
    freudInterpretation: string;
    personalInsights: string;
    overallMeaning: string;
    imageUrl?: string;
  };
}

const dreamTypeLabels: Record<string, string> = {
  NORMAL: 'Normal',
  NIGHTMARE: 'Kabus',
  LUCID: 'Lucid',
  RECURRING: 'Tekrarlayan',
  PROPHETIC: 'Kehanetvari',
  HEALING: 'İyileştirici',
};

const moonPhaseLabels: Record<string, string> = {
  NEW_MOON: 'Yeni Ay',
  WAXING_CRESCENT: 'Hilal',
  FIRST_QUARTER: 'İlk Dördün',
  WAXING_GIBBOUS: 'Şişkin Ay',
  FULL_MOON: 'Dolunay',
  WANING_GIBBOUS: 'Azalan Şişkin Ay',
  LAST_QUARTER: 'Son Dördün',
  WANING_CRESCENT: 'Azalan Hilal',
};

export default function DreamDetailPage({ dreamId }: { dreamId: string }) {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [dream, setDream] = useState<Dream | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isSharing, setIsSharing] = useState(false);

  useEffect(() => {
    fetchDream();
  }, [dreamId]);

  const fetchDream = async () => {
    try {
      const response = await fetch(`/api/dreams/${dreamId}`);
      if (!response.ok) throw new Error('Rüya bulunamadı');
      const data = await response.json();
      setDream(data);
    } catch (error) {
      console.error('Rüya yükleme hatası:', error);
      toast.error('Rüya yüklenemedi');
      router.push('/dashboard');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!confirm('Bu rüyayı silmek istediğinize emin misiniz?')) return;

    setIsDeleting(true);
    try {
      const response = await fetch(`/api/dreams/${dreamId}`, {
        method: 'DELETE',
      });

      if (!response.ok) throw new Error('Silme başarısız');

      toast.success('Rüya silindi');
      router.push('/dashboard');
    } catch (error) {
      console.error('Silme hatası:', error);
      toast.error('Rüya silinemedi');
    } finally {
      setIsDeleting(false);
    }
  };

  const handleShare = async () => {
    if (!confirm('Bu rüyayı topluluğa anonim olarak paylaşmak istediğinize emin misiniz?')) return;

    setIsSharing(true);
    try {
      const response = await fetch(`/api/dreams/${dreamId}/share`, {
        method: 'POST',
      });

      if (!response.ok) throw new Error('Paylaşım başarısız');

      toast.success('Rüya topluluğa paylaşıldı');
      router.push('/dashboard/topluluk');
    } catch (error) {
      console.error('Paylaşım hatası:', error);
      toast.error('Rüya paylaşılamadı');
    } finally {
      setIsSharing(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center">
        <Loader2 className="w-12 h-12 text-white animate-spin" />
      </div>
    );
  }

  if (!dream) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      <DashboardHeader />

      <div className="container mx-auto px-6 py-8 max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="space-y-6"
        >
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              onClick={() => router.back()}
              className="text-purple-200 hover:text-white hover:bg-white/10"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Geri
            </Button>
            <div className="flex space-x-2">
              <Button
                variant="outline"
                onClick={handleShare}
                disabled={isSharing}
                className="text-green-300 border-green-500/30 hover:bg-green-500/10"
              >
                {isSharing ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Users className="w-4 h-4 mr-2" />
                )}
                Topluluğa Paylaş
              </Button>
              <Button
                variant="outline"
                onClick={handleDelete}
                disabled={isDeleting}
                className="text-red-300 border-red-500/30 hover:bg-red-500/10"
              >
                {isDeleting ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Trash2 className="w-4 h-4 mr-2" />
                )}
                Sil
              </Button>
            </div>
          </div>

          <Card className="bg-white/10 backdrop-blur-md border-white/20">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle className="text-2xl text-white mb-3">
                    {dream.title}
                  </CardTitle>
                  <div className="flex flex-wrap gap-2">
                    <Badge
                      variant="outline"
                      className="bg-purple-500/20 text-purple-200 border-purple-500/30"
                    >
                      {dreamTypeLabels[dream.dreamType] || dream.dreamType}
                    </Badge>
                    {dream.moonPhase && (
                      <Badge
                        variant="outline"
                        className="bg-blue-500/20 text-blue-200 border-blue-500/30"
                      >
                        <Moon className="w-3 h-3 mr-1" />
                        {moonPhaseLabels[dream.moonPhase] || dream.moonPhase}
                      </Badge>
                    )}
                    {dream.sleepQuality && (
                      <Badge
                        variant="outline"
                        className="bg-green-500/20 text-green-200 border-green-500/30"
                      >
                        Uyku Kalitesi: {dream.sleepQuality}/10
                      </Badge>
                    )}
                    {dream.sleepHours && (
                      <Badge
                        variant="outline"
                        className="bg-cyan-500/20 text-cyan-200 border-cyan-500/30"
                      >
                        <Clock className="w-3 h-3 mr-1" />
                        {dream.sleepHours} saat
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="flex items-center text-purple-300 text-sm mb-2">
                  <Calendar className="w-4 h-4 mr-2" />
                  {format(new Date(dream.date), 'dd MMMM yyyy, EEEE', { locale: tr })}
                </div>
                <p className="text-purple-100 leading-relaxed whitespace-pre-wrap">
                  {dream.content}
                </p>
              </div>

              {dream.audioUrl && (
                <div className="pt-4 border-t border-white/10">
                  <h4 className="text-white font-semibold mb-2 flex items-center">
                    <Volume2 className="w-4 h-4 mr-2" />
                    Sesli Kayıt
                  </h4>
                  <audio controls className="w-full" src={dream.audioUrl}>
                    Tarayıcınız ses oynatmayı desteklemiyor.
                  </audio>
                </div>
              )}

              {!dream.analysis && (
                <div className="pt-4 border-t border-white/10">
                  <Button
                    asChild
                    className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                  >
                    <Link href={`/dashboard/ruya/${dream.id}/analiz`}>
                      <Brain className="w-4 h-4 mr-2" />
                      AI ile Analiz Et
                    </Link>
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          {dream.analysis && (
            <>
              <Card className="bg-white/10 backdrop-blur-md border-white/20">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Brain className="w-5 h-5 mr-2" />
                    AI Analizi
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {dream.analysis.imageUrl && (
                    <div className="relative aspect-video w-full rounded-lg overflow-hidden bg-muted">
                      <Image
                        src={dream.analysis.imageUrl}
                        alt="Rüya görseli"
                        fill
                        className="object-cover"
                      />
                    </div>
                  )}

                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <h4 className="text-white font-semibold mb-2 flex items-center">
                        <Brain className="w-4 h-4 mr-2" />
                        Semboller
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {dream.analysis.symbols?.map((symbol, i) => (
                          <Badge
                            key={i}
                            variant="secondary"
                            className="bg-purple-500/20 text-purple-200 border-purple-500/30"
                          >
                            {symbol}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h4 className="text-white font-semibold mb-2">Duygular</h4>
                      <div className="flex flex-wrap gap-2">
                        {dream.analysis.emotions?.map((emotion, i) => (
                          <Badge
                            key={i}
                            variant="secondary"
                            className="bg-pink-500/20 text-pink-200 border-pink-500/30"
                          >
                            {emotion}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>

                  {dream.analysis.jungInterpretation && (
                    <div>
                      <h4 className="text-white font-semibold mb-2">Jung Yorumu</h4>
                      <p className="text-purple-200 leading-relaxed">
                        {dream.analysis.jungInterpretation}
                      </p>
                    </div>
                  )}

                  {dream.analysis.freudInterpretation && (
                    <div>
                      <h4 className="text-white font-semibold mb-2">Freud Yorumu</h4>
                      <p className="text-purple-200 leading-relaxed">
                        {dream.analysis.freudInterpretation}
                      </p>
                    </div>
                  )}

                  {dream.analysis.personalInsights && (
                    <div>
                      <h4 className="text-white font-semibold mb-2">Kişisel Öneriler</h4>
                      <p className="text-purple-200 leading-relaxed">
                        {dream.analysis.personalInsights}
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>

              <div className="flex justify-center">
                <Button
                  asChild
                  variant="outline"
                  className="border-purple-500/30 text-purple-200 hover:bg-purple-500/10"
                >
                  <Link href={`/dashboard/analiz?dreamId=${dream.id}`}>
                    <Eye className="w-4 h-4 md:mr-2" />
                    <span className="hidden md:inline">Tam Analizi Görüntüle</span>
                  </Link>
                </Button>
              </div>
            </>
          )}
        </motion.div>
      </div>
    </div>
  );
}
