
'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { Card, CardContent } from '@/components/ui/card';
import { motion } from 'framer-motion';
import { 
  BookOpen, 
  Brain, 
  Calendar, 
  Sparkles,
  TrendingUp,
  Moon,
  Zap,
  Target
} from 'lucide-react';

interface StatsData {
  totalDreams: number;
  thisMonthDreams: number;
  analyzedDreams: number;
  generatedImages: number;
  averageSleepQuality: number;
  dreamStreak: number;
  totalSymbols: number;
  completionRate: number;
}

export default function DashboardStats() {
  const { data: session } = useSession() || {};
  const [stats, setStats] = useState<StatsData>({
    totalDreams: 0,
    thisMonthDreams: 0,
    analyzedDreams: 0,
    generatedImages: 0,
    averageSleepQuality: 0,
    dreamStreak: 0,
    totalSymbols: 0,
    completionRate: 0,
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      if (!session?.user?.id) return;

      try {
        const response = await fetch('/api/stats');
        if (response.ok) {
          const data = await response.json();
          setStats(data);
        }
      } catch (error) {
        console.error('Stats fetch error:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchStats();
  }, [session?.user?.id]);

  const statCards = [
    {
      title: 'Toplam Rüya',
      value: stats.totalDreams,
      icon: BookOpen,
      gradient: 'from-purple-500 to-blue-500',
      change: '+12%',
      period: 'Bu ay',
    },
    {
      title: 'Bu Ay',
      value: stats.thisMonthDreams,
      icon: Calendar,
      gradient: 'from-blue-500 to-cyan-500',
      change: `${stats.thisMonthDreams}/10`,
      period: 'Limit',
    },
    {
      title: 'AI Analizi',
      value: stats.analyzedDreams,
      icon: Brain,
      gradient: 'from-cyan-500 to-teal-500',
      change: '+8%',
      period: 'Bu hafta',
    },
    {
      title: 'AI Görseller',
      value: stats.generatedImages,
      icon: Sparkles,
      gradient: 'from-teal-500 to-emerald-500',
      change: '+15%',
      period: 'Bu ay',
    },
    {
      title: 'Uyku Kalitesi',
      value: stats.averageSleepQuality,
      icon: Moon,
      gradient: 'from-emerald-500 to-green-500',
      suffix: '/10',
      change: '+0.5',
      period: 'Ortalama',
    },
    {
      title: 'Rüya Serisi',
      value: stats.dreamStreak,
      icon: Target,
      gradient: 'from-orange-500 to-red-500',
      suffix: ' gün',
      change: '🔥',
      period: 'Aktif',
    },
    {
      title: 'Sembol Keşfi',
      value: stats.totalSymbols,
      icon: Zap,
      gradient: 'from-violet-500 to-purple-500',
      change: '+3',
      period: 'Bu hafta',
    },
    {
      title: 'Tamamlama',
      value: stats.completionRate,
      icon: TrendingUp,
      gradient: 'from-pink-500 to-rose-500',
      suffix: '%',
      change: '+5%',
      period: 'Bu ay',
    },
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.6, delay: 0.1 }}
      className="space-y-4"
    >
      <h2 className="text-2xl font-bold text-white">İstatistiklerim</h2>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {statCards.map((stat, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.15 + index * 0.1 }}
            whileHover={{ scale: 1.05, y: -5 }}
          >
            <Card className="bg-white/10 backdrop-blur-md border-white/20 hover:bg-white/15 transition-all duration-300 group">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className={`p-2 rounded-lg bg-gradient-to-br ${stat.gradient} shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                    <stat.icon className="w-4 h-4 text-white" />
                  </div>
                  {stat.change && (
                    <span className="text-xs text-green-300 font-medium">
                      {stat.change}
                    </span>
                  )}
                </div>
                
                <div className="space-y-1">
                  <motion.div
                    className="text-2xl font-bold text-white"
                    initial={{ scale: 0.5 }}
                    animate={{ scale: 1 }}
                    transition={{ duration: 0.5, delay: 0.3 + index * 0.1 }}
                  >
                    {isLoading ? (
                      <div className="h-6 bg-white/20 rounded animate-pulse" />
                    ) : (
                      `${stat.value}${stat.suffix || ''}`
                    )}
                  </motion.div>
                  
                  <p className="text-xs text-purple-200 font-medium">
                    {stat.title}
                  </p>
                  
                  {stat.period && (
                    <p className="text-xs text-purple-300/80">
                      {stat.period}
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Progress Bars */}
      {!session?.user?.isPremium && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
        >
          <Card className="bg-white/5 backdrop-blur-md border-white/10">
            <CardContent className="p-4">
              <div className="space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-purple-200">Aylık Rüya Limiti</span>
                  <span className="text-white">{stats.thisMonthDreams}/10</span>
                </div>
                <div className="w-full bg-white/10 rounded-full h-2">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${(stats.thisMonthDreams / 10) * 100}%` }}
                    transition={{ duration: 1, delay: 0.6 }}
                    className="bg-gradient-to-r from-purple-500 to-blue-500 h-2 rounded-full"
                  />
                </div>
                {stats.thisMonthDreams >= 8 && (
                  <p className="text-xs text-orange-300">
                    Limitinize yaklaştınız! Premium'a geçerek sınırsız erişim kazanın.
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}
    </motion.div>
  );
}
