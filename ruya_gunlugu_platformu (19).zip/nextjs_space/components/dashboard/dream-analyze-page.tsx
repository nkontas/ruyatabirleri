
'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, Brain, Sparkles, ArrowLeft, Wand2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { useRouter } from 'next/navigation';
import DashboardHeader from './dashboard-header';
import toast from 'react-hot-toast';

interface Dream {
  id: string;
  title: string;
  content: string;
  analysis?: any;
}

export default function DreamAnalyzePage({ dreamId }: { dreamId: string }) {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [analyzing, setAnalyzing] = useState(false);
  const [dream, setDream] = useState<Dream | null>(null);

  useEffect(() => {
    fetchDream();
  }, [dreamId]);

  const fetchDream = async () => {
    try {
      const response = await fetch(`/api/dreams/${dreamId}`);
      if (!response.ok) throw new Error('Rüya bulunamadı');
      const data = await response.json();
      setDream(data);
      
      // Eğer analiz zaten varsa direkt analiz sayfasına yönlendir
      if (data.analysis) {
        router.push(`/dashboard/analiz?dreamId=${dreamId}`);
      }
    } catch (error) {
      console.error('Rüya yükleme hatası:', error);
      toast.error('Rüya yüklenemedi');
      router.push('/dashboard');
    } finally {
      setLoading(false);
    }
  };

  const handleAnalyze = async () => {
    if (!dream) return;

    setAnalyzing(true);
    try {
      const response = await fetch('/api/dreams/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content: dream.content,
          dreamId: dream.id,
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Analiz başarısız');
      }

      const data = await response.json();
      toast.success('AI analizi tamamlandı! 🔮');
      router.push(`/dashboard/analiz?dreamId=${dream.id}`);
    } catch (error: any) {
      console.error('Analiz hatası:', error);
      toast.error(error.message || 'Analiz yapılamadı');
    } finally {
      setAnalyzing(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center">
        <Loader2 className="w-12 h-12 text-white animate-spin" />
      </div>
    );
  }

  if (!dream) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      <DashboardHeader />

      <div className="container mx-auto px-6 py-8 max-w-4xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="space-y-6"
        >
          <Button
            variant="ghost"
            onClick={() => router.back()}
            className="text-purple-200 hover:text-white hover:bg-white/10"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Geri
          </Button>

          <Card className="bg-white/10 backdrop-blur-md border-white/20">
            <CardHeader>
              <CardTitle className="text-white text-2xl">
                {dream.title}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-purple-200 leading-relaxed whitespace-pre-wrap">
                {dream.content}
              </p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-500/20 to-blue-500/20 backdrop-blur-md border-white/20">
            <CardContent className="p-8 text-center">
              <motion.div
                animate={{
                  scale: [1, 1.1, 1],
                  rotate: [0, 5, -5, 0],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  repeatType: 'reverse',
                }}
                className="mx-auto w-20 h-20 mb-6 bg-gradient-to-br from-purple-400 to-blue-400 rounded-full flex items-center justify-center"
              >
                <Wand2 className="w-10 h-10 text-white" />
              </motion.div>

              <h2 className="text-2xl font-bold text-white mb-3">
                AI ile Rüya Analizi
              </h2>
              <p className="text-purple-200 mb-6 max-w-md mx-auto">
                Yapay zeka rüyanızı derinlemesine analiz edecek, sembollerini çözecek ve
                Jung, Freud ve İslami perspektiflerden yorumlayacak. Ayrıca rüyanızı temsil eden
                benzersiz bir görsel oluşturulacak.
              </p>

              <div className="space-y-3 mb-8 text-left max-w-md mx-auto">
                <div className="flex items-start space-x-3 text-purple-200">
                  <Sparkles className="w-5 h-5 mt-0.5 flex-shrink-0" />
                  <span>Semboller ve anlamları</span>
                </div>
                <div className="flex items-start space-x-3 text-purple-200">
                  <Brain className="w-5 h-5 mt-0.5 flex-shrink-0" />
                  <span>Jung, Freud ve İslami yorumlar</span>
                </div>
                <div className="flex items-start space-x-3 text-purple-200">
                  <Sparkles className="w-5 h-5 mt-0.5 flex-shrink-0" />
                  <span>AI tarafından oluşturulan rüya görseli</span>
                </div>
                <div className="flex items-start space-x-3 text-purple-200">
                  <Brain className="w-5 h-5 mt-0.5 flex-shrink-0" />
                  <span>Kişisel öneriler ve içgörüler</span>
                </div>
              </div>

              <Button
                onClick={handleAnalyze}
                disabled={analyzing}
                className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white px-8 py-6 text-lg"
              >
                {analyzing ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    Analiz Ediliyor... (Bu 30-60 saniye sürebilir)
                  </>
                ) : (
                  <>
                    <Wand2 className="w-5 h-5 mr-2" />
                    Analizi Başlat
                  </>
                )}
              </Button>

              {analyzing && (
                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-purple-300 text-sm mt-4"
                >
                  🔮 Yapay zeka rüyanızı analiz ediyor ve görsel oluşturuyor...
                </motion.p>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
