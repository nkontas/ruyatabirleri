'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, Moon, BarChart3, Heart, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';
import DashboardHeader from './dashboard-header';

export default function StatsPage() {
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState<any>(null);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const response = await fetch('/api/stats');
      const data = await response.json();
      setStats(data);
    } catch (error) {
      console.error('Error fetching stats:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center">
        <Loader2 className="w-12 h-12 text-white animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      <DashboardHeader />

      <div className="container mx-auto px-6 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">İstatistikler 📊</h1>
          <p className="text-purple-200 text-lg mb-8">
            Rüya patternleriniz ve trendleriniz
          </p>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card className="bg-white/10 backdrop-blur-md border-white/20">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-purple-200">Toplam Rüya</p>
                    <p className="text-3xl font-bold text-white">{stats?.totalDreams || 0}</p>
                  </div>
                  <Moon className="w-10 h-10 text-purple-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/10 backdrop-blur-md border-white/20">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-purple-200">Bu Ay</p>
                    <p className="text-3xl font-bold text-white">{stats?.thisMonth || 0}</p>
                  </div>
                  <BarChart3 className="w-10 h-10 text-blue-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/10 backdrop-blur-md border-white/20">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-purple-200">Ortalama Kalite</p>
                    <p className="text-3xl font-bold text-white">{stats?.avgQuality || 0}/10</p>
                  </div>
                  <Heart className="w-10 h-10 text-pink-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/10 backdrop-blur-md border-white/20">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-purple-200">En Yaygın</p>
                    <p className="text-lg font-bold text-white">{stats?.mostCommon || '-'}</p>
                  </div>
                  <TrendingUp className="w-10 h-10 text-green-400" />
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <Card className="bg-white/10 backdrop-blur-md border-white/20">
              <CardHeader>
                <CardTitle className="text-white">En Sık Semboller</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {stats?.topSymbols?.map((symbol: any, i: number) => (
                    <div key={i} className="flex justify-between items-center">
                      <span className="text-purple-200">{symbol.name}</span>
                      <span className="text-white font-semibold">{symbol.count}</span>
                    </div>
                  )) || <p className="text-purple-200">Veri yok</p>}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/10 backdrop-blur-md border-white/20">
              <CardHeader>
                <CardTitle className="text-white">En Sık Duygular</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {stats?.topEmotions?.map((emotion: any, i: number) => (
                    <div key={i} className="flex justify-between items-center">
                      <span className="text-purple-200">{emotion.name}</span>
                      <span className="text-white font-semibold">{emotion.count}</span>
                    </div>
                  )) || <p className="text-purple-200">Veri yok</p>}
                </div>
              </CardContent>
            </Card>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
