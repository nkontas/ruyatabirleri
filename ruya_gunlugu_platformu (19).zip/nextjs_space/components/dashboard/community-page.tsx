
'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { 
  Users, 
  MessageCircle, 
  Heart, 
  Share2,
  Clock,
  Filter,
  TrendingUp,
  Eye,
  Coffee,
  Loader2,
  Send
} from 'lucide-react';
import { motion } from 'framer-motion';
import DashboardHeader from './dashboard-header';
import { toast } from 'react-hot-toast';
import { formatDistanceToNow } from 'date-fns';
import { tr } from 'date-fns/locale';
import { UserAvatar } from '@/components/user-avatar';

interface CommunityDream {
  id: string;
  dreamId: string;
  title: string;
  excerpt: string;
  content: string;
  dreamType: string;
  anonymousName: string;
  user: {
    id: string;
    username: string | null;
    name: string | null;
    image: string | null;
  };
  shareDate: string;
  likeCount: number;
  commentCount: number;
  isLiked: boolean;
}

interface Comment {
  id: string;
  content: string;
  createdAt: string;
  user: {
    id: string;
    name: string | null;
    username: string | null;
    image: string | null;
  };
}

export default function CommunityPage() {
  const { data: session } = useSession() || {};
  const [filter, setFilter] = useState('recent');
  const [dreams, setDreams] = useState<CommunityDream[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedDream, setSelectedDream] = useState<CommunityDream | null>(null);
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [commentLoading, setCommentLoading] = useState(false);
  const [isCommentsOpen, setIsCommentsOpen] = useState(false);

  useEffect(() => {
    loadDreams();
  }, [filter]);

  const loadDreams = async () => {
    try {
      setLoading(true);
      const response = await fetch(`/api/community/dreams?filter=${filter}`);
      if (!response.ok) throw new Error('Rüyalar yüklenemedi');
      const data = await response.json();
      setDreams(data.dreams);
    } catch (error) {
      toast.error('Rüyalar yüklenirken hata oluştu');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleLike = async (dreamId: string) => {
    try {
      const response = await fetch(`/api/community/dreams/${dreamId}/like`, {
        method: 'POST',
      });

      if (!response.ok) throw new Error('Beğeni işlemi başarısız');

      const data = await response.json();
      
      setDreams((prev) =>
        prev.map((dream) =>
          dream.id === dreamId
            ? {
                ...dream,
                isLiked: data.isLiked,
                likeCount: data.isLiked
                  ? dream.likeCount + 1
                  : dream.likeCount - 1,
              }
            : dream
        )
      );
    } catch (error) {
      toast.error('Beğeni işlemi başarısız');
      console.error(error);
    }
  };

  const handleOpenComments = async (dream: CommunityDream) => {
    setSelectedDream(dream);
    setIsCommentsOpen(true);
    await loadComments(dream.id);
  };

  const loadComments = async (dreamId: string) => {
    try {
      const response = await fetch(`/api/community/dreams/${dreamId}/comments`);
      if (!response.ok) throw new Error('Yorumlar yüklenemedi');
      const data = await response.json();
      setComments(data);
    } catch (error) {
      toast.error('Yorumlar yüklenirken hata oluştu');
      console.error(error);
    }
  };

  const handleAddComment = async () => {
    if (!selectedDream || !newComment.trim()) return;

    try {
      setCommentLoading(true);
      const response = await fetch(
        `/api/community/dreams/${selectedDream.id}/comments`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ content: newComment }),
        }
      );

      if (!response.ok) throw new Error('Yorum eklenemedi');

      const data = await response.json();
      setComments([data, ...comments]);
      setNewComment('');
      toast.success('Yorumunuz eklendi');

      // Update comment count
      setDreams((prev) =>
        prev.map((dream) =>
          dream.id === selectedDream.id
            ? { ...dream, commentCount: dream.commentCount + 1 }
            : dream
        )
      );
    } catch (error) {
      toast.error('Yorum eklenirken hata oluştu');
      console.error(error);
    } finally {
      setCommentLoading(false);
    }
  };

  const handleShare = (dream: CommunityDream) => {
    const shareUrl = `${window.location.origin}/dashboard/topluluk/${dream.id}`;
    
    if (navigator.share) {
      navigator.share({
        title: dream.title,
        text: dream.excerpt,
        url: shareUrl,
      }).catch(() => {
        // Fallback to clipboard
        navigator.clipboard.writeText(shareUrl);
        toast.success('Link kopyalandı');
      });
    } else {
      navigator.clipboard.writeText(shareUrl);
      toast.success('Link kopyalandı');
    }
  };

  const dreamTypeColors: Record<string, string> = {
    NORMAL: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
    NIGHTMARE: 'bg-red-500/20 text-red-300 border-red-500/30',
    LUCID: 'bg-purple-500/20 text-purple-300 border-purple-500/30',
    RECURRING: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30',
    PROPHETIC: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30',
    HEALING: 'bg-green-500/20 text-green-300 border-green-500/30',
  };

  const dreamTypeLabels: Record<string, string> = {
    NORMAL: 'Normal',
    NIGHTMARE: 'Kabus',
    LUCID: 'Lucid',
    RECURRING: 'Tekrarlayan',
    PROPHETIC: 'Kehanetvari',
    HEALING: 'İyileştirici',
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      {/* Animated background */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div
          animate={{ 
            scale: [1, 1.2, 1],
            rotate: [0, 180, 360],
          }}
          transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
          className="absolute top-10 left-10 w-32 h-32 bg-purple-500/5 rounded-full blur-3xl"
        />
        <motion.div
          animate={{ 
            scale: [1.2, 1, 1.2],
            rotate: [360, 180, 0],
          }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          className="absolute bottom-10 right-10 w-40 h-40 bg-blue-500/5 rounded-full blur-3xl"
        />
      </div>

      <div className="relative z-10">
        <DashboardHeader />

        <div className="container mx-auto px-6 py-8">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-8"
          >
            <div className="flex items-center space-x-4 mb-4">
              <div className="p-3 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl">
                <Users className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-white">Rüya Topluluğu</h1>
                <p className="text-purple-200">
                  Diğer kullanıcıların anonim rüya paylaşımlarını keşfedin
                </p>
              </div>
            </div>
          </motion.div>

          {/* Stats Cards */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-8"
          >
            <Card className="bg-white/10 backdrop-blur-md border-white/20">
              <CardContent className="p-6">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-blue-500/20 rounded-lg">
                    <Users className="w-5 h-5 text-blue-300" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-white">1,234</p>
                    <p className="text-sm text-purple-200">Aktif Üye</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/10 backdrop-blur-md border-white/20">
              <CardContent className="p-6">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-purple-500/20 rounded-lg">
                    <MessageCircle className="w-5 h-5 text-purple-300" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-white">567</p>
                    <p className="text-sm text-purple-200">Paylaşılan Rüya</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/10 backdrop-blur-md border-white/20">
              <CardContent className="p-6">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-pink-500/20 rounded-lg">
                    <Heart className="w-5 h-5 text-pink-300" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-white">2,890</p>
                    <p className="text-sm text-purple-200">Beğeni</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/10 backdrop-blur-md border-white/20">
              <CardContent className="p-6">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-green-500/20 rounded-lg">
                    <TrendingUp className="w-5 h-5 text-green-300" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-white">89</p>
                    <p className="text-sm text-purple-200">Bu Hafta</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Filter Bar */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="flex items-center justify-between mb-8"
          >
            <div className="flex items-center space-x-4">
              <Button
                variant={filter === 'recent' ? 'default' : 'ghost'}
                onClick={() => setFilter('recent')}
                className="text-white"
              >
                <Clock className="w-4 h-4 mr-2" />
                En Son
              </Button>
              <Button
                variant={filter === 'popular' ? 'default' : 'ghost'}
                onClick={() => setFilter('popular')}
                className="text-white"
              >
                <TrendingUp className="w-4 h-4 mr-2" />
                Popüler
              </Button>
              <Button
                variant={filter === 'commented' ? 'default' : 'ghost'}
                onClick={() => setFilter('commented')}
                className="text-white"
              >
                <MessageCircle className="w-4 h-4 mr-2" />
                Çok Yorumlanan
              </Button>
            </div>

            <Button variant="outline" className="text-purple-200 border-purple-400">
              <Filter className="w-4 h-4 mr-2" />
              Filtrele
            </Button>
          </motion.div>

          {/* Community Posts */}
          <div className="space-y-6">
            {loading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="w-8 h-8 animate-spin text-purple-400" />
              </div>
            ) : dreams.length === 0 ? (
              <Card className="bg-gradient-to-r from-purple-600/20 to-blue-600/20 border-purple-400/30 backdrop-blur-md">
                <CardContent className="p-8 text-center">
                  <Coffee className="w-12 h-12 text-purple-300 mx-auto mb-4" />
                  <h3 className="text-2xl font-bold text-white mb-2">
                    Henüz Paylaşım Yok
                  </h3>
                  <p className="text-purple-200 max-w-2xl mx-auto">
                    Toplulukta henüz paylaşılan rüya bulunmuyor. İlk paylaşımı siz yapabilirsiniz!
                  </p>
                </CardContent>
              </Card>
            ) : (
              dreams.map((dream, index) => (
                <motion.div
                  key={dream.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.3 + index * 0.1 }}
                  whileHover={{ scale: 1.01 }}
                >
                  <Card className="bg-white/10 backdrop-blur-md border-white/20 hover:bg-white/15 transition-all duration-300">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex items-start space-x-3 flex-1">
                          <UserAvatar 
                            image={dream.user.image}
                            name={dream.user.name || dream.user.username || dream.anonymousName}
                            className="w-10 h-10 border-2 border-purple-400/30"
                          />
                          <div className="flex-1">
                            <div className="flex items-center space-x-3 mb-2">
                              <h3 className="text-xl font-semibold text-white">
                                {dream.title}
                              </h3>
                              <Badge 
                                variant="outline"
                                className={`text-xs ${dreamTypeColors[dream.dreamType] || 'bg-gray-500/20 text-gray-300'}`}
                              >
                                {dreamTypeLabels[dream.dreamType] || dream.dreamType}
                              </Badge>
                            </div>
                            <div className="flex items-center space-x-2 text-sm text-purple-300">
                              <Link 
                                href={`/dashboard/kullanici/${dream.user.id}`}
                                className="hover:underline hover:text-purple-200 transition-colors font-medium"
                              >
                                {dream.user.username || dream.user.name || dream.anonymousName}
                              </Link>
                              <span>•</span>
                              <span>
                                {formatDistanceToNow(new Date(dream.shareDate), {
                                  addSuffix: true,
                                  locale: tr,
                                })}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardHeader>

                    <CardContent className="space-y-4">
                      <p className="text-purple-200 leading-relaxed">
                        {dream.excerpt}
                      </p>

                      {/* Actions */}
                      <div className="flex items-center justify-between pt-4 border-t border-white/10">
                        <div className="flex items-center space-x-6">
                          <button
                            onClick={() => handleLike(dream.id)}
                            className={`flex items-center space-x-2 transition-colors ${
                              dream.isLiked
                                ? 'text-pink-400 hover:text-pink-300'
                                : 'text-purple-200 hover:text-pink-300'
                            }`}
                          >
                            <Heart
                              className={`w-4 h-4 ${dream.isLiked ? 'fill-current' : ''}`}
                            />
                            <span className="text-sm">{dream.likeCount}</span>
                          </button>
                          
                          <button
                            onClick={() => handleOpenComments(dream)}
                            className="flex items-center space-x-2 text-purple-200 hover:text-blue-300 transition-colors"
                          >
                            <MessageCircle className="w-4 h-4" />
                            <span className="text-sm">{dream.commentCount} Yorum</span>
                          </button>
                          
                          <button
                            onClick={() => handleShare(dream)}
                            className="flex items-center space-x-2 text-purple-200 hover:text-green-300 transition-colors"
                          >
                            <Share2 className="w-4 h-4" />
                            <span className="text-sm">Paylaş</span>
                          </button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))
            )}
          </div>

          {/* Comments Dialog */}
          <Dialog open={isCommentsOpen} onOpenChange={setIsCommentsOpen}>
            <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 border-purple-400/30">
              <DialogHeader>
                <DialogTitle className="text-white">
                  {selectedDream?.title}
                </DialogTitle>
                <DialogDescription className="text-purple-200">
                  Paylaşan:{" "}
                  <Link
                    href={`/dashboard/kullanici/${selectedDream?.user.id}`}
                    className="hover:underline hover:text-purple-100 transition-colors"
                  >
                    {selectedDream?.user.username || selectedDream?.user.name || selectedDream?.anonymousName}
                  </Link>
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-4">
                {/* Add Comment */}
                <div className="space-y-2">
                  <Textarea
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder="Yorumunuzu yazın..."
                    className="bg-white/10 border-white/20 text-white placeholder:text-purple-300"
                    rows={3}
                  />
                  <Button
                    onClick={handleAddComment}
                    disabled={!newComment.trim() || commentLoading}
                    className="w-full bg-gradient-to-r from-purple-600 to-blue-600"
                  >
                    {commentLoading ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Gönderiliyor...
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4 mr-2" />
                        Yorum Yap
                      </>
                    )}
                  </Button>
                </div>

                {/* Comments List */}
                <div className="space-y-3">
                  <h4 className="text-white font-semibold">
                    Yorumlar ({comments.length})
                  </h4>
                  {comments.length === 0 ? (
                    <p className="text-purple-300 text-center py-4">
                      Henüz yorum yapılmamış. İlk yorumu siz yapın!
                    </p>
                  ) : (
                    comments.map((comment) => (
                      <Card
                        key={comment.id}
                        className="bg-white/5 border-white/10"
                      >
                        <CardContent className="p-4">
                          <div className="flex items-start space-x-3">
                            <UserAvatar
                              image={comment.user.image}
                              name={comment.user.name || comment.user.username}
                              className="w-8 h-8 border border-purple-400/30"
                            />
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-2">
                                <Link
                                  href={`/dashboard/kullanici/${comment.user.id}`}
                                  className="text-white font-medium hover:text-purple-300 hover:underline transition-colors"
                                >
                                  {comment.user.username || comment.user.name || 'Anonim'}
                                </Link>
                                <span className="text-xs text-purple-300">
                                  {formatDistanceToNow(
                                    new Date(comment.createdAt),
                                    { addSuffix: true, locale: tr }
                                  )}
                                </span>
                              </div>
                              <p className="text-purple-200 text-sm">
                                {comment.content}
                              </p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))
                  )}
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>
    </div>
  );
}
