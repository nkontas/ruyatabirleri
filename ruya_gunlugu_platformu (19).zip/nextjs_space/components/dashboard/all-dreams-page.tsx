
'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Loader2,
  Search,
  Brain,
  Sparkles,
  Calendar,
  Eye,
  Filter,
  Plus,
} from 'lucide-react';
import { motion } from 'framer-motion';
import Link from 'next/link';
import DashboardHeader from './dashboard-header';
import { formatDistanceToNow } from 'date-fns';
import { tr } from 'date-fns/locale';

interface Dream {
  id: string;
  title: string;
  content: string;
  date: string;
  dreamType: string;
  sleepQuality?: number;
  createdAt: string;
  analysis?: {
    emotions: string[];
    symbols: string[];
    imageUrl?: string;
  };
}

const dreamTypeLabels: Record<string, string> = {
  ALL: 'Tüm Rüyalar',
  NORMAL: 'Normal',
  NIGHTMARE: 'Kabus',
  LUCID: 'Lucid',
  RECURRING: 'Tekrarlayan',
  PROPHETIC: 'Kehanetvari',
  HEALING: 'İyileştirici',
};

const dreamTypeColors: Record<string, string> = {
  NORMAL: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
  NIGHTMARE: 'bg-red-500/20 text-red-300 border-red-500/30',
  LUCID: 'bg-purple-500/20 text-purple-300 border-purple-500/30',
  RECURRING: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30',
  PROPHETIC: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30',
  HEALING: 'bg-green-500/20 text-green-300 border-green-500/30',
};

export default function AllDreamsPage() {
  const [dreams, setDreams] = useState<Dream[]>([]);
  const [filteredDreams, setFilteredDreams] = useState<Dream[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState('ALL');

  useEffect(() => {
    fetchDreams();
  }, []);

  useEffect(() => {
    filterDreams();
  }, [dreams, searchQuery, filterType]);

  const fetchDreams = async () => {
    try {
      const response = await fetch('/api/dreams?limit=100');
      if (response.ok) {
        const data = await response.json();
        setDreams(data);
      }
    } catch (error) {
      console.error('Rüyalar yüklenemedi:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const filterDreams = () => {
    let filtered = [...dreams];

    // Filter by type
    if (filterType !== 'ALL') {
      filtered = filtered.filter((dream) => dream.dreamType === filterType);
    }

    // Filter by search query
    if (searchQuery) {
      filtered = filtered.filter(
        (dream) =>
          dream.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          dream.content.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    setFilteredDreams(filtered);
  };

  const truncateContent = (content: string, maxLength: number = 150) => {
    if (content.length <= maxLength) return content;
    return content.substring(0, maxLength) + '...';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      <DashboardHeader />

      <div className="container mx-auto px-6 py-8 max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="space-y-6"
        >
          <div className="flex items-center justify-between">
            <h1 className="text-3xl md:text-4xl font-bold text-white">
              Rüya Günlüğüm 📖
            </h1>
            <Button
              asChild
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
            >
              <Link href="/dashboard/ruya-ekle">
                <Plus className="w-4 h-4 mr-2" />
                Yeni Rüya
              </Link>
            </Button>
          </div>

          {/* Filters */}
          <Card className="bg-white/10 backdrop-blur-md border-white/20">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-purple-300 w-5 h-5" />
                  <Input
                    placeholder="Rüya ara..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 bg-white/5 border-white/20 text-white placeholder:text-purple-300"
                  />
                </div>
                <div className="w-full md:w-64">
                  <Select value={filterType} onValueChange={setFilterType}>
                    <SelectTrigger className="bg-white/5 border-white/20 text-white">
                      <Filter className="w-4 h-4 mr-2" />
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ALL">Tüm Rüyalar</SelectItem>
                      <SelectItem value="NORMAL">Normal</SelectItem>
                      <SelectItem value="NIGHTMARE">Kabus</SelectItem>
                      <SelectItem value="LUCID">Lucid</SelectItem>
                      <SelectItem value="RECURRING">Tekrarlayan</SelectItem>
                      <SelectItem value="PROPHETIC">Kehanetvari</SelectItem>
                      <SelectItem value="HEALING">İyileştirici</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Results count */}
          <div className="text-purple-200 text-sm">
            {filteredDreams.length} rüya bulundu
          </div>

          {/* Dreams List */}
          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-12 h-12 text-white animate-spin" />
            </div>
          ) : filteredDreams.length === 0 ? (
            <Card className="bg-white/10 backdrop-blur-md border-white/20">
              <CardContent className="p-12 text-center">
                <p className="text-purple-200 text-lg">
                  {searchQuery || filterType !== 'ALL'
                    ? 'Arama kriterlerine uygun rüya bulunamadı'
                    : 'Henüz rüya kaydınız yok'}
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4">
              {filteredDreams.map((dream, index) => (
                <motion.div
                  key={dream.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.05 }}
                >
                  <Card className="bg-white/10 backdrop-blur-md border-white/20 hover:bg-white/15 transition-all duration-300 group">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <h3 className="font-semibold text-white group-hover:text-purple-200 transition-colors text-lg">
                              {dream.title}
                            </h3>
                            <Badge
                              variant="outline"
                              className={`text-xs border ${
                                dreamTypeColors[dream.dreamType] ||
                                'bg-gray-500/20 text-gray-300 border-gray-500/30'
                              }`}
                            >
                              {dreamTypeLabels[dream.dreamType] || dream.dreamType}
                            </Badge>
                          </div>

                          <p className="text-purple-200 text-sm leading-relaxed mb-3">
                            {truncateContent(dream.content)}
                          </p>

                          <div className="flex items-center space-x-4 text-xs text-purple-300">
                            <div className="flex items-center space-x-1">
                              <Calendar className="w-3 h-3" />
                              <span>
                                {formatDistanceToNow(new Date(dream.createdAt), {
                                  addSuffix: true,
                                  locale: tr,
                                })}
                              </span>
                            </div>

                            {dream.analysis && (
                              <div className="flex items-center space-x-2">
                                <div className="flex items-center space-x-1">
                                  <Brain className="w-3 h-3 text-cyan-400" />
                                  <span className="text-cyan-300">Analiz edildi</span>
                                </div>
                                {dream.analysis.imageUrl && (
                                  <div className="flex items-center space-x-1">
                                    <Sparkles className="w-3 h-3 text-yellow-400" />
                                    <span className="text-yellow-300">Görsel</span>
                                  </div>
                                )}
                              </div>
                            )}
                          </div>
                        </div>

                        <div className="flex flex-col space-y-2 ml-4">
                          <Button
                            variant="ghost"
                            size="sm"
                            asChild
                            className="text-purple-200 hover:text-white hover:bg-white/10"
                          >
                            <Link href={`/dashboard/ruya/${dream.id}`}>
                              <Eye className="w-4 h-4 md:mr-1" />
                              <span className="hidden md:inline">Görüntüle</span>
                            </Link>
                          </Button>

                          {!dream.analysis && (
                            <Button
                              variant="ghost"
                              size="sm"
                              asChild
                              className="text-cyan-300 hover:text-cyan-200 hover:bg-cyan-500/10"
                            >
                              <Link href={`/dashboard/ruya/${dream.id}/analiz`}>
                                <Brain className="w-4 h-4 mr-1" />
                                Analiz Et
                              </Link>
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}
