
'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { signOut } from 'next-auth/react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { UserAvatar } from '@/components/user-avatar';
import { 
  Moon, 
  User, 
  Settings, 
  Crown, 
  LogOut, 
  Menu,
  Search,
  Bell,
  Shield,
  Users,
  MessageCircle
} from 'lucide-react';
import { motion } from 'framer-motion';
import Link from 'next/link';

export default function DashboardHeader() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [unreadMessageCount, setUnreadMessageCount] = useState(0);
  const [unreadNotificationCount, setUnreadNotificationCount] = useState(0);
  const { data: session } = useSession() || {};

  useEffect(() => {
    if (session?.user?.id) {
      fetchUnreadCounts();
      
      // Periyodik olarak güncelle
      const interval = setInterval(fetchUnreadCounts, 30000); // Her 30 saniyede bir
      return () => clearInterval(interval);
    }
  }, [session]);

  const fetchUnreadCounts = async () => {
    try {
      // Okunmamış mesaj sayısını getir
      const messagesRes = await fetch('/api/messages');
      if (messagesRes.ok) {
        const messagesData = await messagesRes.json();
        const totalUnread = messagesData.conversations?.reduce(
          (sum: number, conv: any) => sum + (conv.unreadCount || 0),
          0
        ) || 0;
        setUnreadMessageCount(totalUnread);
      }

      // Okunmamış bildirim sayısını getir
      const notificationsRes = await fetch('/api/notifications');
      if (notificationsRes.ok) {
        const notificationsData = await notificationsRes.json();
        const unreadNotifs = notificationsData.notifications?.filter(
          (n: any) => !n.isRead
        ).length || 0;
        setUnreadNotificationCount(unreadNotifs);
      }
    } catch (error) {
      console.error('Bildirim sayıları alınamadı:', error);
    }
  };

  const handleSignOut = async () => {
    await signOut({ callbackUrl: '/' });
  };

  const getInitials = (name: string | null | undefined) => {
    if (!name) return 'U';
    return name.split(' ').map(word => word.charAt(0)).join('').toUpperCase().slice(0, 2);
  };

  return (
    <motion.header
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="sticky top-0 z-50 bg-white/10 backdrop-blur-md border-b border-white/20"
    >
      <div className="container mx-auto px-3 sm:px-6 py-3 sm:py-4">
        <div className="flex items-center justify-between gap-2 sm:gap-4">
          {/* Logo */}
          <Link href="/dashboard" className="flex items-center space-x-2 sm:space-x-3 group flex-shrink-0">
            <motion.div
              whileHover={{ rotate: 360 }}
              transition={{ duration: 1 }}
            >
              <Moon className="w-6 h-6 sm:w-8 sm:h-8 text-purple-300 group-hover:text-purple-200 transition-colors" />
            </motion.div>
            <h1 className="text-base sm:text-xl font-bold text-white group-hover:text-purple-200 transition-colors whitespace-nowrap">
              Rüya Günlüğüm
            </h1>
          </Link>

          {/* Navigation - Hidden on mobile */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link
              href="/dashboard"
              className="text-purple-200 hover:text-white transition-colors px-3 py-2 rounded-lg hover:bg-white/10"
            >
              Dashboard
            </Link>
            <Link
              href="/dashboard/ruya-ekle"
              className="text-purple-200 hover:text-white transition-colors px-3 py-2 rounded-lg hover:bg-white/10"
            >
              Rüya Ekle
            </Link>
            <Link
              href="/dashboard/topluluk"
              className="text-purple-200 hover:text-white transition-colors px-3 py-2 rounded-lg hover:bg-white/10"
            >
              Topluluk
            </Link>
            <Link
              href="/dashboard/friends"
              className="text-purple-200 hover:text-white transition-colors px-3 py-2 rounded-lg hover:bg-white/10"
            >
              Arkadaşlar
            </Link>
            <Link
              href="/dashboard/semboller"
              className="text-purple-200 hover:text-white transition-colors px-3 py-2 rounded-lg hover:bg-white/10"
            >
              Semboller
            </Link>
          </nav>

          {/* Right Side */}
          <div className="flex items-center space-x-1 sm:space-x-2 md:space-x-4">
            {/* Search Button - Hidden on mobile */}
            <Button
              variant="ghost"
              size="icon"
              className="text-purple-200 hover:text-white hover:bg-white/10 hidden sm:inline-flex h-8 w-8 sm:h-10 sm:w-10"
            >
              <Search className="w-4 h-4 sm:w-5 sm:h-5" />
            </Button>

            {/* Messages */}
            <Link href="/dashboard/mesajlar">
              <Button
                variant="ghost"
                size="icon"
                className="text-purple-200 hover:text-white hover:bg-white/10 relative h-8 w-8 sm:h-10 sm:w-10"
              >
                <MessageCircle className="w-4 h-4 sm:w-5 sm:h-5" />
                {unreadMessageCount > 0 && (
                  <span className="absolute -top-1 -right-1 min-w-[16px] h-[16px] sm:min-w-[18px] sm:h-[18px] bg-pink-500 rounded-full text-[9px] sm:text-[10px] font-bold text-white flex items-center justify-center px-0.5 sm:px-1">
                    {unreadMessageCount > 9 ? '9+' : unreadMessageCount}
                  </span>
                )}
              </Button>
            </Link>

            {/* Friends - Hidden on mobile */}
            <Link href="/dashboard/arkadaslar" className="hidden sm:inline-flex">
              <Button
                variant="ghost"
                size="icon"
                className="text-purple-200 hover:text-white hover:bg-white/10 h-8 w-8 sm:h-10 sm:w-10"
              >
                <Users className="w-4 h-4 sm:w-5 sm:h-5" />
              </Button>
            </Link>

            {/* Notifications */}
            <Link href="/dashboard/notifications">
              <Button
                variant="ghost"
                size="icon"
                className="text-purple-200 hover:text-white hover:bg-white/10 relative h-8 w-8 sm:h-10 sm:w-10"
              >
                <Bell className="w-4 h-4 sm:w-5 sm:h-5" />
                {unreadNotificationCount > 0 && (
                  <span className="absolute -top-1 -right-1 min-w-[16px] h-[16px] sm:min-w-[18px] sm:h-[18px] bg-pink-500 rounded-full text-[9px] sm:text-[10px] font-bold text-white flex items-center justify-center px-0.5 sm:px-1">
                    {unreadNotificationCount > 9 ? '9+' : unreadNotificationCount}
                  </span>
                )}
              </Button>
            </Link>

            {/* User Menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-8 w-8 sm:h-10 sm:w-10 rounded-full p-0">
                  <UserAvatar 
                    image={session?.user?.image || null}
                    name={session?.user?.name || null}
                    className="h-8 w-8 sm:h-10 sm:w-10 border-2 border-purple-300/50"
                  />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-48 sm:w-56 bg-white/10 backdrop-blur-md border-white/20" align="end">
                <div className="flex items-center justify-start gap-2 p-2">
                  <div className="flex flex-col space-y-1 leading-none min-w-0">
                    <p className="font-medium text-white text-sm truncate">
                      {session?.user?.name || 'Kullanıcı'}
                    </p>
                    <p className="text-xs text-purple-200 truncate">
                      {session?.user?.email || 'user@example.com'}
                    </p>
                  </div>
                </div>
                <DropdownMenuSeparator className="bg-white/20" />
                <DropdownMenuItem asChild className="text-purple-200 hover:text-white hover:bg-white/10">
                  <Link href="/dashboard/profil" className="flex items-center">
                    <User className="mr-2 h-4 w-4" />
                    Profilim
                  </Link>
                </DropdownMenuItem>
                {session?.user?.isAdmin && (
                  <DropdownMenuItem asChild className="text-purple-200 hover:text-white hover:bg-white/10">
                    <Link href="/dashboard/admin/ayarlar" className="flex items-center">
                      <Shield className="mr-2 h-4 w-4 text-green-400" />
                      Admin Paneli
                    </Link>
                  </DropdownMenuItem>
                )}
                <DropdownMenuItem asChild className="text-purple-200 hover:text-white hover:bg-white/10">
                  <Link href="/dashboard/ayarlar" className="flex items-center">
                    <Settings className="mr-2 h-4 w-4" />
                    Ayarlar
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild className="text-purple-200 hover:text-white hover:bg-white/10">
                  <Link href="/premium" className="flex items-center">
                    <Crown className="mr-2 h-4 w-4 text-yellow-400" />
                    Premium'a Geç
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator className="bg-white/20" />
                <DropdownMenuItem 
                  onClick={handleSignOut}
                  className="text-red-300 hover:text-red-200 hover:bg-red-500/20"
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  Çıkış Yap
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Mobile Menu */}
            <div className="md:hidden">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="text-purple-200 hover:text-white hover:bg-white/10 h-8 w-8"
              >
                <Menu className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <motion.nav
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden mt-4 pt-4 border-t border-white/20"
          >
            <div className="flex flex-col space-y-2">
              <Link
                href="/dashboard"
                className="text-purple-200 hover:text-white transition-colors px-3 py-2 rounded-lg hover:bg-white/10"
                onClick={() => setIsMenuOpen(false)}
              >
                Dashboard
              </Link>
              <Link
                href="/dashboard/ruya-ekle"
                className="text-purple-200 hover:text-white transition-colors px-3 py-2 rounded-lg hover:bg-white/10"
                onClick={() => setIsMenuOpen(false)}
              >
                Rüya Ekle
              </Link>
              <Link
                href="/dashboard/topluluk"
                className="text-purple-200 hover:text-white transition-colors px-3 py-2 rounded-lg hover:bg-white/10"
                onClick={() => setIsMenuOpen(false)}
              >
                Topluluk
              </Link>
              <Link
                href="/dashboard/mesajlar"
                className="text-purple-200 hover:text-white transition-colors px-3 py-2 rounded-lg hover:bg-white/10 flex items-center justify-between"
                onClick={() => setIsMenuOpen(false)}
              >
                <div className="flex items-center">
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Mesajlar
                </div>
                {unreadMessageCount > 0 && (
                  <span className="min-w-[20px] h-[20px] bg-pink-500 rounded-full text-xs font-bold text-white flex items-center justify-center px-1">
                    {unreadMessageCount > 9 ? '9+' : unreadMessageCount}
                  </span>
                )}
              </Link>
              <Link
                href="/dashboard/arkadaslar"
                className="text-purple-200 hover:text-white transition-colors px-3 py-2 rounded-lg hover:bg-white/10 flex items-center"
                onClick={() => setIsMenuOpen(false)}
              >
                <Users className="w-4 h-4 mr-2" />
                Arkadaşlar
              </Link>
              <Link
                href="/dashboard/notifications"
                className="text-purple-200 hover:text-white transition-colors px-3 py-2 rounded-lg hover:bg-white/10 flex items-center justify-between"
                onClick={() => setIsMenuOpen(false)}
              >
                <div className="flex items-center">
                  <Bell className="w-4 h-4 mr-2" />
                  Bildirimler
                </div>
                {unreadNotificationCount > 0 && (
                  <span className="min-w-[20px] h-[20px] bg-pink-500 rounded-full text-xs font-bold text-white flex items-center justify-center px-1">
                    {unreadNotificationCount > 9 ? '9+' : unreadNotificationCount}
                  </span>
                )}
              </Link>
              <Link
                href="/dashboard/semboller"
                className="text-purple-200 hover:text-white transition-colors px-3 py-2 rounded-lg hover:bg-white/10"
                onClick={() => setIsMenuOpen(false)}
              >
                Semboller
              </Link>
            </div>
          </motion.nav>
        )}
      </div>
    </motion.header>
  );
}
