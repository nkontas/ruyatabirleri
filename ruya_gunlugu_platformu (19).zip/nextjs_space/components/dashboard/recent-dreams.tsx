
'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { motion } from 'framer-motion';
import { 
  Clock, 
  Brain, 
  Sparkles, 
  Moon, 
  Star,
  ArrowRight,
  Plus,
  Eye,
  Calendar
} from 'lucide-react';
import Link from 'next/link';
import { formatDistanceToNow } from 'date-fns';
import { tr } from 'date-fns/locale';

interface Dream {
  id: string;
  title: string;
  content: string;
  date: string;
  dreamType: string;
  sleepQuality?: number;
  createdAt: string;
  analysis?: {
    emotions: string[];
    symbols: string[];
    imageUrl?: string;
  };
}

const dreamTypeLabels: Record<string, string> = {
  NORMAL: 'Normal',
  NIGHTMARE: 'Kabus',
  LUCID: 'Lucid',
  RECURRING: 'Tekrarlayan',
  PROPHETIC: 'Kehanetvari',
  HEALING: 'İyileştirici',
};

const dreamTypeColors: Record<string, string> = {
  NORMAL: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
  NIGHTMARE: 'bg-red-500/20 text-red-300 border-red-500/30',
  LUCID: 'bg-purple-500/20 text-purple-300 border-purple-500/30',
  RECURRING: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30',
  PROPHETIC: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30',
  HEALING: 'bg-green-500/20 text-green-300 border-green-500/30',
};

export default function RecentDreams() {
  const { data: session } = useSession() || {};
  const [dreams, setDreams] = useState<Dream[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchRecentDreams = async () => {
      if (!session?.user?.id) return;

      try {
        const response = await fetch('/api/dreams?limit=5');
        if (response.ok) {
          const data = await response.json();
          setDreams(data);
        }
      } catch (error) {
        console.error('Dreams fetch error:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchRecentDreams();
  }, [session?.user?.id]);

  const truncateContent = (content: string, maxLength: number = 150) => {
    if (content.length <= maxLength) return content;
    return content.substring(0, maxLength) + '...';
  };

  const getSleepQualityColor = (quality?: number) => {
    if (!quality) return 'text-gray-400';
    if (quality >= 8) return 'text-green-300';
    if (quality >= 6) return 'text-yellow-300';
    if (quality >= 4) return 'text-orange-300';
    return 'text-red-300';
  };

  const getSleepQualityIcon = (quality?: number) => {
    if (!quality) return '😴';
    if (quality >= 8) return '😴✨';
    if (quality >= 6) return '😊';
    if (quality >= 4) return '😐';
    return '😴💭';
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.6, delay: 0.4 }}
      className="space-y-4"
    >
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Son Rüyalarım</h2>
        <Button variant="ghost" asChild className="text-purple-200 hover:text-white">
          <Link href="/dashboard/ruyalarim" className="flex items-center">
            Tümünü Gör <ArrowRight className="w-4 h-4 ml-2" />
          </Link>
        </Button>
      </div>

      {isLoading ? (
        <div className="space-y-4">
          {[...Array(3)].map((_, i) => (
            <Card key={i} className="bg-white/5 backdrop-blur-md border-white/10">
              <CardContent className="p-6">
                <div className="animate-pulse space-y-3">
                  <div className="h-4 bg-white/20 rounded w-3/4" />
                  <div className="h-3 bg-white/20 rounded w-full" />
                  <div className="h-3 bg-white/20 rounded w-2/3" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : dreams.length === 0 ? (
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6 }}
        >
          <Card className="bg-white/5 backdrop-blur-md border-white/10">
            <CardContent className="p-12 text-center">
              <motion.div
                animate={{ rotate: [0, 10, -10, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <Moon className="w-16 h-16 text-purple-300 mx-auto mb-4" />
              </motion.div>
              <h3 className="text-xl font-semibold text-white mb-2">
                Henüz rüya kaydınız yok
              </h3>
              <p className="text-purple-200 mb-6">
                İlk rüyanızı kaydedin ve AI ile analiz etmeye başlayın
              </p>
              <Button asChild className="bg-gradient-to-r from-purple-600 to-blue-600">
                <Link href="/dashboard/ruya-ekle">
                  <Plus className="w-4 h-4 mr-2" />
                  İlk Rüyamı Kaydet
                </Link>
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      ) : (
        <div className="space-y-4">
          {dreams.map((dream, index) => (
            <motion.div
              key={dream.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ scale: 1.02 }}
            >
              <Card className="bg-white/10 backdrop-blur-md border-white/20 hover:bg-white/15 transition-all duration-300 group">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <h3 className="font-semibold text-white group-hover:text-purple-200 transition-colors">
                          {dream.title}
                        </h3>
                        <Badge 
                          variant="outline" 
                          className={`text-xs border ${dreamTypeColors[dream.dreamType] || 'bg-gray-500/20 text-gray-300 border-gray-500/30'}`}
                        >
                          {dreamTypeLabels[dream.dreamType] || dream.dreamType}
                        </Badge>
                      </div>
                      
                      <p className="text-purple-200 text-sm leading-relaxed mb-3">
                        {truncateContent(dream.content)}
                      </p>

                      <div className="flex items-center space-x-4 text-xs text-purple-300">
                        <div className="flex items-center space-x-1">
                          <Calendar className="w-3 h-3" />
                          <span>
                            {formatDistanceToNow(new Date(dream.createdAt), { 
                              addSuffix: true, 
                              locale: tr 
                            })}
                          </span>
                        </div>
                        
                        {dream.sleepQuality && (
                          <div className="flex items-center space-x-1">
                            <span>{getSleepQualityIcon(dream.sleepQuality)}</span>
                            <span className={getSleepQualityColor(dream.sleepQuality)}>
                              {dream.sleepQuality}/10
                            </span>
                          </div>
                        )}

                        {dream.analysis && (
                          <div className="flex items-center space-x-2">
                            {dream.analysis.emotions.length > 0 && (
                              <div className="flex items-center space-x-1">
                                <Brain className="w-3 h-3 text-cyan-400" />
                                <span className="text-cyan-300">Analiz edildi</span>
                              </div>
                            )}
                            {dream.analysis.imageUrl && (
                              <div className="flex items-center space-x-1">
                                <Sparkles className="w-3 h-3 text-yellow-400" />
                                <span className="text-yellow-300">Görsel</span>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="flex flex-col space-y-2 ml-4">
                      <Button
                        variant="ghost"
                        size="sm"
                        asChild
                        className="text-purple-200 hover:text-white hover:bg-white/10"
                      >
                        <Link href={`/dashboard/ruya/${dream.id}`}>
                          <Eye className="w-4 h-4 md:mr-1" />
                          <span className="hidden md:inline">Görüntüle</span>
                        </Link>
                      </Button>

                      {!dream.analysis && (
                        <Button
                          variant="ghost"
                          size="sm"
                          asChild
                          className="text-cyan-300 hover:text-cyan-200 hover:bg-cyan-500/10"
                        >
                          <Link href={`/dashboard/ruya/${dream.id}/analiz`}>
                            <Brain className="w-4 h-4 mr-1" />
                            Analiz Et
                          </Link>
                        </Button>
                      )}
                    </div>
                  </div>

                  {dream.analysis?.symbols && dream.analysis.symbols.length > 0 && (
                    <div className="pt-3 border-t border-white/10">
                      <div className="flex flex-wrap gap-1">
                        <span className="text-xs text-purple-300 mr-2">Semboller:</span>
                        {dream.analysis.symbols.slice(0, 5).map((symbol, idx) => (
                          <Badge
                            key={idx}
                            variant="secondary"
                            className="text-xs bg-purple-500/20 text-purple-200 border-purple-500/30"
                          >
                            {symbol}
                          </Badge>
                        ))}
                        {dream.analysis.symbols.length > 5 && (
                          <Badge
                            variant="secondary"
                            className="text-xs bg-purple-500/20 text-purple-200 border-purple-500/30"
                          >
                            +{dream.analysis.symbols.length - 5} daha
                          </Badge>
                        )}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      )}
    </motion.div>
  );
}
