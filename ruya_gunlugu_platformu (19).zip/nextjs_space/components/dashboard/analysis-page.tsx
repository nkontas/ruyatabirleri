'use client';

import { useState, useEffect } from 'react';
import { useSearchParams } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, Brain, Sparkles, Heart, BookOpen, Plus, Calendar, Eye } from 'lucide-react';
import { motion } from 'framer-motion';
import DashboardHeader from './dashboard-header';
import Image from 'next/image';
import Link from 'next/link';
import { formatDistanceToNow } from 'date-fns';
import { tr } from 'date-fns/locale';

interface Dream {
  id: string;
  title: string;
  content: string;
  createdAt: string;
  analysis?: {
    symbols: string[];
    emotions: string[];
    imageUrl?: string;
  };
}

export default function AnalysisPage() {
  const searchParams = useSearchParams();
  const dreamId = searchParams?.get('dreamId');
  const [loading, setLoading] = useState(true);
  const [dream, setDream] = useState<any>(null);
  const [analysis, setAnalysis] = useState<any>(null);
  const [analyzedDreams, setAnalyzedDreams] = useState<Dream[]>([]);

  useEffect(() => {
    if (dreamId) {
      fetchDreamAndAnalysis();
    } else {
      fetchAnalyzedDreams();
    }
  }, [dreamId]);

  const fetchDreamAndAnalysis = async () => {
    try {
      const response = await fetch(`/api/dreams/${dreamId}`);
      const data = await response.json();
      setDream(data);
      setAnalysis(data.analysis);
    } catch (error) {
      console.error('Error fetching dream:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchAnalyzedDreams = async () => {
    try {
      const response = await fetch('/api/dreams?limit=50');
      if (response.ok) {
        const data = await response.json();
        // Filter only dreams with analysis
        const analyzed = data.filter((d: Dream) => d.analysis);
        setAnalyzedDreams(analyzed);
      }
    } catch (error) {
      console.error('Error fetching dreams:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center">
        <Loader2 className="w-12 h-12 text-white animate-spin" />
      </div>
    );
  }

  // Show dream list if no dreamId
  if (!dreamId) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
        <DashboardHeader />
        <div className="container mx-auto px-6 py-8 max-w-6xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="space-y-6"
          >
            <div className="flex items-center justify-between">
              <h1 className="text-3xl md:text-4xl font-bold text-white">Analiz Edilmiş Rüyalar 🔮</h1>
              <Button
                asChild
                className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
              >
                <Link href="/dashboard/ruyalarim">
                  <Eye className="w-4 h-4 md:mr-2" />
                  <span className="hidden md:inline">Tüm Rüyalar</span>
                </Link>
              </Button>
            </div>

            {analyzedDreams.length === 0 ? (
              <Card className="bg-white/10 backdrop-blur-md border-white/20">
                <CardContent className="p-12 text-center">
                  <Brain className="w-16 h-16 text-purple-300 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-white mb-2">
                    Henüz analiz edilmiş rüya yok
                  </h3>
                  <p className="text-purple-200 mb-6">
                    Rüyalarınızı AI ile analiz edin ve derinlemesine yorumlar alın
                  </p>
                  <Button
                    asChild
                    className="bg-gradient-to-r from-purple-600 to-blue-600"
                  >
                    <Link href="/dashboard/ruyalarim">
                      <Plus className="w-4 h-4 mr-2" />
                      Rüya Seç ve Analiz Et
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-4">
                {analyzedDreams.map((dream, index) => (
                  <motion.div
                    key={dream.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                  >
                    <Link href={`/dashboard/analiz?dreamId=${dream.id}`}>
                      <Card className="bg-white/10 backdrop-blur-md border-white/20 hover:bg-white/15 transition-all duration-300 cursor-pointer group">
                        <CardContent className="p-6">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <h3 className="font-semibold text-white group-hover:text-purple-200 transition-colors text-lg mb-2">
                                {dream.title}
                              </h3>
                              <div className="flex items-center space-x-4 text-xs text-purple-300 mb-3">
                                <div className="flex items-center space-x-1">
                                  <Calendar className="w-3 h-3" />
                                  <span>
                                    {formatDistanceToNow(new Date(dream.createdAt), {
                                      addSuffix: true,
                                      locale: tr,
                                    })}
                                  </span>
                                </div>
                                {dream.analysis?.imageUrl && (
                                  <div className="flex items-center space-x-1">
                                    <Sparkles className="w-3 h-3 text-yellow-400" />
                                    <span className="text-yellow-300">AI Görsel</span>
                                  </div>
                                )}
                              </div>
                              {dream.analysis?.symbols && dream.analysis.symbols.length > 0 && (
                                <div className="flex flex-wrap gap-1">
                                  {dream.analysis.symbols.slice(0, 5).map((symbol, idx) => (
                                    <Badge
                                      key={idx}
                                      variant="secondary"
                                      className="text-xs bg-purple-500/20 text-purple-200 border-purple-500/30"
                                    >
                                      {symbol}
                                    </Badge>
                                  ))}
                                  {dream.analysis.symbols.length > 5 && (
                                    <Badge
                                      variant="secondary"
                                      className="text-xs bg-purple-500/20 text-purple-200 border-purple-500/30"
                                    >
                                      +{dream.analysis.symbols.length - 5}
                                    </Badge>
                                  )}
                                </div>
                              )}
                            </div>
                            {dream.analysis?.imageUrl && (
                              <div className="ml-4 relative w-24 h-24 rounded-lg overflow-hidden bg-muted flex-shrink-0">
                                <Image
                                  src={dream.analysis.imageUrl}
                                  alt={dream.title}
                                  fill
                                  className="object-cover"
                                />
                              </div>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    </Link>
                  </motion.div>
                ))}
              </div>
            )}
          </motion.div>
        </div>
      </div>
    );
  }

  // Show specific dream analysis
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      <DashboardHeader />

      <div className="container mx-auto px-6 py-8 max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="space-y-6"
        >
          <div className="flex items-center justify-between">
            <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">Rüya Analizi 🔮</h1>
            <Button
              asChild
              variant="outline"
              className="border-purple-500/30 text-purple-200 hover:bg-purple-500/10"
            >
              <Link href="/dashboard/analiz">
                <Brain className="w-4 h-4 md:mr-2" />
                <span className="hidden md:inline">Tüm Analizler</span>
              </Link>
            </Button>
          </div>
          
          {dream && (
            <Card className="bg-white/10 backdrop-blur-md border-white/20">
              <CardHeader>
                <CardTitle className="text-white">{dream.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-purple-200 leading-relaxed whitespace-pre-wrap">{dream.content}</p>
              </CardContent>
            </Card>
          )}

          {!analysis && (
            <Card className="bg-white/10 backdrop-blur-md border-white/20">
              <CardContent className="p-8 text-center">
                <Brain className="w-12 h-12 text-purple-300 mx-auto mb-4" />
                <p className="text-purple-200 text-lg mb-4">
                  Bu rüya henüz analiz edilmemiş
                </p>
                <Button
                  asChild
                  className="bg-gradient-to-r from-purple-600 to-blue-600"
                >
                  <Link href={`/dashboard/ruya/${dreamId}/analiz`}>
                    <Brain className="w-4 h-4 mr-2" />
                    Analiz Et
                  </Link>
                </Button>
              </CardContent>
            </Card>
          )}

          {analysis && (
            <>
              {analysis.imageUrl && (
                <Card className="bg-white/10 backdrop-blur-md border-white/20 overflow-hidden">
                  <CardContent className="p-6">
                    <h3 className="text-xl font-semibold text-white mb-4 flex items-center">
                      <Sparkles className="w-5 h-5 mr-2" />
                      AI Tarafından Oluşturulan Görsel
                    </h3>
                    <div className="relative aspect-square w-full max-w-lg mx-auto rounded-lg overflow-hidden bg-muted">
                      <Image
                        src={analysis.imageUrl}
                        alt="Rüya görseli"
                        fill
                        className="object-cover"
                      />
                    </div>
                  </CardContent>
                </Card>
              )}

              <div className="grid md:grid-cols-2 gap-6">
                <Card className="bg-white/10 backdrop-blur-md border-white/20">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center">
                      <Brain className="w-5 h-5 mr-2" />
                      Semboller
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-2">
                      {analysis.symbols?.map((symbol: string, i: number) => (
                        <span key={i} className="px-3 py-1 bg-purple-500/30 rounded-full text-purple-200 text-sm">
                          {symbol}
                        </span>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-white/10 backdrop-blur-md border-white/20">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center">
                      <Heart className="w-5 h-5 mr-2" />
                      Duygular
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-2">
                      {analysis.emotions?.map((emotion: string, i: number) => (
                        <span key={i} className="px-3 py-1 bg-pink-500/30 rounded-full text-pink-200 text-sm">
                          {emotion}
                        </span>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card className="bg-white/10 backdrop-blur-md border-white/20">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <BookOpen className="w-5 h-5 mr-2" />
                    Jung Yorumu
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-purple-200 leading-relaxed">{analysis.jungInterpretation}</p>
                </CardContent>
              </Card>

              <Card className="bg-white/10 backdrop-blur-md border-white/20">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <BookOpen className="w-5 h-5 mr-2" />
                    Freud Yorumu
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-purple-200 leading-relaxed">{analysis.freudInterpretation}</p>
                </CardContent>
              </Card>

              {analysis.islamicInterpretation && (
                <Card className="bg-white/10 backdrop-blur-md border-white/20">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center">
                      <BookOpen className="w-5 h-5 mr-2" />
                      İslami Yorum
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-purple-200 leading-relaxed">{analysis.islamicInterpretation}</p>
                  </CardContent>
                </Card>
              )}

              <Card className="bg-white/10 backdrop-blur-md border-white/20">
                <CardHeader>
                  <CardTitle className="text-white">Kişisel Öneriler</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-purple-200 leading-relaxed">{analysis.personalInsights}</p>
                </CardContent>
              </Card>
            </>
          )}
        </motion.div>
      </div>
    </div>
  );
}
