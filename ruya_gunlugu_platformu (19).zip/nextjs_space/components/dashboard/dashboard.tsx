
'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Moon, 
  Plus, 
  Brain, 
  BookOpen, 
  BarChart3, 
  Users, 
  Settings, 
  Crown,
  LogOut,
  Sparkles,
  Calendar,
  Search
} from 'lucide-react';
import { motion } from 'framer-motion';
import Link from 'next/link';
import DashboardHeader from './dashboard-header';
import RecentDreams from './recent-dreams';
import DashboardStats from './dashboard-stats';

interface DashboardProps {
  isPremium: boolean;
  premiumUntil: Date | null;
}

export default function Dashboard({ isPremium, premiumUntil }: DashboardProps) {
  const [mounted, setMounted] = useState(false);
  const [daysRemaining, setDaysRemaining] = useState<number | null>(null);

  useEffect(() => {
    setMounted(true);
    
    // Premium bitiş tarihine kaç gün kaldığını hesapla
    if (isPremium && premiumUntil) {
      const today = new Date();
      const endDate = new Date(premiumUntil);
      const diffTime = endDate.getTime() - today.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      setDaysRemaining(diffDays > 0 ? diffDays : 0);
    }
  }, [isPremium, premiumUntil]);

  if (!mounted) {
    return <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900" />;
  }

  const quickActions = [
    {
      title: 'Yeni Rüya Ekle',
      description: 'Ses kaydı veya metin ile yeni rüyanızı kaydedin',
      icon: Plus,
      href: '/dashboard/ruya-ekle',
      gradient: 'from-purple-500 to-pink-500',
    },
    {
      title: 'Rüya Analizi',
      description: 'AI ile rüyalarınızı derinlemesine analiz edin',
      icon: Brain,
      href: '/dashboard/analiz',
      gradient: 'from-blue-500 to-cyan-500',
    },
    {
      title: 'Rüya Galerisi',
      description: 'AI tarafından oluşturulan rüya görsellerinizi görün',
      icon: Sparkles,
      href: '/dashboard/galeri',
      gradient: 'from-indigo-500 to-purple-500',
    },
    {
      title: 'İstatistikler',
      description: 'Rüya patternlerinizi ve trendlerinizi keşfedin',
      icon: BarChart3,
      href: '/dashboard/istatistikler',
      gradient: 'from-emerald-500 to-teal-500',
    },
    {
      title: 'Topluluk',
      description: 'Rüya paylaşımları ve yorumları görün',
      icon: Users,
      href: '/dashboard/topluluk',
      gradient: 'from-orange-500 to-red-500',
    },
    {
      title: 'Semboller',
      description: 'Rüya sembolleri ansiklopedisini inceleyin',
      icon: BookOpen,
      href: '/dashboard/semboller',
      gradient: 'from-violet-500 to-purple-500',
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 relative">
      {/* Animated background */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div
          animate={{ 
            scale: [1, 1.2, 1],
            rotate: [0, 180, 360],
          }}
          transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
          className="absolute top-10 left-10 w-32 h-32 bg-purple-500/5 rounded-full blur-3xl"
        />
        <motion.div
          animate={{ 
            scale: [1.2, 1, 1.2],
            rotate: [360, 180, 0],
          }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          className="absolute bottom-10 right-10 w-40 h-40 bg-blue-500/5 rounded-full blur-3xl"
        />
      </div>

      <div className="relative z-10">
        <DashboardHeader />

        <div className="container mx-auto px-4 sm:px-6 py-4 sm:py-8 space-y-6 sm:space-y-8">
          {/* Welcome Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold text-white mb-2">
              Hoş Geldiniz, Rüya Kaşifi! 🌙
            </h1>
            <p className="text-purple-200 text-sm sm:text-base md:text-lg">
              Bugün hangi rüyanızı keşfetmeye hazırsınız?
            </p>
          </motion.div>

          {/* Stats Cards */}
          <DashboardStats />

          {/* Quick Actions Grid */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="space-y-4"
          >
            <h2 className="text-xl sm:text-2xl font-bold text-white">Hızlı İşlemler</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
              {quickActions.map((action, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.3 + index * 0.1 }}
                  whileHover={{ scale: 1.02, y: -5 }}
                >
                  <Link href={action.href}>
                    <Card className="bg-white/10 backdrop-blur-md border-white/20 hover:bg-white/15 transition-all duration-300 cursor-pointer group h-full">
                      <CardContent className="p-4 sm:p-6">
                        <div className="flex items-start space-x-3 sm:space-x-4">
                          <div className={`p-2 sm:p-3 rounded-xl bg-gradient-to-br ${action.gradient} shadow-lg group-hover:scale-110 transition-transform duration-300 flex-shrink-0`}>
                            <action.icon className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <h3 className="font-semibold text-white mb-1 sm:mb-2 group-hover:text-purple-200 transition-colors text-sm sm:text-base">
                              {action.title}
                            </h3>
                            <p className="text-xs sm:text-sm text-purple-200 leading-relaxed">
                              {action.description}
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Recent Dreams */}
          <RecentDreams />

          {/* Premium Status Section */}
          {isPremium ? (
            // Premium üyeler için kalan gün sayısı kartı
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.5 }}
            >
              <Card className="bg-gradient-to-r from-yellow-600/20 to-orange-600/20 border-yellow-400/30 backdrop-blur-md">
                <CardContent className="p-4 sm:p-6">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                    <div className="flex items-start space-x-3 sm:space-x-4 flex-1">
                      <div className="p-2 sm:p-3 bg-gradient-to-br from-yellow-500 to-orange-500 rounded-xl flex-shrink-0">
                        <Crown className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                      </div>
                      <div className="min-w-0">
                        <h3 className="text-base sm:text-xl font-semibold text-white mb-1">
                          ✨ Premium Üyesiniz
                        </h3>
                        {daysRemaining !== null && (
                          <p className="text-yellow-200 text-xs sm:text-sm">
                            {daysRemaining > 0 
                              ? `Premium üyeliğinizin sona ermesine ${daysRemaining} gün kaldı`
                              : 'Premium üyeliğiniz bugün sona eriyor'}
                          </p>
                        )}
                      </div>
                    </div>
                    {daysRemaining !== null && daysRemaining <= 7 && (
                      <Button className="bg-gradient-to-r from-yellow-600 to-orange-600 hover:from-yellow-700 hover:to-orange-700 w-full sm:w-auto">
                        <Link href="/premium" className="flex items-center">
                          <Sparkles className="w-4 h-4 mr-2" />
                          Yenile
                        </Link>
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ) : (
            // Premium olmayan üyeler için yükseltme banner'ı
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.5 }}
            >
              <Card className="bg-gradient-to-r from-purple-600/20 to-pink-600/20 border-purple-400/30 backdrop-blur-md">
                <CardContent className="p-4 sm:p-6">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                    <div className="flex items-start space-x-3 sm:space-x-4 flex-1">
                      <div className="p-2 sm:p-3 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex-shrink-0">
                        <Crown className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                      </div>
                      <div className="min-w-0">
                        <h3 className="text-base sm:text-xl font-semibold text-white mb-1">Premium Üyeliğe Geçin</h3>
                        <p className="text-purple-200 text-xs sm:text-sm">
                          Sınırsız rüya kaydı, gelişmiş AI analizi ve daha fazlası
                        </p>
                      </div>
                    </div>
                    <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 w-full sm:w-auto">
                      <Link href="/premium" className="flex items-center">
                        <Crown className="w-4 h-4 mr-2" />
                        Yükselt
                      </Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
}
