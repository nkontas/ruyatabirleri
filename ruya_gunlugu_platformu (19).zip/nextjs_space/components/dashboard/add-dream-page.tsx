'use client';

import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {   Mic, Square, Loader2, Brain, Sparkles, Save } from 'lucide-react';
import { motion } from 'framer-motion';
import { useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react';
import toast from 'react-hot-toast';
import DashboardHeader from './dashboard-header';

export default function AddDreamPage() {
  const router = useRouter();
  const { data: session } = useSession() || {};
  const [mounted, setMounted] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const [recordingTime, setRecordingTime] = useState(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const [formData, setFormData] = useState({
    title: '',
    content: '',
    date: new Date().toISOString().split('T')[0],
    sleepHours: '',
    sleepQuality: '',
    moonPhase: 'FULL_MOON',
    dreamType: 'NORMAL',
  });

  useEffect(() => {
    setMounted(true);
  }, []);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaRecorderRef.current = new MediaRecorder(stream);
      audioChunksRef.current = [];

      mediaRecorderRef.current.ondataavailable = (event) => {
        audioChunksRef.current.push(event.data);
      };

      mediaRecorderRef.current.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        setAudioBlob(audioBlob);
        stream.getTracks().forEach(track => track.stop());
        if (timerRef.current) clearInterval(timerRef.current);
      };

      mediaRecorderRef.current.start();
      setIsRecording(true);
      setRecordingTime(0);

      // Start timer
      timerRef.current = setInterval(() => {
        setRecordingTime((prev) => {
          if (prev >= 300) { // 5 minutes = 300 seconds
            stopRecording();
            return 300;
          }
          return prev + 1;
        });
      }, 1000);

      toast.success('Ses kaydı başladı! (Maksimum 5 dakika)');
    } catch (error) {
      console.error('Mikrofon erişimi hatası:', error);
      toast.error('Mikrofon erişimi reddedildi');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      toast.success('Ses kaydı tamamlandı!');
    }
  };

  const transcribeAudio = async () => {
    if (!audioBlob) return;

    setIsTranscribing(true);
    try {
      const formData = new FormData();
      formData.append('audio', audioBlob, 'dream-recording.webm');

      const response = await fetch('/api/transcribe', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) throw new Error('Transkripsiyon başarısız');

      const data = await response.json();
      setFormData((prev) => ({ ...prev, content: data.text }));
      toast.success('Ses metne dönüştürüldü!');
    } catch (error) {
      console.error('Transkripsiyon hatası:', error);
      toast.error('Ses metne dönüştürülemedi');
    } finally {
      setIsTranscribing(false);
    }
  };

  const analyzeWithAI = async () => {
    if (!formData.content.trim()) {
      toast.error('Lütfen önce rüya içeriği ekleyin');
      return;
    }

    setIsAnalyzing(true);
    try {
      const response = await fetch('/api/dreams/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: formData.content }),
      });

      if (!response.ok) throw new Error('Analiz başarısız');

      const data = await response.json();
      toast.success('AI analizi tamamlandı! Rüya kaydediliyor...');
      
      // Analiz sonuçlarını göster
      router.push(`/dashboard/analiz?dreamId=${data.dreamId}`);
    } catch (error) {
      console.error('AI analiz hatası:', error);
      toast.error('AI analizi yapılamadı');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const saveDream = async (withAnalysis: boolean = false) => {
    if (!formData.content.trim() || !formData.title.trim()) {
      toast.error('Lütfen başlık ve içerik alanlarını doldurun');
      return;
    }

    setIsSaving(true);
    try {
      // Upload audio if exists
      let audioUrl = null;
      if (audioBlob) {
        const audioFormData = new FormData();
        audioFormData.append('file', audioBlob, 'dream-recording.webm');
        
        const uploadResponse = await fetch('/api/upload', {
          method: 'POST',
          body: audioFormData,
        });

        if (uploadResponse.ok) {
          const uploadData = await uploadResponse.json();
          audioUrl = uploadData.url;
        }
      }

      // Save dream
      const response = await fetch('/api/dreams', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          audioUrl,
          sleepHours: formData.sleepHours ? parseFloat(formData.sleepHours) : null,
          sleepQuality: formData.sleepQuality ? parseInt(formData.sleepQuality) : null,
          analyze: withAnalysis,
        }),
      });

      if (!response.ok) throw new Error('Rüya kaydedilemedi');

      const data = await response.json();
      toast.success('Rüya başarıyla kaydedildi!');
      
      if (withAnalysis) {
        router.push(`/dashboard/analiz?dreamId=${data.dreamId}`);
      } else {
        router.push('/dashboard');
      }
    } catch (error) {
      console.error('Kayıt hatası:', error);
      toast.error('Rüya kaydedilemedi');
    } finally {
      setIsSaving(false);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (!mounted) {
    return <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900" />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      <DashboardHeader />

      <div className="container mx-auto px-6 py-8 max-w-4xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">Yeni Rüya Ekle 🌙</h1>
          <p className="text-purple-200 text-lg mb-8">
            Rüyanızı sesli anlatın veya yazarak kaydedin
          </p>

          <Card className="bg-white/10 backdrop-blur-md border-white/20">
            <CardHeader>
              <CardTitle className="text-white">Rüya Kaydı</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Voice Recording Section */}
              <div className="space-y-4">
                <Label className="text-white">Sesli Anlatım</Label>
                <div className="flex flex-col sm:flex-row gap-4 items-center">
                  {!isRecording ? (
                    <Button
                      onClick={startRecording}
                      disabled={audioBlob !== null}
                      className="w-full sm:w-auto bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                    >
                      <Mic className="w-4 h-4 mr-2" />
                      Kayda Başla
                    </Button>
                  ) : (
                    <Button
                      onClick={stopRecording}
                      className="w-full sm:w-auto bg-red-600 hover:bg-red-700"
                    >
                      <Square className="w-4 h-4 mr-2" />
                      Kaydı Durdur {formatTime(recordingTime)}
                    </Button>
                  )}

                  {audioBlob && !isRecording && (
                    <div className="flex gap-2 flex-wrap">
                      <Button
                        onClick={transcribeAudio}
                        disabled={isTranscribing}
                        variant="outline"
                        className="bg-white/10 border-white/20 hover:bg-white/20 text-white"
                      >
                        {isTranscribing ? (
                          <>
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            Dönüştürülüyor...
                          </>
                        ) : (
                          'Metne Çevir'
                        )}
                      </Button>
                      <Button
                        onClick={() => {
                          setAudioBlob(null);
                          setRecordingTime(0);
                        }}
                        variant="outline"
                        className="bg-white/10 border-white/20 hover:bg-white/20 text-white"
                      >
                        Kaydı Sil
                      </Button>
                    </div>
                  )}
                </div>
              </div>

              {/* Text Input Fields */}
              <div className="space-y-4">
                <div>
                  <Label htmlFor="title" className="text-white">Rüya Başlığı</Label>
                  <Input
                    id="title"
                    placeholder="Örn: Uçuş Rüyası"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    className="bg-white/10 border-white/20 text-white placeholder:text-purple-200/50"
                  />
                </div>

                <div>
                  <Label htmlFor="content" className="text-white">Rüya İçeriği</Label>
                  <Textarea
                    id="content"
                    placeholder="Rüyanızı detaylı olarak anlatın..."
                    value={formData.content}
                    onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                    rows={8}
                    className="bg-white/10 border-white/20 text-white placeholder:text-purple-200/50"
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="date" className="text-white">Tarih</Label>
                    <Input
                      id="date"
                      type="date"
                      value={formData.date}
                      onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                      className="bg-white/10 border-white/20 text-white"
                    />
                  </div>

                  <div>
                    <Label htmlFor="sleepHours" className="text-white">Uyku Süresi (saat)</Label>
                    <Input
                      id="sleepHours"
                      type="number"
                      step="0.5"
                      placeholder="7.5"
                      value={formData.sleepHours}
                      onChange={(e) => setFormData({ ...formData, sleepHours: e.target.value })}
                      className="bg-white/10 border-white/20 text-white placeholder:text-purple-200/50"
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="sleepQuality" className="text-white">Uyku Kalitesi (1-10)</Label>
                    <Input
                      id="sleepQuality"
                      type="number"
                      min="1"
                      max="10"
                      placeholder="8"
                      value={formData.sleepQuality}
                      onChange={(e) => setFormData({ ...formData, sleepQuality: e.target.value })}
                      className="bg-white/10 border-white/20 text-white placeholder:text-purple-200/50"
                    />
                  </div>

                  <div>
                    <Label htmlFor="moonPhase" className="text-white">Ay Fazı</Label>
                    <Select value={formData.moonPhase} onValueChange={(value) => setFormData({ ...formData, moonPhase: value })}>
                      <SelectTrigger className="bg-white/10 border-white/20 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="NEW_MOON">Yeni Ay</SelectItem>
                        <SelectItem value="WAXING_CRESCENT">Hilal</SelectItem>
                        <SelectItem value="FIRST_QUARTER">İlk Dörtlük</SelectItem>
                        <SelectItem value="WAXING_GIBBOUS">Şişkin Ay</SelectItem>
                        <SelectItem value="FULL_MOON">Dolunay</SelectItem>
                        <SelectItem value="WANING_GIBBOUS">Azalan Şişkin</SelectItem>
                        <SelectItem value="LAST_QUARTER">Son Dörtlük</SelectItem>
                        <SelectItem value="WANING_CRESCENT">Azalan Hilal</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label htmlFor="dreamType" className="text-white">Rüya Türü</Label>
                  <Select value={formData.dreamType} onValueChange={(value) => setFormData({ ...formData, dreamType: value })}>
                    <SelectTrigger className="bg-white/10 border-white/20 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="NORMAL">Normal</SelectItem>
                      <SelectItem value="NIGHTMARE">Kabus</SelectItem>
                      <SelectItem value="LUCID">Lucid (Bilinçli)</SelectItem>
                      <SelectItem value="RECURRING">Tekrarlayan</SelectItem>
                      <SelectItem value="PROPHETIC">Kehanet</SelectItem>
                      <SelectItem value="HEALING">İyileştirici</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <Button
                  onClick={() => saveDream(false)}
                  disabled={isSaving || isAnalyzing}
                  className="flex-1 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700"
                >
                  {isSaving ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Kaydediliyor...
                    </>
                  ) : (
                    <>
                      <Save className="w-4 h-4 mr-2" />
                      Kaydet
                    </>
                  )}
                </Button>

                <Button
                  onClick={() => saveDream(true)}
                  disabled={isSaving || isAnalyzing}
                  className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                >
                  {isAnalyzing ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Analiz Ediliyor...
                    </>
                  ) : (
                    <>
                      <Brain className="w-4 h-4 mr-2" />
                      AI ile Analiz Et
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
