'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Check, Crown, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';
import DashboardHeader from './dashboard/dashboard-header';
import toast from 'react-hot-toast';

export default function PremiumPage() {
  const [loading, setLoading] = useState(false);

  const handlePurchase = async () => {
    setLoading(true);
    
    // DUMMY iyzico ödeme işlemi
    setTimeout(() => {
      toast.success('Ödeme işlemi tamamlandı! (Demo)');
      setLoading(false);
    }, 2000);
  };

  const premiumFeatures = [
    'Sınırsız rüya kaydı',
    'Gelişmiş AI analizi',
    'Detaylı rüya raporları (PDF)',
    'Kişisel rüya danışmanı chatbot',
    'Öncelikli destek',
    'Reklamsız deneyim',
    'Özel rüya sembolleri kütüphanesi',
    'İleri düzey istatistikler',
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      <DashboardHeader />

      <div className="container mx-auto px-6 py-12 max-w-4xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <div className="inline-block p-3 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full mb-4">
            <Crown className="w-12 h-12 text-white" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Premium Üyelik 👑
          </h1>
          <p className="text-xl text-purple-200">
            Rüya deneyiminizi bir üst seviyeye taşıyın
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <Card className="bg-gradient-to-br from-white/10 to-white/5 backdrop-blur-md border-white/20 shadow-2xl">
            <CardHeader className="text-center pb-8">
              <div className="flex items-center justify-center space-x-2 mb-4">
                <Sparkles className="w-6 h-6 text-yellow-400" />
                <CardTitle className="text-3xl text-white">Aylık Abonelik</CardTitle>
                <Sparkles className="w-6 h-6 text-yellow-400" />
              </div>
              <div className="flex items-center justify-center space-x-2">
                <span className="text-5xl font-bold text-white">₺99</span>
                <span className="text-purple-200">/ay</span>
              </div>
            </CardHeader>

            <CardContent className="space-y-6">
              <div className="space-y-4 py-6">
                {premiumFeatures.map((feature, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.4, delay: 0.3 + index * 0.1 }}
                    className="flex items-center space-x-3"
                  >
                    <div className="flex-shrink-0 w-6 h-6 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full flex items-center justify-center">
                      <Check className="w-4 h-4 text-white" />
                    </div>
                    <span className="text-purple-100 text-lg">{feature}</span>
                  </motion.div>
                ))}
              </div>

              <div className="pt-6">
                <Button
                  onClick={handlePurchase}
                  disabled={loading}
                  className="w-full py-6 text-lg bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 shadow-lg hover:shadow-xl transition-all duration-300"
                >
                  {loading ? (
                    'İşleniyor...'
                  ) : (
                    <>
                      <Crown className="w-5 h-5 mr-2" />
                      Şimdi Satın Al (iyzico - Demo)
                    </>
                  )}
                </Button>
              </div>

              <p className="text-center text-purple-200 text-sm pt-4">
                * Bu bir demo ödeme sayfasıdır. Gerçek ödeme işlemi yapılmamaktadır.
              </p>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
