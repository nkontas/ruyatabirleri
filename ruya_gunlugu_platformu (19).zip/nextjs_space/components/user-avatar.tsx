

'use client';

import { useState, useEffect } from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Loader2 } from 'lucide-react';

interface UserAvatarProps {
  image: string | null;
  name: string | null;
  className?: string;
}

export function UserAvatar({ image, name, className }: UserAvatarProps) {
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (image && image.startsWith('6664/')) {
      // S3 key ise, API üzerinden signed URL al
      setIsLoading(true);
      fetch(`/api/user/profile/image?key=${encodeURIComponent(image)}`)
        .then(res => {
          if (!res.ok) throw new Error('Failed to fetch image');
          return res.json();
        })
        .then(data => {
          setImageUrl(data.url);
        })
        .catch(err => {
          console.error('Error loading avatar image:', err);
          setImageUrl(null);
        })
        .finally(() => {
          setIsLoading(false);
        });
    } else if (image) {
      // Normal URL ise doğrudan kullan
      setImageUrl(image);
    } else {
      setImageUrl(null);
    }
  }, [image]);

  return (
    <Avatar className={className}>
      {isLoading ? (
        <AvatarFallback>
          <Loader2 className="h-4 w-4 animate-spin" />
        </AvatarFallback>
      ) : (
        <>
          <AvatarImage src={imageUrl || undefined} alt={name || 'User'} />
          <AvatarFallback className="bg-gradient-to-br from-purple-500 to-pink-500 text-white">
            {name?.[0]?.toUpperCase() || 'U'}
          </AvatarFallback>
        </>
      )}
    </Avatar>
  );
}
