
'use client';

import { useState, useRef, useEffect } from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Camera, Loader2, X } from 'lucide-react';
import { toast } from 'react-hot-toast';
interface ProfileImageUploadProps {
  currentImage: string | null;
  userName: string | null;
  onImageUpdate: (newImagePath: string | null) => void;
}

export function ProfileImageUpload({
  currentImage,
  userName,
  onImageUpdate,
}: ProfileImageUploadProps) {
  const [uploading, setUploading] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [isLoadingImage, setIsLoadingImage] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Load image from S3 when component mounts or currentImage changes
  useEffect(() => {
    if (currentImage && currentImage.startsWith('6664/')) {
      setIsLoadingImage(true);
      fetch(`/api/user/profile/image-url?key=${encodeURIComponent(currentImage)}`)
        .then(res => res.json())
        .then(data => {
          if (data.url) {
            setImageUrl(data.url);
          }
        })
        .catch(err => {
          console.error('Error loading profile image:', err);
        })
        .finally(() => {
          setIsLoadingImage(false);
        });
    } else if (currentImage) {
      setImageUrl(currentImage);
    } else {
      setImageUrl(null);
      setIsLoadingImage(false);
    }
  }, [currentImage]);

  // Compress and resize image using Canvas API
  const compressImage = async (file: File): Promise<File> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      
      reader.onload = (e) => {
        const img = new Image();
        
        img.onload = () => {
          // Max dimensions for profile image
          const MAX_WIDTH = 800;
          const MAX_HEIGHT = 800;
          const MAX_SIZE = 1024 * 1024; // 1MB target size
          
          let width = img.width;
          let height = img.height;
          
          // Calculate new dimensions while maintaining aspect ratio
          if (width > height) {
            if (width > MAX_WIDTH) {
              height = (height * MAX_WIDTH) / width;
              width = MAX_WIDTH;
            }
          } else {
            if (height > MAX_HEIGHT) {
              width = (width * MAX_HEIGHT) / height;
              height = MAX_HEIGHT;
            }
          }
          
          // Create canvas
          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          
          const ctx = canvas.getContext('2d');
          if (!ctx) {
            reject(new Error('Canvas context not available'));
            return;
          }
          
          // Draw image on canvas
          ctx.drawImage(img, 0, 0, width, height);
          
          // Try different quality levels to get under MAX_SIZE
          let quality = 0.9;
          const tryCompress = () => {
            canvas.toBlob(
              (blob) => {
                if (!blob) {
                  reject(new Error('Compression failed'));
                  return;
                }
                
                // If size is still too large and quality can be reduced, try again
                if (blob.size > MAX_SIZE && quality > 0.3) {
                  quality -= 0.1;
                  tryCompress();
                  return;
                }
                
                // Create new file from blob
                const compressedFile = new File(
                  [blob],
                  file.name,
                  { type: 'image/jpeg', lastModified: Date.now() }
                );
                
                console.log(`Original size: ${(file.size / 1024 / 1024).toFixed(2)}MB, Compressed size: ${(compressedFile.size / 1024 / 1024).toFixed(2)}MB`);
                resolve(compressedFile);
              },
              'image/jpeg',
              quality
            );
          };
          
          tryCompress();
        };
        
        img.onerror = () => {
          reject(new Error('Image load failed'));
        };
        
        img.src = e.target?.result as string;
      };
      
      reader.onerror = () => {
        reject(new Error('File read failed'));
      };
      
      reader.readAsDataURL(file);
    });
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type
    const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    if (!validTypes.includes(file.type)) {
      toast.error('Sadece JPG, PNG ve WebP formatları desteklenmektedir');
      return;
    }

    // Show loading toast
    const loadingToast = toast.loading('Resim optimize ediliyor...');

    try {
      // Compress image automatically
      const compressedFile = await compressImage(file);
      toast.dismiss(loadingToast);
      
      // Now upload the compressed file
      await handleUpload(compressedFile);
    } catch (error: any) {
      console.error('Compression error:', error);
      toast.dismiss(loadingToast);
      toast.error('Resim işlenirken bir hata oluştu');
    }
  };

  const handleUpload = async (file: File) => {
    setUploading(true);

    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch('/api/user/profile/image', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Yükleme başarısız');
      }

      const data = await response.json();
      
      // Load the new image
      if (data.image && data.image.startsWith('6664/')) {
        const urlResponse = await fetch(`/api/user/profile/image-url?key=${encodeURIComponent(data.image)}`);
        const urlData = await urlResponse.json();
        if (urlData.url) {
          setImageUrl(urlData.url);
        }
      } else {
        setImageUrl(data.image);
      }
      
      onImageUpdate(data.image);
      toast.success('Profil resmi başarıyla güncellendi');
    } catch (error: any) {
      console.error('Upload error:', error);
      toast.error(error.message || 'Profil resmi yüklenirken bir hata oluştu');
    } finally {
      setUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleDelete = async () => {
    if (!confirm('Profil resmini silmek istediğinizden emin misiniz?')) {
      return;
    }

    setDeleting(true);

    try {
      const response = await fetch('/api/user/profile/image', {
        method: 'DELETE',
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Silme başarısız');
      }

      setImageUrl(null);
      onImageUpdate(null);
      toast.success('Profil resmi silindi');
    } catch (error: any) {
      console.error('Delete error:', error);
      toast.error(error.message || 'Profil resmi silinirken bir hata oluştu');
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="flex flex-col items-center space-y-4">
      <div className="relative">
        <Avatar className="h-32 w-32">
          {isLoadingImage ? (
            <AvatarFallback>
              <Loader2 className="h-8 w-8 animate-spin" />
            </AvatarFallback>
          ) : (
            <>
              <AvatarImage src={imageUrl || undefined} />
              <AvatarFallback className="bg-gradient-to-br from-purple-500 to-pink-500 text-white text-4xl">
                {userName?.[0]?.toUpperCase() || 'U'}
              </AvatarFallback>
            </>
          )}
        </Avatar>

        <input
          ref={fileInputRef}
          type="file"
          accept="image/jpeg,image/jpg,image/png,image/webp"
          onChange={handleFileSelect}
          className="hidden"
        />

        <Button
          size="icon"
          variant="secondary"
          className="absolute bottom-0 right-0 rounded-full shadow-lg"
          onClick={() => fileInputRef.current?.click()}
          disabled={uploading || deleting}
        >
          {uploading ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <Camera className="h-4 w-4" />
          )}
        </Button>
      </div>

      <div className="flex gap-2">
        <Button
          variant="outline"
          size="sm"
          onClick={() => fileInputRef.current?.click()}
          disabled={uploading || deleting}
        >
          {uploading ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Yükleniyor...
            </>
          ) : (
            'Resim Yükle'
          )}
        </Button>

        {imageUrl && (
          <Button
            variant="outline"
            size="sm"
            onClick={handleDelete}
            disabled={uploading || deleting}
          >
            {deleting ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Siliniyor...
              </>
            ) : (
              <>
                <X className="h-4 w-4 mr-2" />
                Resmi Sil
              </>
            )}
          </Button>
        )}
      </div>

      <p className="text-xs text-muted-foreground text-center">
        JPG, PNG veya WebP formatında<br />
        Resminiz otomatik olarak optimize edilecektir
      </p>
    </div>
  );
}
