
import { PrismaClient, SymbolCategory } from '@prisma/client';
import bcryptjs from 'bcryptjs';

const prisma = new PrismaClient();

// 50+ Rüya Sembolleri (Türkçe)
const dreamSymbols = [
  // ANIMALS
  { symbol: 'Kedi', meaning: 'Bağımsızlık, gizemlilik, kadınsılık ve sezgisel güç. Kedi rüyalar genellikle öz güveninizi veya cinselliğinizi temsil eder.', category: 'ANIMALS' as SymbolCategory },
  { symbol: 'Köpek', meaning: 'Sadakat, dostluk, koruma ve güven. Köpek rüyaları genellikle yakın ilişkilerde vefakarlığı simgeler.', category: 'ANIMALS' as SymbolCategory },
  { symbol: 'Yılan', meaning: 'Dönüşüm, iyileşme, cinsellik veya tehlike. Yılan bilinçaltındaki gizli güçleri temsil edebilir.', category: 'ANIMALS' as SymbolCategory },
  { symbol: 'Kartal', meaning: 'Özgürlük, güç, yüksek perspektif ve manevi yücelik. Hedeflerinize ulaşma isteğini simgeler.', category: 'ANIMALS' as SymbolCategory },
  { symbol: 'Balık', meaning: 'Bilinçaltı, derin duygular, maneviyat ve bereket. Ruhani gelişimi temsil eder.', category: 'ANIMALS' as SymbolCategory },
  { symbol: 'At', meaning: 'Güç, hız, tutku ve özgürlük arzusu. Yaşam enerjinizi ve ilerleme isteğinizi yansıtır.', category: 'ANIMALS' as SymbolCategory },
  { symbol: 'Kedi yavrusu', meaning: 'Masumiyet, oyunculuk ve yeni başlangıçlar. İç çocuğunuzla bağlantı kurma ihtiyacını gösterir.', category: 'ANIMALS' as SymbolCategory },
  { symbol: 'Aslan', meaning: 'Cesaret, liderlik, güç ve kral ruhu. Kişisel gücünüzü ortaya çıkarma zamanını işaret eder.', category: 'ANIMALS' as SymbolCategory },

  // NATURE
  { symbol: 'Su', meaning: 'Duygular, temizlenme, yenileme ve ruhani akış. Su durumunuz duygusal halinizi yansıtır.', category: 'NATURE' as SymbolCategory },
  { symbol: 'Ateş', meaning: 'Tutku, dönüşüm, yaratıcılık veya öfke. Güçlü duygusal enerjiyi temsil eder.', category: 'NATURE' as SymbolCategory },
  { symbol: 'Ağaç', meaning: 'Büyüme, köken, istikrar ve yaşam döngüsü. Kişisel gelişiminizi ve kökenlerinizi simgeler.', category: 'NATURE' as SymbolCategory },
  { symbol: 'Dağ', meaning: 'Engeller, hedefler, manevi yükseklik ve zorluklar. Aştığınız ya da aşmanız gereken zorluklardır.', category: 'NATURE' as SymbolCategory },
  { symbol: 'Deniz', meaning: 'Bilinçaltı, sonsuzluk, duygusal derinlik ve gizem. Ruhunuzun derin katmanlarını temsil eder.', category: 'NATURE' as SymbolCategory },
  { symbol: 'Güneş', meaning: 'Aydınlanma, pozitif enerji, başarı ve yaşam gücü. Umut ve neşeyi simgeler.', category: 'NATURE' as SymbolCategory },
  { symbol: 'Ay', meaning: 'Kadınsılık, sezgi, gizem ve döngüsellik. Ruhsal yaşamınızın ritimlerini gösterir.', category: 'NATURE' as SymbolCategory },
  { symbol: 'Yıldız', meaning: 'Rehberlik, umut, dilek ve ruhsal aydınlanma. Hedeflerinize ulaştıracak ilhamı temsil eder.', category: 'NATURE' as SymbolCategory },
  { symbol: 'Rüzgar', meaning: 'Değişim, özgürlük, iletişim ve ruhsal hareket. Hayatınızdaki değişimleri işaret eder.', category: 'NATURE' as SymbolCategory },
  { symbol: 'Kar', meaning: 'Saflık, soğukluk, yalnızlık veya duygusal donukluk. Temiz bir sayfa açma zamanını simgeler.', category: 'NATURE' as SymbolCategory },
  { symbol: 'Çiçek', meaning: 'Güzellik, sevgi, büyüme ve kadınsılık. Hayatınızdaki güzel gelişmeleri temsil eder.', category: 'NATURE' as SymbolCategory },

  // PEOPLE
  { symbol: 'Anne', meaning: 'Koruma, sevgi, şefkat ve beslenme. İçinizdeki besleyici enerjiyi simgeler.', category: 'PEOPLE' as SymbolCategory },
  { symbol: 'Baba', meaning: 'Otorite, koruma, rehberlik ve erkeksi güç. Disiplin ve yapı ihtiyacını gösterir.', category: 'PEOPLE' as SymbolCategory },
  { symbol: 'Çocuk', meaning: 'Masumiyet, yeni başlangıçlar, potansiyel ve iç çocuk. Yaratıcılığınızı ve spontanlığınızı temsil eder.', category: 'PEOPLE' as SymbolCategory },
  { symbol: 'Yaşlı adam', meaning: 'Bilgelik, tecrübe, rehberlik ve zaman. İçinizdeki bilge danışmanı simgeler.', category: 'PEOPLE' as SymbolCategory },
  { symbol: 'Yaşlı kadın', meaning: 'Anne arketip, geleneksel bilgi, koruma ve sezgisel bilgelik. Içgörülerinizi temsil eder.', category: 'PEOPLE' as SymbolCategory },
  { symbol: 'Arkadaş', meaning: 'Destek, paylaşım, sosyal bağlar ve kendinizin farklı yönleri. Sosyal ihtiyaçlarınızı gösterir.', category: 'PEOPLE' as SymbolCategory },
  { symbol: 'Düşman', meaning: 'İçsel çatışma, bastırılmış özellikler ve gölge yönü. Kabul etmediğiniz taraflarınızı simgeler.', category: 'PEOPLE' as SymbolCategory },
  { symbol: 'Öğretmen', meaning: 'Bilgi, rehberlik, öğrenme ve kişisel gelişim. Yaşam derslerinizi temsil eder.', category: 'PEOPLE' as SymbolCategory },

  // OBJECTS
  { symbol: 'Ev', meaning: 'Güvenlik, kimlik, iç dünya ve kişilik. Evin durumu ruhsal halinizi yansıtır.', category: 'OBJECTS' as SymbolCategory },
  { symbol: 'Araba', meaning: 'Kontrol, yön, ilerleme ve kişisel güç. Hayatınızdaki kontrolü simgeler.', category: 'OBJECTS' as SymbolCategory },
  { symbol: 'Köprü', meaning: 'Geçiş, bağlantı, değişim ve yeni olanaklar. Yaşamınızdaki geçiş dönemlerini gösterir.', category: 'OBJECTS' as SymbolCategory },
  { symbol: 'Merdiven', meaning: 'Yükseliş, gelişim, manevi ilerleme ve hedeflere ulaşma. Kişisel büyümenizi temsil eder.', category: 'OBJECTS' as SymbolCategory },
  { symbol: 'Ayna', meaning: 'Öz yansıma, gerçek, kimlik ve kendinizi görme. İçe bakış yapma zamanını işaret eder.', category: 'OBJECTS' as SymbolCategory },
  { symbol: 'Kitap', meaning: 'Bilgi, öğrenme, hikaye ve yaşam dersleri. Keşfetmeniz gereken bilgileri simgeler.', category: 'OBJECTS' as SymbolCategory },
  { symbol: 'Kapı', meaning: 'Fırsatlar, geçişler, gizem ve yeni başlangıçlar. Açılmayı bekleyen olanakları gösterir.', category: 'OBJECTS' as SymbolCategory },
  { symbol: 'Telefon', meaning: 'İletişim, bağlantı, mesaj ve sosyal ilişkiler. Önemli iletişim ihtiyacını temsil eder.', category: 'OBJECTS' as SymbolCategory },
  { symbol: 'Para', meaning: 'Değer, güç, güvenlik ve özgüven. Kişisel değerinizi ve gücünüzü simgeler.', category: 'OBJECTS' as SymbolCategory },
  { symbol: 'Çanta', meaning: 'Kişisel eşyalar, kimlik, sorumluluklar ve yaşam bagajı. Taşıdığınız yükleri temsil eder.', category: 'OBJECTS' as SymbolCategory },

  // EMOTIONS  
  { symbol: 'Korku', meaning: 'Bilinmeyen, değişim direnci, güvensizlik ve kaygı. Yüzleşmeniz gereken korkuları gösterir.', category: 'EMOTIONS' as SymbolCategory },
  { symbol: 'Sevinç', meaning: 'İç huzur, başarı, tatmin ve pozitif enerji. Ruhsal dengenizi ve mutluluğunuzu yansıtır.', category: 'EMOTIONS' as SymbolCategory },
  { symbol: 'Öfke', meaning: 'Bastırılmış duygular, adaletsizlik, güç mücadelesi ve sınırlar. Öfkenizin kaynağını araştırın.', category: 'EMOTIONS' as SymbolCategory },
  { symbol: 'Üzüntü', meaning: 'Kayıp, yas, değişim ve duygusal temizlik. İyileşme sürecinin bir parçasıdır.', category: 'EMOTIONS' as SymbolCategory },
  { symbol: 'Aşk', meaning: 'Bağlantı, birlik, şefkat ve ruhsal bütünlük. İçinizdeki sevgi enerjisini temsil eder.', category: 'EMOTIONS' as SymbolCategory },

  // ACTIONS
  { symbol: 'Uçmak', meaning: 'Özgürlük, sınırları aşma, manevi yücelik ve rüyalara ulaşma. Potansiyelinizi keşfetme zamanı.', category: 'ACTIONS' as SymbolCategory },
  { symbol: 'Düşmek', meaning: 'Kontrol kaybı, başarısızlık korkusu, güvensizlik ve yer çekimi. Desteklenme ihtiyacını gösterir.', category: 'ACTIONS' as SymbolCategory },
  { symbol: 'Koşmak', meaning: 'Kaçış, acele, hedeflere ulaşma çabası veya bir şeyden kurtulma. Hareket ihtiyacını simgeler.', category: 'ACTIONS' as SymbolCategory },
  { symbol: 'Aramak', meaning: 'Arayış, kayıp, ihtiyaç ve ruhsal arama. Eksik olan bir şeyi bulmaya çalışıyorsunuz.', category: 'ACTIONS' as SymbolCategory },
  { symbol: 'Dans etmek', meaning: 'Ritim, uyum, yaratıcılık ve yaşam enerjisi. İçinizdeki neşe ve canlılığı temsil eder.', category: 'ACTIONS' as SymbolCategory },

  // PLACES
  { symbol: 'Okul', meaning: 'Öğrenme, gelişim, geçmiş deneyimler ve yaşam dersleri. Hala öğrenmeniz gereken şeyler vardır.', category: 'PLACES' as SymbolCategory },
  { symbol: 'Hastane', meaning: 'İyileşme, sağlık, bakım ve yardım alma. Fiziksel ya da duygusal iyileşme süreci.', category: 'PLACES' as SymbolCategory },
  { symbol: 'Kilise/Cami', meaning: 'Maneviyat, inançlar, kutsal alan ve ruhsal arayış. İç huzur ve anlam arayışını gösterir.', category: 'PLACES' as SymbolCategory },
  { symbol: 'Orman', meaning: 'Bilinmeyen, doğal güdüler, gizem ve keşif. İçinizdeki vahşi ve doğal yanları temsil eder.', category: 'PLACES' as SymbolCategory },
  { symbol: 'Plaj', meaning: 'Rahatlama, tatil, sınır ve geçiş. Bilinçli ve bilinçsız arasındaki sınırı simgeler.', category: 'PLACES' as SymbolCategory },

  // COLORS
  { symbol: 'Kırmızı', meaning: 'Tutku, enerji, öfke, güç ve yaşam gücü. Güçlü duygusal durumları temsil eder.', category: 'COLORS' as SymbolCategory },
  { symbol: 'Mavi', meaning: 'Huzur, sakinlik, iletişim ve maneviyat. İç barışı ve dengeyi simgeler.', category: 'COLORS' as SymbolCategory },
  { symbol: 'Yeşil', meaning: 'Büyüme, doğa, şifa ve yenilenme. Umut ve tazelenmini temsil eder.', category: 'COLORS' as SymbolCategory },
  { symbol: 'Sarı', meaning: 'Neşe, aydınlanma, zeka ve yaratıcılık. Mental berraklığı ve optimizmi gösterir.', category: 'COLORS' as SymbolCategory },
  { symbol: 'Siyah', meaning: 'Gizem, bilinmeyen, yas veya dönüşüm. Gölge yönlerinizi veya yeni başlangıçları simgeler.', category: 'COLORS' as SymbolCategory },
  { symbol: 'Beyaz', meaning: 'Saflık, temizlik, masumiyet ve ruhsal aydınlanma. Yeni bir sayfa açmayı temsil eder.', category: 'COLORS' as SymbolCategory },
  { symbol: 'Mor', meaning: 'Maneviyat, sezgi, dönüşüm ve gizem. Ruhsal gelişiminizi ve içgörülerinizi simgeler.', category: 'COLORS' as SymbolCategory },

  // NUMBERS
  { symbol: 'Bir (1)', meaning: 'Birlik, başlangıç, liderlik ve bağımsızlık. Yeni bir dönemin başlangıcını işaret eder.', category: 'NUMBERS' as SymbolCategory },
  { symbol: 'İki (2)', meaning: 'İkili, denge, işbirliği ve karşıtlıklar. İlişkilerde denge kurma zamanıdır.', category: 'NUMBERS' as SymbolCategory },
  { symbol: 'Üç (3)', meaning: 'Yaratıcılık, üçlü birlik, büyüme ve ifade. Yaratıcı potansiyelinizi ortaya çıkarın.', category: 'NUMBERS' as SymbolCategory },
  { symbol: 'Yedi (7)', meaning: 'Manevi mükemmellik, şans, gizem ve tamamlanma. Ruhsal gelişim dönemini simgeler.', category: 'NUMBERS' as SymbolCategory },

  // SPIRITUAL
  { symbol: 'Melek', meaning: 'Koruyucu güç, rehberlik, maneviyat ve yüksek destek. İlahi korumanın varlığını gösterir.', category: 'SPIRITUAL' as SymbolCategory },
  { symbol: 'Haç', meaning: 'İnanç, kurban, denge ve ruhsal koruma. Manevi yolculuğunuzu temsil eder.', category: 'SPIRITUAL' as SymbolCategory },
  { symbol: 'Kristal', meaning: 'Berraklık, şifa, enerji ve ruhsal güç. İç görünüzün netleştiğini gösterir.', category: 'SPIRITUAL' as SymbolCategory },
  { symbol: 'Mandala', meaning: 'Bütünlük, denge, merkez ve kozmik düzen. Ruhsal dengenizi arayışınızı simgeler.', category: 'SPIRITUAL' as SymbolCategory },
];

async function main() {
  console.log('🌙 Rüya günlüğü veritabanı tohumlama işlemi başlatılıyor...');

  try {
    // Test kullanıcısı oluştur (john@doe.com)
    const hashedPassword = await bcryptjs.hash('johndoe123', 10);
    
    const testUser = await prisma.user.upsert({
      where: { email: 'john@doe.com' },
      update: {},
      create: {
        email: 'john@doe.com',
        name: 'Test Kullanıcısı',
        password: hashedPassword,
        bio: 'Rüya günlüğü test kullanıcısı',
        isPremium: true, // Admin yetkisi için premium yapalım
        dreamCount: 0,
      },
    });

    console.log(`✅ Test kullanıcısı oluşturuldu: ${testUser.email}`);

    // Rüya sembolleri oluştur
    let createdSymbols = 0;
    
    for (const symbolData of dreamSymbols) {
      await prisma.dreamSymbol.upsert({
        where: { symbol: symbolData.symbol },
        update: {},
        create: symbolData,
      });
      createdSymbols++;
    }

    console.log(`✅ ${createdSymbols} rüya sembolü eklendi`);

    // İstatistikler
    const totalUsers = await prisma.user.count();
    const totalSymbols = await prisma.dreamSymbol.count();

    console.log('📊 Tohumlama işlemi tamamlandı!');
    console.log(`   Toplam kullanıcı: ${totalUsers}`);
    console.log(`   Toplam rüya sembolü: ${totalSymbols}`);

  } catch (error) {
    console.error('❌ Tohumlama işleminde hata:', error);
    throw error;
  }
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
