import 'dotenv/config';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function makeAdmin() {
  try {
    const email = 'nkontas@hotmail.com';
    
    // Önce kullanıcıyı kontrol et
    const user = await prisma.user.findUnique({
      where: { email },
      select: { id: true, email: true, name: true, isAdmin: true }
    });
    
    if (!user) {
      console.log('❌ Kullanıcı bulunamadı:', email);
      return;
    }
    
    console.log('📋 Mevcut durum:');
    console.log(JSON.stringify(user, null, 2));
    
    if (user.isAdmin) {
      console.log('✅ Kullanıcı zaten admin!');
      return;
    }
    
    // Admin yap
    const updated = await prisma.user.update({
      where: { email },
      data: { isAdmin: true },
      select: { id: true, email: true, name: true, isAdmin: true }
    });
    
    console.log('\n✅ Kullanıcı admin yapıldı:');
    console.log(JSON.stringify(updated, null, 2));
    
  } catch (error) {
    console.error('❌ Hata:', error);
  } finally {
    await prisma.$disconnect();
  }
}

makeAdmin();
