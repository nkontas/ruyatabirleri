
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { redirect } from 'next/navigation';
import CommunityPage from '@/components/dashboard/community-page';

export default async function CommunityDashboardPage() {
  const session = await getServerSession(authOptions);

  if (!session) {
    redirect('/auth/giris');
  }

  return <CommunityPage />;
}
