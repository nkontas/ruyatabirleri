"use client";

import { useState, useEffect, useRef } from "react";
import { useSession } from "next-auth/react";
import { useParams, useRouter } from "next/navigation";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { UserAvatar } from "@/components/user-avatar";
import { Loader2, Send, ArrowLeft, User } from "lucide-react";
import { toast } from "react-hot-toast";
import Link from "next/link";

interface Message {
  id: string;
  content: string;
  senderId: string;
  createdAt: string;
  sender: {
    id: string;
    name: string | null;
    username: string | null;
    image: string | null;
  };
}

export default function MessageDetailPage() {
  const router = useRouter();
  const params = useParams();
  const userId = params?.userId as string;
  const { data: session, status } = useSession() || {};
  const [loading, setLoading] = useState(true);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [sending, setSending] = useState(false);
  const [otherUser, setOtherUser] = useState<any>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (status === "authenticated" && userId) {
      fetchMessages();
      fetchUserInfo();
      
      // Poll for new messages every 5 seconds
      const interval = setInterval(fetchMessages, 5000);
      return () => clearInterval(interval);
    }
  }, [status, userId]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const fetchUserInfo = async () => {
    try {
      const response = await fetch(`/api/user/${userId}`);
      if (response.ok) {
        const data = await response.json();
        setOtherUser(data);
      }
    } catch (error) {
      console.error("Kullanıcı bilgisi yükleme hatası:", error);
    }
  };

  const fetchMessages = async () => {
    try {
      const response = await fetch(`/api/messages/${userId}`);
      
      if (!response.ok) {
        throw new Error("Mesajlar yüklenemedi");
      }

      const data = await response.json();
      setMessages(data.messages || []);
    } catch (error: any) {
      console.error("Mesaj yükleme hatası:", error);
      if (loading) {
        toast.error(error.message || "Mesajlar yüklenirken hata oluştu");
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newMessage.trim()) return;

    setSending(true);
    try {
      const response = await fetch("/api/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          receiverId: userId,
          content: newMessage.trim(),
        }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || "Mesaj gönderilemedi");
      }

      setNewMessage("");
      fetchMessages();
    } catch (error: any) {
      toast.error(error.message || "Mesaj gönderilirken hata oluştu");
    } finally {
      setSending(false);
    }
  };

  if (loading || status === "loading") {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-purple-600" />
      </div>
    );
  }

  return (
    <div className="container max-w-4xl mx-auto px-4 py-8">
      <Card className="h-[calc(100vh-12rem)]">
        <CardHeader className="border-b">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => router.push("/dashboard/mesajlar")}
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>

            {otherUser ? (
              <Link 
                href={`/dashboard/kullanici/${otherUser.id}`}
                className="flex items-center gap-3 flex-1 hover:bg-muted/50 rounded-md p-2 -ml-2 transition-colors"
              >
                <UserAvatar 
                  image={otherUser.image}
                  name={otherUser.name || otherUser.username}
                  className="w-10 h-10"
                />
                <div className="flex-1 min-w-0">
                  <p className="font-semibold truncate">
                    {otherUser.name || otherUser.username}
                  </p>
                  {otherUser.username && (
                    <p className="text-xs text-muted-foreground truncate">
                      @{otherUser.username}
                    </p>
                  )}
                </div>
              </Link>
            ) : (
              <div className="flex items-center gap-3">
                <Avatar className="w-10 h-10">
                  <AvatarFallback>
                    <User className="h-5 w-5" />
                  </AvatarFallback>
                </Avatar>
                <p className="font-semibold">Mesajlar</p>
              </div>
            )}
          </div>
        </CardHeader>

        <CardContent className="flex flex-col h-[calc(100%-5rem)] p-0">
          {/* Messages List */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.length === 0 ? (
              <div className="flex items-center justify-center h-full">
                <p className="text-muted-foreground">
                  Henüz mesaj yok. İlk mesajı gönderin!
                </p>
              </div>
            ) : (
              messages.map((message) => {
                const isOwn = message.senderId === session?.user?.id;
                return (
                  <div
                    key={message.id}
                    className={`flex gap-2 ${isOwn ? "flex-row-reverse" : "flex-row"}`}
                  >
                    <UserAvatar 
                      image={message.sender.image}
                      name={message.sender.name || message.sender.username}
                      className="w-8 h-8 flex-shrink-0"
                    />

                    <div
                      className={`max-w-[70%] rounded-lg px-4 py-2 ${
                        isOwn
                          ? "bg-purple-600 text-white"
                          : "bg-muted"
                      }`}
                    >
                      <p className="text-sm break-words">{message.content}</p>
                      <p
                        className={`text-xs mt-1 ${
                          isOwn ? "text-purple-100" : "text-muted-foreground"
                        }`}
                      >
                        {new Date(message.createdAt).toLocaleTimeString("tr-TR", {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </p>
                    </div>
                  </div>
                );
              })
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Message Input */}
          <form
            onSubmit={handleSendMessage}
            className="border-t p-4 flex gap-2"
          >
            <Input
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="Mesajınızı yazın..."
              disabled={sending}
              className="flex-1"
            />
            <Button
              type="submit"
              disabled={!newMessage.trim() || sending}
              className="bg-purple-600 hover:bg-purple-700"
            >
              {sending ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Send className="h-4 w-4" />
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
