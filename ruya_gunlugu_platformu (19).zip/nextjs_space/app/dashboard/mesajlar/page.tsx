"use client";

import { useState, useEffect } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { UserAvatar } from "@/components/user-avatar";
import { Badge } from "@/components/ui/badge";
import { Loader2, MessageCircle, ArrowLeft } from "lucide-react";
import { toast } from "react-hot-toast";
import Link from "next/link";

interface Conversation {
  user: {
    id: string;
    name: string | null;
    username: string | null;
    image: string | null;
  };
  lastMessage: {
    id: string;
    content: string;
    createdAt: string;
    senderId: string;
  };
  unreadCount: number;
}

export default function MessagesListPage() {
  const router = useRouter();
  const { data: session, status } = useSession() || {};
  const [loading, setLoading] = useState(true);
  const [conversations, setConversations] = useState<Conversation[]>([]);

  useEffect(() => {
    if (status === "authenticated") {
      fetchConversations();
    }
  }, [status]);

  const fetchConversations = async () => {
    try {
      const response = await fetch("/api/messages");
      
      if (!response.ok) {
        throw new Error("Konuşmalar yüklenemedi");
      }

      const data = await response.json();
      setConversations(data.conversations || []);
    } catch (error: any) {
      console.error("Konuşma yükleme hatası:", error);
      toast.error(error.message || "Konuşmalar yüklenirken hata oluştu");
    } finally {
      setLoading(false);
    }
  };

  if (loading || status === "loading") {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-purple-600" />
      </div>
    );
  }

  return (
    <div className="container max-w-4xl mx-auto px-4 py-8">
      <Button
        variant="ghost"
        onClick={() => router.push("/dashboard")}
        className="mb-4 hover:bg-purple-100 dark:hover:bg-purple-900/20"
      >
        <ArrowLeft className="mr-2 h-4 w-4" />
        Ana Menüye Dön
      </Button>

      <h1 className="text-3xl font-bold mb-8 bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
        Mesajlar
      </h1>

      {conversations.length === 0 ? (
        <Card>
          <CardContent className="pt-6">
            <div className="text-center py-12">
              <MessageCircle className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-muted-foreground mb-4">
                Henüz mesajınız yok
              </p>
              <p className="text-sm text-muted-foreground">
                Arkadaşlarınızla mesajlaşmaya başlayın
              </p>
              <Link href="/dashboard/arkadaslar">
                <Button className="mt-4">
                  Arkadaşlarıma Git
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {conversations.map((conversation) => (
            <Link 
              key={conversation.user.id} 
              href={`/dashboard/mesajlar/${conversation.user.id}`}
            >
              <Card className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardContent className="pt-6">
                  <div className="flex items-start gap-4">
                    <UserAvatar 
                      image={conversation.user.image}
                      name={conversation.user.name || conversation.user.username}
                      className="w-14 h-14"
                    />

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <h3 className="font-semibold truncate">
                          {conversation.user.name || conversation.user.username}
                        </h3>
                        {conversation.unreadCount > 0 && (
                          <Badge className="bg-purple-600">
                            {conversation.unreadCount}
                          </Badge>
                        )}
                      </div>
                      {conversation.user.username && (
                        <p className="text-xs text-muted-foreground mb-2">
                          @{conversation.user.username}
                        </p>
                      )}
                      <p className="text-sm text-muted-foreground truncate">
                        {conversation.lastMessage.senderId === session?.user?.id && "Siz: "}
                        {conversation.lastMessage.content}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {new Date(conversation.lastMessage.createdAt).toLocaleDateString("tr-TR", {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
