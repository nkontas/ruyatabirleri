
'use client';

import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { UserPlus, UserCheck, UserX, MessageCircle, ArrowLeft, Users, BookOpen } from 'lucide-react';
import { toast } from 'react-hot-toast';
import Link from 'next/link';
import { UserAvatar } from '@/components/user-avatar';

interface User {
  id: string;
  name: string | null;
  username: string | null;
  email: string | null;
  image: string | null;
  bio: string | null;
  createdAt: string;
  _count: {
    dreams: number;
    sentFriendRequests: number;
    receivedFriendRequests: number;
  };
}

interface Dream {
  id: string;
  title: string;
  content: string;
  mood: string | null;
  isPublic: boolean;
  createdAt: string;
  likesCount: number;
  commentsCount: number;
  isLiked: boolean;
}

interface PageProps {
  params: {
    userId: string;
  };
}

export default function UserProfilePage({ params }: PageProps) {
  const userId = params.userId;
  const { data: session, status } = useSession() || {};
  const router = useRouter();
  const [user, setUser] = useState<User | null>(null);
  const [dreams, setDreams] = useState<Dream[]>([]);
  const [loading, setLoading] = useState(true);
  const [friendStatus, setFriendStatus] = useState<'none' | 'friend' | 'pending_sent' | 'pending_received'>('none');

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/auth/signin');
    }
  }, [status, router]);

  useEffect(() => {
    if (session?.user && userId) {
      fetchUserProfile();
      fetchUserDreams();
      checkFriendStatus();
    }
  }, [session, userId]);

  const fetchUserProfile = async () => {
    try {
      const response = await fetch(`/api/users/${userId}`);
      if (response.ok) {
        const data = await response.json();
        setUser(data.user);
      } else {
        toast.error('Kullanıcı bulunamadı');
        router.push('/dashboard/friends');
      }
    } catch (error) {
      console.error('Error fetching user:', error);
      toast.error('Kullanıcı bilgileri yüklenemedi');
    } finally {
      setLoading(false);
    }
  };

  const fetchUserDreams = async () => {
    try {
      const response = await fetch(`/api/users/${userId}/dreams`);
      if (response.ok) {
        const data = await response.json();
        setDreams(data.dreams || []);
      }
    } catch (error) {
      console.error('Error fetching dreams:', error);
    }
  };

  const checkFriendStatus = async () => {
    try {
      const response = await fetch(`/api/friendship/status?userId=${userId}`);
      if (response.ok) {
        const data = await response.json();
        setFriendStatus(data.status);
      }
    } catch (error) {
      console.error('Error checking friend status:', error);
    }
  };

  const sendFriendRequest = async () => {
    try {
      const response = await fetch('/api/friendship/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ receiverId: userId }),
      });

      if (response.ok) {
        toast.success('Arkadaşlık isteği gönderildi');
        setFriendStatus('pending_sent');
      } else {
        const error = await response.json();
        toast.error(error.error || 'İstek gönderilemedi');
      }
    } catch (error) {
      console.error('Error sending friend request:', error);
      toast.error('İstek gönderilemedi');
    }
  };

  const removeFriend = async () => {
    if (!confirm('Bu arkadaşınızı silmek istediğinizden emin misiniz?')) return;

    try {
      const response = await fetch('/api/friendship/remove', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ friendId: userId }),
      });

      if (response.ok) {
        toast.success('Arkadaş silindi');
        setFriendStatus('none');
      } else {
        toast.error('Silme işlemi başarısız oldu');
      }
    } catch (error) {
      console.error('Error removing friend:', error);
      toast.error('Silme işlemi başarısız oldu');
    }
  };

  const toggleLike = async (dreamId: string) => {
    try {
      const response = await fetch('/api/community/like', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ dreamId }),
      });

      if (response.ok) {
        setDreams((prev) =>
          prev.map((dream) =>
            dream.id === dreamId
              ? {
                  ...dream,
                  isLiked: !dream.isLiked,
                  likesCount: dream.isLiked ? dream.likesCount - 1 : dream.likesCount + 1,
                }
              : dream
          )
        );
      }
    } catch (error) {
      console.error('Error toggling like:', error);
    }
  };

  if (status === 'loading' || loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto mb-4"></div>
          <p className="text-gray-400">Yükleniyor...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const isOwnProfile = user.id === session?.user?.id;

  return (
    <div className="container max-w-6xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-6">
        <Link href="/dashboard/friends">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-pink-600 bg-clip-text text-transparent">
          Kullanıcı Profili
        </h1>
      </div>

      <Card className="p-6 bg-gradient-to-br from-gray-800/50 to-gray-900/50 border-gray-700 mb-6">
        <div className="flex flex-col md:flex-row items-start gap-6">
          <Link href={`/dashboard/kullanici/${user.id}`}>
            <UserAvatar
              image={user.image}
              name={user.name || user.username || 'User'}
              className="w-24 h-24 border-4 border-purple-500/50 cursor-pointer hover:border-purple-400/70 transition-colors"
            />
          </Link>

          <div className="flex-1 space-y-4">
            <div>
              <Link href={`/dashboard/kullanici/${user.id}`}>
                <h2 className="text-2xl font-bold text-white hover:text-purple-400 transition-colors cursor-pointer">{user.name || user.username}</h2>
              </Link>
              {user.username && user.name && (
                <p className="text-gray-400">@{user.username}</p>
              )}
              {user.bio && (
                <p className="text-gray-300 mt-2">{user.bio}</p>
              )}
            </div>

            <div className="flex flex-wrap gap-4 text-sm">
              <div className="flex items-center gap-2">
                <BookOpen className="h-4 w-4 text-purple-400" />
                <span className="text-gray-400">
                  <span className="font-semibold text-white">{user._count.dreams}</span> rüya
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Users className="h-4 w-4 text-purple-400" />
                <span className="text-gray-400">
                  <span className="font-semibold text-white">
                    {user._count.sentFriendRequests + user._count.receivedFriendRequests}
                  </span>{' '}
                  arkadaş
                </span>
              </div>
            </div>

            {!isOwnProfile && (
              <div className="flex flex-wrap gap-3">
                {friendStatus === 'none' && (
                  <Button onClick={sendFriendRequest} className="bg-purple-600 hover:bg-purple-700">
                    <UserPlus className="h-4 w-4 mr-2" />
                    Arkadaş Ekle
                  </Button>
                )}

                {friendStatus === 'pending_sent' && (
                  <Button disabled variant="ghost" className="text-gray-400">
                    İstek Gönderildi
                  </Button>
                )}

                {friendStatus === 'pending_received' && (
                  <Button onClick={sendFriendRequest} className="bg-green-600 hover:bg-green-700">
                    <UserCheck className="h-4 w-4 mr-2" />
                    İsteği Kabul Et
                  </Button>
                )}

                {friendStatus === 'friend' && (
                  <>
                    <Link href={`/dashboard/mesajlar/${user.id}`}>
                      <Button className="bg-blue-600 hover:bg-blue-700">
                        <MessageCircle className="h-4 w-4 mr-2" />
                        Mesaj Gönder
                      </Button>
                    </Link>
                    <Button
                      onClick={removeFriend}
                      variant="ghost"
                      className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                    >
                      <UserX className="h-4 w-4 mr-2" />
                      Arkadaşlıktan Çıkar
                    </Button>
                  </>
                )}
              </div>
            )}

            {isOwnProfile && (
              <Link href="/dashboard/settings">
                <Button className="bg-purple-600 hover:bg-purple-700">
                  Profili Düzenle
                </Button>
              </Link>
            )}
          </div>
        </div>
      </Card>

      <Tabs defaultValue="dreams" className="space-y-6">
        <TabsList className="grid w-full grid-cols-1 bg-gray-800/50">
          <TabsTrigger value="dreams" className="data-[state=active]:bg-purple-600">
            <BookOpen className="h-4 w-4 mr-2" />
            Paylaşılan Rüyalar ({dreams.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="dreams" className="space-y-4">
          {dreams.length === 0 ? (
            <Card className="p-8 text-center bg-gray-800/30 border-gray-700">
              <BookOpen className="h-12 w-12 mx-auto mb-4 text-gray-500" />
              <p className="text-gray-400">
                {isOwnProfile
                  ? 'Henüz paylaşılmış rüyanız yok'
                  : 'Bu kullanıcı henüz rüya paylaşmamış'}
              </p>
            </Card>
          ) : (
            <div className="grid gap-6">
              {dreams.map((dream) => (
                <Card
                  key={dream.id}
                  className="p-6 bg-gradient-to-br from-gray-800/50 to-gray-900/50 border-gray-700 hover:border-purple-500/50 transition-all"
                >
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-xl font-semibold text-white mb-2">{dream.title}</h3>
                      <p className="text-gray-300 line-clamp-3">{dream.content}</p>
                    </div>

                    {dream.mood && (
                      <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/30">
                        <span className="text-sm text-purple-300">Ruh Hali: {dream.mood}</span>
                      </div>
                    )}

                    <div className="flex items-center justify-between pt-4 border-t border-gray-700">
                      <div className="flex items-center gap-4 text-sm text-gray-400">
                        <button
                          onClick={() => toggleLike(dream.id)}
                          className={`flex items-center gap-1 transition-colors ${
                            dream.isLiked ? 'text-red-400' : 'hover:text-red-400'
                          }`}
                        >
                          <span>{dream.isLiked ? '❤️' : '🤍'}</span>
                          <span>{dream.likesCount}</span>
                        </button>
                        <span className="flex items-center gap-1">
                          💬 {dream.commentsCount}
                        </span>
                        <span className="text-xs">
                          {new Date(dream.createdAt).toLocaleDateString('tr-TR', {
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric',
                          })}
                        </span>
                      </div>

                      <Link href={`/dashboard/ruya/${dream.id}`}>
                        <Button size="sm" variant="ghost" className="text-purple-400 hover:text-purple-300">
                          Detay
                        </Button>
                      </Link>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
