"use client";

import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import SymbolsPage from "@/components/symbols-page";
import { Loader2 } from "lucide-react";

export default function SembollerPage() {
  const { data: session, status } = useSession() || {};
  const router = useRouter();
  const [symbolsByCategory, setSymbolsByCategory] = useState({});
  const [loading, setLoading] = useState(true);
  const [initialized, setInitialized] = useState(false);

  useEffect(() => {
    if (status === "unauthenticated") {
      router.push("/auth/giris");
    }
  }, [status, router]);

  useEffect(() => {
    const initSymbols = async () => {
      try {
        // First, seed the database if needed
        if (!initialized) {
          await fetch("/api/symbols/seed", { method: "POST" });
          setInitialized(true);
        }

        // Then fetch the symbols
        const response = await fetch("/api/symbols");
        if (response.ok) {
          const data = await response.json();
          setSymbolsByCategory(data);
        }
      } catch (error) {
        console.error("Semboller yüklenirken hata:", error);
      } finally {
        setLoading(false);
      }
    };

    if (status === "authenticated") {
      initSymbols();
    }
  }, [status, initialized]);

  if (status === "loading" || loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
        <Loader2 className="h-8 w-8 animate-spin text-purple-300" />
      </div>
    );
  }

  if (status === "unauthenticated") {
    return null;
  }

  return <SymbolsPage symbolsByCategory={symbolsByCategory} />;
}
