
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { redirect } from 'next/navigation';
import AnalysisPage from '@/components/dashboard/analysis-page';

export default async function AnalizPage() {
  const session = await getServerSession(authOptions);

  if (!session) {
    redirect('/auth/giris');
  }

  return <AnalysisPage />;
}
