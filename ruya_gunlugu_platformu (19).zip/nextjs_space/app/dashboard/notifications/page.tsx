
'use client';

import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Bell, Heart, MessageCircle, UserPlus, Check, Trash2, ArrowLeft } from 'lucide-react';
import { toast } from 'react-hot-toast';
import Link from 'next/link';
import { formatDistanceToNow } from 'date-fns';
import { tr } from 'date-fns/locale';

interface Notification {
  id: string;
  type: string;
  title: string;
  message: string;
  link: string | null;
  isRead: boolean;
  createdAt: string;
  fromUser: {
    id: string;
    name: string | null;
    username: string | null;
    image: string | null;
  } | null;
}

export default function NotificationsPage() {
  const { data: session, status } = useSession() || {};
  const router = useRouter();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'unread'>('all');

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/auth/signin');
    }
  }, [status, router]);

  useEffect(() => {
    if (session?.user) {
      fetchNotifications();
    }
  }, [session]);

  const fetchNotifications = async () => {
    try {
      const response = await fetch('/api/notifications');
      if (response.ok) {
        const data = await response.json();
        setNotifications(data.notifications || []);
      }
    } catch (error) {
      console.error('Error fetching notifications:', error);
    } finally {
      setLoading(false);
    }
  };

  const markAsRead = async (notificationId: string) => {
    try {
      const response = await fetch('/api/notifications/read', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ notificationId }),
      });

      if (response.ok) {
        setNotifications((prev) =>
          prev.map((n) => (n.id === notificationId ? { ...n, isRead: true } : n))
        );
      }
    } catch (error) {
      console.error('Error marking notification as read:', error);
    }
  };

  const markAllAsRead = async () => {
    try {
      const response = await fetch('/api/notifications/read-all', {
        method: 'POST',
      });

      if (response.ok) {
        setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
        toast.success('Tüm bildirimler okundu olarak işaretlendi');
      }
    } catch (error) {
      console.error('Error marking all as read:', error);
      toast.error('İşlem başarısız oldu');
    }
  };

  const deleteNotification = async (notificationId: string) => {
    try {
      const response = await fetch('/api/notifications/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ notificationId }),
      });

      if (response.ok) {
        setNotifications((prev) => prev.filter((n) => n.id !== notificationId));
        toast.success('Bildirim silindi');
      }
    } catch (error) {
      console.error('Error deleting notification:', error);
      toast.error('Silme işlemi başarısız oldu');
    }
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'LIKE':
        return <Heart className="h-5 w-5 text-red-400" />;
      case 'COMMENT':
        return <MessageCircle className="h-5 w-5 text-blue-400" />;
      case 'FRIEND_REQUEST':
      case 'FRIEND_ACCEPTED':
        return <UserPlus className="h-5 w-5 text-green-400" />;
      default:
        return <Bell className="h-5 w-5 text-purple-400" />;
    }
  };

  const filteredNotifications = notifications.filter((n) =>
    filter === 'all' ? true : !n.isRead
  );

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  if (status === 'loading' || loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto mb-4"></div>
          <p className="text-gray-400">Yükleniyor...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container max-w-4xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-6">
        <Link href="/dashboard">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <div className="flex-1">
          <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-pink-600 bg-clip-text text-transparent">
            Bildirimler
          </h1>
          {unreadCount > 0 && (
            <p className="text-sm text-gray-400 mt-1">{unreadCount} okunmamış bildirim</p>
          )}
        </div>
        {unreadCount > 0 && (
          <Button onClick={markAllAsRead} variant="outline" size="sm">
            <Check className="h-4 w-4 mr-2" />
            Tümünü Okundu İşaretle
          </Button>
        )}
      </div>

      <div className="flex gap-2 mb-6">
        <Button
          variant={filter === 'all' ? 'default' : 'outline'}
          onClick={() => setFilter('all')}
          size="sm"
        >
          Tümü ({notifications.length})
        </Button>
        <Button
          variant={filter === 'unread' ? 'default' : 'outline'}
          onClick={() => setFilter('unread')}
          size="sm"
        >
          Okunmamış ({unreadCount})
        </Button>
      </div>

      <div className="space-y-2">
        {filteredNotifications.length === 0 ? (
          <Card className="p-8 text-center bg-gray-800/30 border-gray-700">
            <Bell className="h-12 w-12 mx-auto mb-4 text-gray-500" />
            <p className="text-gray-400">
              {filter === 'unread' ? 'Okunmamış bildirim yok' : 'Henüz bildirim yok'}
            </p>
          </Card>
        ) : (
          filteredNotifications.map((notification) => (
            <Card
              key={notification.id}
              className={`p-4 transition-all ${
                notification.isRead
                  ? 'bg-gray-800/20 border-gray-700'
                  : 'bg-gray-800/40 border-purple-500/30'
              }`}
            >
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 mt-1">{getIcon(notification.type)}</div>

                {notification.fromUser && (
                  <Avatar className="h-10 w-10 border-2 border-purple-500/50 flex-shrink-0">
                    <AvatarImage src={notification.fromUser.image || undefined} />
                    <AvatarFallback className="bg-gradient-to-br from-purple-500 to-pink-500">
                      {notification.fromUser.name?.[0] ||
                        notification.fromUser.username?.[0] ||
                        'U'}
                    </AvatarFallback>
                  </Avatar>
                )}

                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-white">{notification.title}</p>
                  <p className="text-sm text-gray-400 mt-1">{notification.message}</p>
                  <p className="text-xs text-gray-500 mt-2">
                    {formatDistanceToNow(new Date(notification.createdAt), {
                      addSuffix: true,
                      locale: tr,
                    })}
                  </p>
                  {notification.link && (
                    <Link
                      href={notification.link}
                      onClick={() => !notification.isRead && markAsRead(notification.id)}
                      className="text-sm text-purple-400 hover:text-purple-300 mt-2 inline-block"
                    >
                      Görüntüle →
                    </Link>
                  )}
                </div>

                <div className="flex gap-2 flex-shrink-0">
                  {!notification.isRead && (
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => markAsRead(notification.id)}
                      className="text-green-400 hover:text-green-300 hover:bg-green-500/10"
                      title="Okundu işaretle"
                    >
                      <Check className="h-4 w-4" />
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => deleteNotification(notification.id)}
                    className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                    title="Sil"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
