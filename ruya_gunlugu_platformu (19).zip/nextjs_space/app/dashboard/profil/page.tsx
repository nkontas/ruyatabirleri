

"use client";

import { useState, useEffect } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Mail, Calendar, Crown, BookOpen, ArrowLeft } from "lucide-react";
import { toast } from "react-hot-toast";
import { ProfileImageUpload } from "@/components/profile-image-upload";

interface UserProfile {
  id: string;
  name: string | null;
  email: string;
  bio: string | null;
  age: number | null;
  gender: string | null;
  image: string | null;
  isPremium: boolean;
  showDreamCount: boolean;
  dreamCount: number;
  createdAt: string;
}

export default function ProfilPage() {
  const router = useRouter();
  const { data: session, status, update } = useSession() || {};
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    bio: "",
    showDreamCount: true,
  });

  useEffect(() => {
    if (status === "authenticated") {
      fetchProfile();
    } else if (status === "unauthenticated") {
      setLoading(false);
    }
  }, [status]);

  const fetchProfile = async () => {
    try {
      const response = await fetch("/api/user/profile");
      if (!response.ok) throw new Error("Profil yüklenemedi");
      const data = await response.json();
      setProfile(data);
      setFormData({
        name: data.name || "",
        bio: data.bio || "",
        showDreamCount: data.showDreamCount ?? true,
      });
    } catch (error) {
      console.error("Profil yükleme hatası:", error);
      toast.error("Profil bilgileri yüklenirken bir hata oluştu");
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);

    try {
      const response = await fetch("/api/user/profile", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: formData.name,
          bio: formData.bio,
          showDreamCount: formData.showDreamCount,
        }),
      });

      if (!response.ok) throw new Error("Profil güncellenemedi");

      const updatedProfile = await response.json();
      setProfile(updatedProfile);
      
      // Session'ı güncelle
      await update({
        ...session,
        user: {
          ...session?.user,
          name: updatedProfile.name,
        },
      });

      toast.success("Profil başarıyla güncellendi");
    } catch (error) {
      console.error("Profil güncelleme hatası:", error);
      toast.error("Profil güncellenirken bir hata oluştu");
    } finally {
      setSaving(false);
    }
  };

  const handleImageUpdate = async (newImagePath: string | null) => {
    setProfile(prev => prev ? { ...prev, image: newImagePath } : null);
    
    // Update session
    await update({
      ...session,
      user: {
        ...session?.user,
        image: newImagePath,
      },
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="h-8 w-8 animate-spin text-purple-600" />
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <p className="text-muted-foreground">Profil yüklenemedi</p>
      </div>
    );
  }

  const memberSince = new Date(profile.createdAt).toLocaleDateString("tr-TR", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  return (
    <div className="container max-w-4xl mx-auto px-4 py-8">
      <Button
        variant="ghost"
        onClick={() => router.push("/dashboard")}
        className="mb-4 hover:bg-purple-100 dark:hover:bg-purple-900/20"
      >
        <ArrowLeft className="mr-2 h-4 w-4" />
        Ana Menüye Dön
      </Button>
      <h1 className="text-3xl font-bold mb-8 bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
        Profilim
      </h1>

      <div className="grid gap-6 md:grid-cols-3">
        {/* Sol Kolon - Profil Kartı */}
        <Card className="md:col-span-1">
          <CardHeader>
            <CardTitle>Profil Bilgileri</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <ProfileImageUpload
              currentImage={profile.image}
              userName={profile.name}
              onImageUpdate={handleImageUpdate}
            />
              
            {profile.isPremium && (
              <div className="flex items-center justify-center gap-2 px-3 py-1 bg-gradient-to-r from-amber-500 to-yellow-500 rounded-full">
                <Crown className="h-4 w-4 text-white" />
                <span className="text-sm font-semibold text-white">Premium</span>
              </div>
            )}

            <div className="space-y-4 pt-4 border-t">
              <div className="flex items-center gap-3 text-sm">
                <Mail className="h-4 w-4 text-muted-foreground" />
                <span className="text-muted-foreground break-all">{profile.email}</span>
              </div>
              
              <div className="flex items-center gap-3 text-sm">
                <Calendar className="h-4 w-4 text-muted-foreground" />
                <span className="text-muted-foreground">Üye: {memberSince}</span>
              </div>
              
              <div className="flex items-center gap-3 text-sm">
                <BookOpen className="h-4 w-4 text-muted-foreground" />
                <span className="text-muted-foreground">
                  {profile.dreamCount} rüya kaydedildi
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Sağ Kolon - Profil Düzenleme */}
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Profili Düzenle</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="name">Ad Soyad</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) =>
                    setFormData({ ...formData, name: e.target.value })
                  }
                  placeholder="Adınızı ve soyadınızı girin"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">E-posta</Label>
                <Input
                  id="email"
                  type="email"
                  value={profile.email}
                  disabled
                  className="bg-muted"
                />
                <p className="text-xs text-muted-foreground">
                  E-posta adresi değiştirilemez
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="bio">Hakkında</Label>
                <Textarea
                  id="bio"
                  value={formData.bio}
                  onChange={(e) =>
                    setFormData({ ...formData, bio: e.target.value })
                  }
                  placeholder="Kendiniz hakkında bir şeyler yazın..."
                  rows={4}
                />
              </div>

              <Button
                type="submit"
                disabled={saving}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
              >
                {saving ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Kaydediliyor...
                  </>
                ) : (
                  "Değişiklikleri Kaydet"
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>

      {/* İstatistikler Kartı */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Rüya İstatistiklerim</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-4 bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-950/20 dark:to-pink-950/20 rounded-lg">
              <div className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                {profile.dreamCount}
              </div>
              <div className="text-sm text-muted-foreground mt-1">
                Toplam Rüya
              </div>
            </div>

            <div className="text-center p-4 bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-950/20 dark:to-cyan-950/20 rounded-lg">
              <div className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent">
                {Math.floor((Date.now() - new Date(profile.createdAt).getTime()) / (1000 * 60 * 60 * 24))}
              </div>
              <div className="text-sm text-muted-foreground mt-1">
                Aktif Gün
              </div>
            </div>

            <div className="text-center p-4 bg-gradient-to-br from-amber-50 to-orange-50 dark:from-amber-950/20 dark:to-orange-950/20 rounded-lg">
              <div className="text-3xl font-bold bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">
                {profile.isPremium ? "Premium" : "Ücretsiz"}
              </div>
              <div className="text-sm text-muted-foreground mt-1">
                Hesap Tipi
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
