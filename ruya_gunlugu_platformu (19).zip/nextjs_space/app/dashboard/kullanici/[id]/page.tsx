"use client";

import { useState, useEffect } from "react";
import { useSession } from "next-auth/react";
import { useParams, useRouter } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { UserAvatar } from "@/components/user-avatar";
import { Badge } from "@/components/ui/badge";
import { Loader2, User, Mail, Calendar, Crown, BookOpen, ArrowLeft, UserPlus, UserCheck, UserX, MessageCircle, Lock } from "lucide-react";
import { toast } from "react-hot-toast";
import Link from "next/link";

interface UserProfile {
  id: string;
  name: string | null;
  username: string | null;
  email: string | null;
  bio: string | null;
  dateOfBirth: string | null;
  gender: string | null;
  image: string | null;
  dreamCount: number | null;
  sharedDreamCount: number;
  isPremium: boolean;
  createdAt: string;
  isOwnProfile: boolean;
  isFriend: boolean;
  friendshipStatus: string | null;
  isSender: boolean;
  showAge: boolean;
  showGender: boolean;
}

export default function UserProfilePage() {
  const router = useRouter();
  const params = useParams();
  const userId = params?.id as string;
  const { data: session, status } = useSession() || {};
  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [actionLoading, setActionLoading] = useState(false);

  // Yaş hesaplama fonksiyonu
  const calculateAge = (dateOfBirth: string): number => {
    const today = new Date();
    const birthDate = new Date(dateOfBirth);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  };

  useEffect(() => {
    if (status === "authenticated" && userId) {
      fetchProfile();
    }
  }, [status, userId]);

  const fetchProfile = async () => {
    try {
      const response = await fetch(`/api/user/${userId}`);
      
      if (!response.ok) {
        const data = await response.json();
        if (response.status === 403) {
          toast.error("Bu profili görüntüleme yetkiniz yok");
          router.push("/dashboard");
          return;
        }
        throw new Error(data.error || "Profil yüklenemedi");
      }

      const data = await response.json();
      setProfile(data);
    } catch (error: any) {
      console.error("Profil yükleme hatası:", error);
      toast.error(error.message || "Profil yüklenirken hata oluştu");
    } finally {
      setLoading(false);
    }
  };

  const handleSendFriendRequest = async () => {
    setActionLoading(true);
    try {
      const response = await fetch("/api/friendship/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ receiverId: userId }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || "İstek gönderilemedi");
      }

      toast.success("Arkadaşlık isteği gönderildi");
      fetchProfile();
    } catch (error: any) {
      toast.error(error.message || "Bir hata oluştu");
    } finally {
      setActionLoading(false);
    }
  };

  const handleRespondFriendRequest = async (action: "accept" | "reject", friendshipId: string) => {
    setActionLoading(true);
    try {
      const response = await fetch("/api/friendship/respond", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ friendshipId, action }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || "İstek yanıtlanamadı");
      }

      toast.success(action === "accept" ? "Arkadaşlık isteği kabul edildi" : "Arkadaşlık isteği reddedildi");
      fetchProfile();
    } catch (error: any) {
      toast.error(error.message || "Bir hata oluştu");
    } finally {
      setActionLoading(false);
    }
  };

  if (loading || status === "loading") {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-purple-600" />
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="container max-w-4xl mx-auto px-4 py-8">
        <p className="text-center text-muted-foreground">Profil bulunamadı</p>
      </div>
    );
  }

  const joinDate = new Date(profile.createdAt).toLocaleDateString("tr-TR", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  return (
    <div className="container max-w-4xl mx-auto px-4 py-8">
      <Button
        variant="ghost"
        onClick={() => router.back()}
        className="mb-4 hover:bg-purple-100 dark:hover:bg-purple-900/20"
      >
        <ArrowLeft className="mr-2 h-4 w-4" />
        Geri Dön
      </Button>

      <div className="grid gap-6 md:grid-cols-3">
        {/* Sol Kolon - Profil Kartı */}
        <Card className="md:col-span-1">
          <CardContent className="pt-6">
            <div className="flex flex-col items-center space-y-4">
              <UserAvatar 
                image={profile.image}
                name={profile.name || profile.username}
                className="w-24 h-24"
              />

              <div className="text-center space-y-1">
                <h2 className="text-xl font-bold">{profile.name || profile.username}</h2>
                {profile.username && (
                  <p className="text-sm text-muted-foreground">@{profile.username}</p>
                )}
                {profile.isPremium && (
                  <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500">
                    <Crown className="w-3 h-3 mr-1" />
                    Premium
                  </Badge>
                )}
              </div>

              {profile.bio && (
                <p className="text-sm text-center text-muted-foreground">
                  {profile.bio}
                </p>
              )}

              {/* Arkadaşlık Durumu */}
              {!profile.isOwnProfile && (
                <div className="w-full space-y-2">
                  {profile.isFriend ? (
                    <>
                      <Button className="w-full bg-green-600 hover:bg-green-700" disabled>
                        <UserCheck className="mr-2 h-4 w-4" />
                        Arkadaşsınız
                      </Button>
                      <Link href={`/dashboard/mesajlar/${profile.id}`} className="w-full">
                        <Button variant="outline" className="w-full">
                          <MessageCircle className="mr-2 h-4 w-4" />
                          Mesaj Gönder
                        </Button>
                      </Link>
                    </>
                  ) : profile.friendshipStatus === "PENDING" ? (
                    profile.isSender ? (
                      <Button className="w-full" disabled>
                        <UserPlus className="mr-2 h-4 w-4" />
                        İstek Gönderildi
                      </Button>
                    ) : (
                      <div className="space-y-2 w-full">
                        <Button
                          className="w-full bg-green-600 hover:bg-green-700"
                          onClick={() => {
                            // We need friendshipId here, but we don't have it in the profile response
                            // We'll need to add it to the API response or fetch it separately
                            toast.error("Arkadaşlık isteğini kabul etmek için arkadaşlar sayfasını kullanın");
                          }}
                          disabled={actionLoading}
                        >
                          <UserCheck className="mr-2 h-4 w-4" />
                          Kabul Et
                        </Button>
                        <Button
                          variant="outline"
                          className="w-full"
                          disabled={actionLoading}
                        >
                          <UserX className="mr-2 h-4 w-4" />
                          Reddet
                        </Button>
                      </div>
                    )
                  ) : (
                    <Button
                      className="w-full bg-purple-600 hover:bg-purple-700"
                      onClick={handleSendFriendRequest}
                      disabled={actionLoading}
                    >
                      {actionLoading ? (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      ) : (
                        <UserPlus className="mr-2 h-4 w-4" />
                      )}
                      Arkadaşlık İsteği Gönder
                    </Button>
                  )}
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Sağ Kolon - Bilgiler */}
        <div className="md:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5" />
                Profil Bilgileri
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {profile.email && (
                <div className="flex items-center gap-2 text-sm">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  <span>{profile.email}</span>
                </div>
              )}

              {profile.showAge && profile.dateOfBirth && (
                <div className="flex items-center gap-2 text-sm">
                  <User className="h-4 w-4 text-muted-foreground" />
                  <span>Yaş: {calculateAge(profile.dateOfBirth)}</span>
                </div>
              )}

              {profile.showGender && profile.gender && (
                <div className="flex items-center gap-2 text-sm">
                  <User className="h-4 w-4 text-muted-foreground" />
                  <span>Cinsiyet: {
                    profile.gender === 'erkek' ? 'Erkek' :
                    profile.gender === 'kadin' ? 'Kadın' :
                    profile.gender === 'diger' ? 'Diğer' :
                    'Belirtilmemiş'
                  }</span>
                </div>
              )}

              <div className="flex items-center gap-2 text-sm">
                <Calendar className="h-4 w-4 text-muted-foreground" />
                <span>Katılım: {joinDate}</span>
              </div>

              {profile.dreamCount !== null && (
                <div className="flex items-center gap-2 text-sm">
                  <BookOpen className="h-4 w-4 text-muted-foreground" />
                  <span>{profile.dreamCount} Rüya Kaydı</span>
                </div>
              )}

              <div className="flex items-center gap-2 text-sm">
                <BookOpen className="h-4 w-4 text-muted-foreground" />
                <span>{profile.sharedDreamCount} Paylaşılan Rüya</span>
              </div>
            </CardContent>
          </Card>

          {/* Gizlilik Bilgisi */}
          {!profile.isOwnProfile && !profile.isFriend && (
            <Card className="border-muted">
              <CardContent className="pt-6">
                <div className="flex items-start gap-3 text-sm text-muted-foreground">
                  <Lock className="h-5 w-5 mt-0.5" />
                  <div>
                    <p className="font-medium text-foreground mb-1">
                      Sınırlı Profil Görünümü
                    </p>
                    <p>
                      Tüm profil bilgilerini görmek için arkadaş olmanız gerekebilir.
                      Kullanıcının gizlilik ayarlarına göre bazı bilgiler gizlenmiş olabilir.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
