
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { redirect } from 'next/navigation';
import AddDreamPage from '@/components/dashboard/add-dream-page';

export default async function RuyaEklePage() {
  const session = await getServerSession(authOptions);

  if (!session) {
    redirect('/auth/giris');
  }

  return <AddDreamPage />;
}
