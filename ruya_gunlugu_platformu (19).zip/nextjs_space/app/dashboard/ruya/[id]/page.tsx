
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { redirect } from 'next/navigation';
import DreamDetailPage from '@/components/dashboard/dream-detail-page';

export default async function RuyaDetayPage({ params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);

  if (!session) {
    redirect('/auth/giris');
  }

  return <DreamDetailPage dreamId={params.id} />;
}
