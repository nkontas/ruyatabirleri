
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { redirect } from 'next/navigation';
import DreamAnalyzePage from '@/components/dashboard/dream-analyze-page';

export default async function RuyaAnalizPage({ params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);

  if (!session) {
    redirect('/auth/giris');
  }

  return <DreamAnalyzePage dreamId={params.id} />;
}
