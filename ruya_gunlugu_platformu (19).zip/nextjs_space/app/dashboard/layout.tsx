
import Link from 'next/link';

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-screen flex flex-col">
      <div className="flex-1">{children}</div>
      
      {/* Footer */}
      <footer className="border-t border-white/10 bg-card/50 backdrop-blur-sm mt-auto">
        <div className="container mx-auto px-4 sm:px-6 py-4 sm:py-6">
          <div className="text-center text-muted-foreground">
            <div className="flex justify-center gap-4 sm:gap-6 mb-2 sm:mb-3">
              <Link 
                href="/hakkimizda" 
                className="text-xs sm:text-sm hover:text-foreground transition-colors"
              >
                Hakkımızda
              </Link>
              <Link 
                href="/iletisim" 
                className="text-xs sm:text-sm hover:text-foreground transition-colors"
              >
                İletişim
              </Link>
            </div>
            <p className="text-[10px] sm:text-xs">&copy; 2024 Rüya Günlüğüm. Tüm hakları saklıdır.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
