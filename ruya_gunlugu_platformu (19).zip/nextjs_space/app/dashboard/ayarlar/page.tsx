
"use client";

import { useState, useEffect } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Loader2, User, Bell, Lock, Trash2, Crown, Shield, ArrowLeft } from "lucide-react";
import { toast } from "react-hot-toast";
import { ProfileImageUpload } from "@/components/profile-image-upload";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface UserSettings {
  id: string;
  name: string | null;
  email: string;
  bio: string | null;
  dateOfBirth: string | null;
  gender: string | null;
  image: string | null;
  isPremium: boolean;
  showDreamCount: boolean;
  showBio: boolean;
  showAge: boolean;
  showGender: boolean;
  emailNotifications: boolean;
  dreamReminders: boolean;
  communityNotifications: boolean;
  theme: string;
}

export default function AyarlarPage() {
  const router = useRouter();
  const { data: session, status, update } = useSession() || {};
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [settings, setSettings] = useState<UserSettings | null>(null);
  const [activeTab, setActiveTab] = useState("profil");
  
  const [profileData, setProfileData] = useState({
    name: "",
    bio: "",
    dateOfBirth: "",
    gender: "",
    showDreamCount: true,
    showBio: true,
    showAge: false,
    showGender: false,
  });

  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });

  const [notificationSettings, setNotificationSettings] = useState({
    emailNotifications: true,
    dreamReminders: true,
    communityNotifications: true,
  });

  useEffect(() => {
    if (status === "authenticated") {
      fetchSettings();
    } else if (status === "unauthenticated") {
      setLoading(false);
    }
  }, [status]);

  const fetchSettings = async () => {
    try {
      const response = await fetch("/api/user/settings");
      if (!response.ok) throw new Error("Ayarlar yüklenemedi");
      const data = await response.json();
      setSettings(data);
      setProfileData({
        name: data.name || "",
        bio: data.bio || "",
        dateOfBirth: data.dateOfBirth ? new Date(data.dateOfBirth).toISOString().split('T')[0] : "",
        gender: data.gender || "",
        showDreamCount: data.showDreamCount ?? true,
        showBio: data.showBio ?? true,
        showAge: data.showAge ?? false,
        showGender: data.showGender ?? false,
      });
      setNotificationSettings({
        emailNotifications: data.emailNotifications ?? true,
        dreamReminders: data.dreamReminders ?? true,
        communityNotifications: data.communityNotifications ?? true,
      });
    } catch (error) {
      console.error("Ayarlar yükleme hatası:", error);
      toast.error("Ayarlar yüklenirken bir hata oluştu");
    } finally {
      setLoading(false);
    }
  };

  const handleProfileUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);

    try {
      const response = await fetch("/api/user/profile", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: profileData.name,
          bio: profileData.bio,
          dateOfBirth: profileData.dateOfBirth || null,
          gender: profileData.gender || null,
          showDreamCount: profileData.showDreamCount,
          showBio: profileData.showBio,
          showAge: profileData.showAge,
          showGender: profileData.showGender,
        }),
      });

      if (!response.ok) throw new Error("Profil güncellenemedi");

      const updatedProfile = await response.json();
      setSettings({ ...settings!, ...updatedProfile });
      
      // Session'ı güncelle
      await update({
        ...session,
        user: {
          ...session?.user,
          name: updatedProfile.name,
        },
      });

      toast.success("Profil başarıyla güncellendi");
    } catch (error) {
      console.error("Profil güncelleme hatası:", error);
      toast.error("Profil güncellenirken bir hata oluştu");
    } finally {
      setSaving(false);
    }
  };

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (passwordData.newPassword !== passwordData.confirmPassword) {
      toast.error("Yeni şifreler eşleşmiyor");
      return;
    }

    if (passwordData.newPassword.length < 6) {
      toast.error("Şifre en az 6 karakter olmalıdır");
      return;
    }

    setSaving(true);

    try {
      const response = await fetch("/api/user/change-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          currentPassword: passwordData.currentPassword,
          newPassword: passwordData.newPassword,
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || "Şifre değiştirilemedi");
      }

      setPasswordData({
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      });

      toast.success("Şifre başarıyla değiştirildi");
    } catch (error: any) {
      console.error("Şifre değiştirme hatası:", error);
      toast.error(error.message || "Şifre değiştirilirken bir hata oluştu");
    } finally {
      setSaving(false);
    }
  };

  const handleNotificationUpdate = async () => {
    setSaving(true);

    try {
      const response = await fetch("/api/user/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(notificationSettings),
      });

      if (!response.ok) throw new Error("Bildirim ayarları güncellenemedi");

      toast.success("Bildirim ayarları güncellendi");
    } catch (error) {
      console.error("Bildirim ayarları güncelleme hatası:", error);
      toast.error("Bildirim ayarları güncellenirken bir hata oluştu");
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteAccount = async () => {
    try {
      const response = await fetch("/api/user/delete", {
        method: "DELETE",
      });

      if (!response.ok) throw new Error("Hesap silinemedi");

      toast.success("Hesabınız başarıyla silindi");
      window.location.href = "/";
    } catch (error) {
      console.error("Hesap silme hatası:", error);
      toast.error("Hesap silinirken bir hata oluştu");
    }
  };

  const handleImageUpdate = async (newImagePath: string | null) => {
    setSettings(prev => prev ? { ...prev, image: newImagePath } : null);
    
    // Update session
    await update({
      ...session,
      user: {
        ...session?.user,
        image: newImagePath,
      },
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="h-8 w-8 animate-spin text-purple-600" />
      </div>
    );
  }

  if (!settings) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <p className="text-muted-foreground">Ayarlar yüklenemedi</p>
      </div>
    );
  }

  return (
    <div className="container max-w-5xl mx-auto px-4 py-8">
      <div className="mb-8">
        <Button
          variant="ghost"
          onClick={() => router.push("/dashboard")}
          className="mb-4 hover:bg-purple-100 dark:hover:bg-purple-900/20"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Ana Menüye Dön
        </Button>
        <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
          Ayarlar
        </h1>
        <p className="text-muted-foreground mt-2">
          Hesap bilgilerinizi ve tercihlerinizi yönetin
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="profil" className="flex items-center gap-2">
            <User className="h-4 w-4" />
            <span className="hidden sm:inline">Profil</span>
          </TabsTrigger>
          <TabsTrigger value="guvenlik" className="flex items-center gap-2">
            <Lock className="h-4 w-4" />
            <span className="hidden sm:inline">Güvenlik</span>
          </TabsTrigger>
          <TabsTrigger value="bildirimler" className="flex items-center gap-2">
            <Bell className="h-4 w-4" />
            <span className="hidden sm:inline">Bildirimler</span>
          </TabsTrigger>
          <TabsTrigger value="hesap" className="flex items-center gap-2">
            <Shield className="h-4 w-4" />
            <span className="hidden sm:inline">Hesap</span>
          </TabsTrigger>
        </TabsList>

        {/* Profil Ayarları */}
        <TabsContent value="profil" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Profil Bilgileri</CardTitle>
              <CardDescription>
                Profilinizde görünecek bilgileri düzenleyin
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleProfileUpdate} className="space-y-6">
                <div className="flex justify-center py-4">
                  <ProfileImageUpload
                    currentImage={settings.image}
                    userName={settings.name}
                    onImageUpdate={handleImageUpdate}
                  />
                </div>

                <Separator />

                <div className="space-y-2">
                  <Label htmlFor="name">Ad Soyad</Label>
                  <Input
                    id="name"
                    value={profileData.name}
                    onChange={(e) =>
                      setProfileData({ ...profileData, name: e.target.value })
                    }
                    placeholder="Adınızı ve soyadınızı girin"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">E-posta</Label>
                  <Input
                    id="email"
                    type="email"
                    value={settings.email}
                    disabled
                    className="bg-muted"
                  />
                  <p className="text-xs text-muted-foreground">
                    E-posta adresi değiştirilemez
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="bio">Hakkında</Label>
                  <Textarea
                    id="bio"
                    value={profileData.bio}
                    onChange={(e) =>
                      setProfileData({ ...profileData, bio: e.target.value })
                    }
                    placeholder="Kendiniz hakkında bir şeyler yazın..."
                    rows={4}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="dateOfBirth">Doğum Tarihi</Label>
                    <Input
                      id="dateOfBirth"
                      type="date"
                      max={new Date().toISOString().split('T')[0]}
                      value={profileData.dateOfBirth}
                      onChange={(e) =>
                        setProfileData({ ...profileData, dateOfBirth: e.target.value })
                      }
                    />
                    <p className="text-xs text-muted-foreground">
                      Yaşınız otomatik hesaplanacaktır
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="gender">Cinsiyet</Label>
                    <select
                      id="gender"
                      value={profileData.gender}
                      onChange={(e) =>
                        setProfileData({ ...profileData, gender: e.target.value })
                      }
                      className="w-full px-3 py-2 rounded-md border border-input bg-background"
                    >
                      <option value="">Seçiniz</option>
                      <option value="erkek">Erkek</option>
                      <option value="kadin">Kadın</option>
                      <option value="diger">Diğer</option>
                      <option value="belirtmek_istemiyorum">Belirtmek İstemiyorum</option>
                    </select>
                  </div>
                </div>

                <div className="flex items-center justify-between py-2 px-4 bg-muted rounded-lg">
                  <div className="space-y-0.5">
                    <Label htmlFor="showDreamCount">Rüya Sayısı Görünürlüğü</Label>
                    <p className="text-sm text-muted-foreground">
                      Rüya sayınızı diğer kullanıcılara göster
                    </p>
                  </div>
                  <Switch
                    id="showDreamCount"
                    checked={profileData.showDreamCount}
                    onCheckedChange={(checked) =>
                      setProfileData({ ...profileData, showDreamCount: checked })
                    }
                  />
                </div>

                <div className="flex items-center justify-between py-2 px-4 bg-muted rounded-lg">
                  <div className="space-y-0.5">
                    <Label htmlFor="showBio">Hakkımda Bilgisi Görünürlüğü</Label>
                    <p className="text-sm text-muted-foreground">
                      Hakkımda bilginizi diğer kullanıcılara göster
                    </p>
                  </div>
                  <Switch
                    id="showBio"
                    checked={profileData.showBio}
                    onCheckedChange={(checked) =>
                      setProfileData({ ...profileData, showBio: checked })
                    }
                  />
                </div>

                <div className="flex items-center justify-between py-2 px-4 bg-muted rounded-lg">
                  <div className="space-y-0.5">
                    <Label htmlFor="showAge">Yaş Bilgisi Görünürlüğü</Label>
                    <p className="text-sm text-muted-foreground">
                      Yaş bilginizi diğer kullanıcılara göster
                    </p>
                  </div>
                  <Switch
                    id="showAge"
                    checked={profileData.showAge}
                    onCheckedChange={(checked) =>
                      setProfileData({ ...profileData, showAge: checked })
                    }
                  />
                </div>

                <div className="flex items-center justify-between py-2 px-4 bg-muted rounded-lg">
                  <div className="space-y-0.5">
                    <Label htmlFor="showGender">Cinsiyet Bilgisi Görünürlüğü</Label>
                    <p className="text-sm text-muted-foreground">
                      Cinsiyet bilginizi diğer kullanıcılara göster
                    </p>
                  </div>
                  <Switch
                    id="showGender"
                    checked={profileData.showGender}
                    onCheckedChange={(checked) =>
                      setProfileData({ ...profileData, showGender: checked })
                    }
                  />
                </div>

                <Button
                  type="submit"
                  disabled={saving}
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                >
                  {saving ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Kaydediliyor...
                    </>
                  ) : (
                    "Değişiklikleri Kaydet"
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Görünüm Ayarları</CardTitle>
              <CardDescription>
                Uygulama temasını seçin
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="theme">Tema</Label>
                <select
                  id="theme"
                  value={settings?.theme || 'dark'}
                  onChange={async (e) => {
                    const newTheme = e.target.value;
                    try {
                      const response = await fetch('/api/user/settings', {
                        method: 'PUT',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ theme: newTheme }),
                      });
                      
                      if (!response.ok) throw new Error('Tema güncellenemedi');
                      
                      setSettings({ ...settings!, theme: newTheme });
                      
                      // Temayı uygula
                      if (newTheme === 'dark') {
                        document.documentElement.classList.add('dark');
                        localStorage.setItem('theme', 'dark');
                      } else if (newTheme === 'light') {
                        document.documentElement.classList.remove('dark');
                        localStorage.setItem('theme', 'light');
                      } else {
                        // System
                        const systemDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
                        if (systemDark) {
                          document.documentElement.classList.add('dark');
                        } else {
                          document.documentElement.classList.remove('dark');
                        }
                        localStorage.removeItem('theme');
                      }
                      
                      toast.success('Tema güncellendi');
                    } catch (error) {
                      toast.error('Tema güncellenirken hata oluştu');
                      console.error(error);
                    }
                  }}
                  className="w-full px-3 py-2 rounded-md border border-input bg-background"
                >
                  <option value="light">Açık</option>
                  <option value="dark">Koyu</option>
                  <option value="system">Sistem</option>
                </select>
                <p className="text-xs text-muted-foreground">
                  Uygulamanın görünümünü tercihlerinize göre ayarlayın
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Güvenlik Ayarları */}
        <TabsContent value="guvenlik" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Şifre Değiştir</CardTitle>
              <CardDescription>
                Hesabınızın güvenliğini sağlamak için güçlü bir şifre kullanın
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handlePasswordChange} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="currentPassword">Mevcut Şifre</Label>
                  <Input
                    id="currentPassword"
                    type="password"
                    value={passwordData.currentPassword}
                    onChange={(e) =>
                      setPasswordData({ ...passwordData, currentPassword: e.target.value })
                    }
                    placeholder="Mevcut şifrenizi girin"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="newPassword">Yeni Şifre</Label>
                  <Input
                    id="newPassword"
                    type="password"
                    value={passwordData.newPassword}
                    onChange={(e) =>
                      setPasswordData({ ...passwordData, newPassword: e.target.value })
                    }
                    placeholder="Yeni şifrenizi girin"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="confirmPassword">Yeni Şifre (Tekrar)</Label>
                  <Input
                    id="confirmPassword"
                    type="password"
                    value={passwordData.confirmPassword}
                    onChange={(e) =>
                      setPasswordData({ ...passwordData, confirmPassword: e.target.value })
                    }
                    placeholder="Yeni şifrenizi tekrar girin"
                  />
                </div>

                <Button
                  type="submit"
                  disabled={saving}
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                >
                  {saving ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Değiştiriliyor...
                    </>
                  ) : (
                    "Şifreyi Değiştir"
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Bildirim Ayarları */}
        <TabsContent value="bildirimler" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Bildirim Tercihleri</CardTitle>
              <CardDescription>
                Hangi bildirimleri almak istediğinizi seçin
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="emailNotifications">E-posta Bildirimleri</Label>
                  <p className="text-sm text-muted-foreground">
                    Önemli güncellemeler ve haberler için e-posta alın
                  </p>
                </div>
                <Switch
                  id="emailNotifications"
                  checked={notificationSettings.emailNotifications}
                  onCheckedChange={(checked) =>
                    setNotificationSettings({ ...notificationSettings, emailNotifications: checked })
                  }
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="dreamReminders">Rüya Hatırlatıcıları</Label>
                  <p className="text-sm text-muted-foreground">
                    Rüyalarınızı kaydetmeniz için günlük hatırlatıcılar alın
                  </p>
                </div>
                <Switch
                  id="dreamReminders"
                  checked={notificationSettings.dreamReminders}
                  onCheckedChange={(checked) =>
                    setNotificationSettings({ ...notificationSettings, dreamReminders: checked })
                  }
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="communityNotifications">Topluluk Bildirimleri</Label>
                  <p className="text-sm text-muted-foreground">
                    Rüyalarınıza gelen yorumlar ve beğeniler için bildirim alın
                  </p>
                </div>
                <Switch
                  id="communityNotifications"
                  checked={notificationSettings.communityNotifications}
                  onCheckedChange={(checked) =>
                    setNotificationSettings({ ...notificationSettings, communityNotifications: checked })
                  }
                />
              </div>

              <Button
                onClick={handleNotificationUpdate}
                disabled={saving}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
              >
                {saving ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Kaydediliyor...
                  </>
                ) : (
                  "Bildirimleri Kaydet"
                )}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Hesap Yönetimi */}
        <TabsContent value="hesap" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Hesap Bilgileri</CardTitle>
              <CardDescription>
                Hesap durumunuzu ve premium özelliklerinizi görüntüleyin
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between p-4 bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-950/20 dark:to-pink-950/20 rounded-lg">
                <div className="flex items-center gap-3">
                  {settings.isPremium ? (
                    <>
                      <Crown className="h-6 w-6 text-amber-500" />
                      <div>
                        <p className="font-semibold">Premium Üyelik</p>
                        <p className="text-sm text-muted-foreground">
                          Tüm özelliklere sınırsız erişim
                        </p>
                      </div>
                    </>
                  ) : (
                    <>
                      <User className="h-6 w-6 text-purple-500" />
                      <div>
                        <p className="font-semibold">Ücretsiz Hesap</p>
                        <p className="text-sm text-muted-foreground">
                          Temel özelliklere erişim
                        </p>
                      </div>
                    </>
                  )}
                </div>
                {!settings.isPremium && (
                  <Button
                    variant="outline"
                    onClick={() => window.location.href = "/premium"}
                    className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white border-0"
                  >
                    Premium'a Geç
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>

          <Card className="border-destructive">
            <CardHeader>
              <CardTitle className="text-destructive">Tehlikeli Alan</CardTitle>
              <CardDescription>
                Bu işlemler geri alınamaz. Dikkatli olun.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="destructive" className="w-full">
                    <Trash2 className="mr-2 h-4 w-4" />
                    Hesabımı Sil
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Hesabınızı silmek istediğinizden emin misiniz?</AlertDialogTitle>
                    <AlertDialogDescription>
                      Bu işlem geri alınamaz. Tüm rüyalarınız, analizleriniz ve
                      kişisel verileriniz kalıcı olarak silinecektir.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>İptal</AlertDialogCancel>
                    <AlertDialogAction
                      onClick={handleDeleteAccount}
                      className="bg-destructive hover:bg-destructive/90"
                    >
                      Evet, Hesabımı Sil
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
