
'use client';

import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { UserPlus, Users, UserCheck, UserX, Search, ArrowLeft } from 'lucide-react';
import { toast } from 'react-hot-toast';
import Link from 'next/link';

interface User {
  id: string;
  name: string | null;
  username: string | null;
  image: string | null;
  bio: string | null;
}

interface FriendRequest {
  id: string;
  senderId: string;
  receiverId: string;
  status: string;
  createdAt: string;
  sender: User;
  receiver: User;
}

export default function FriendsPage() {
  const { data: session, status } = useSession() || {};
  const router = useRouter();
  const [friends, setFriends] = useState<User[]>([]);
  const [requests, setRequests] = useState<FriendRequest[]>([]);
  const [searchResults, setSearchResults] = useState<User[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [searchLoading, setSearchLoading] = useState(false);

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/auth/giris');
    } else if (status === 'authenticated' && session?.user) {
      fetchFriends();
      fetchRequests();
    }
  }, [status, session, router]);

  const fetchFriends = async () => {
    try {
      const response = await fetch('/api/friendship/list');
      if (response.ok) {
        const data = await response.json();
        setFriends(data.friends || []);
      }
    } catch (error) {
      console.error('Error fetching friends:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchRequests = async () => {
    try {
      const response = await fetch('/api/friendship/requests');
      if (response.ok) {
        const data = await response.json();
        setRequests(data.requests || []);
      }
    } catch (error) {
      console.error('Error fetching requests:', error);
    }
  };

  const handleSearch = async () => {
    if (!searchQuery.trim()) {
      setSearchResults([]);
      return;
    }

    setSearchLoading(true);
    try {
      const response = await fetch(`/api/users/search?q=${encodeURIComponent(searchQuery)}`);
      if (response.ok) {
        const data = await response.json();
        setSearchResults(data.users || []);
      }
    } catch (error) {
      console.error('Error searching users:', error);
      toast.error('Arama sırasında bir hata oluştu');
    } finally {
      setSearchLoading(false);
    }
  };

  const sendFriendRequest = async (userId: string) => {
    try {
      const response = await fetch('/api/friendship/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ receiverId: userId }),
      });

      if (response.ok) {
        toast.success('Arkadaşlık isteği gönderildi');
        handleSearch(); // Refresh search results
      } else {
        const error = await response.json();
        toast.error(error.error || 'İstek gönderilemedi');
      }
    } catch (error) {
      console.error('Error sending friend request:', error);
      toast.error('İstek gönderilemedi');
    }
  };

  const respondToRequest = async (requestId: string, accept: boolean) => {
    try {
      const response = await fetch('/api/friendship/respond', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ requestId, accept }),
      });

      if (response.ok) {
        toast.success(accept ? 'Arkadaşlık isteği kabul edildi' : 'İstek reddedildi');
        fetchRequests();
        if (accept) fetchFriends();
      } else {
        toast.error('İşlem başarısız oldu');
      }
    } catch (error) {
      console.error('Error responding to request:', error);
      toast.error('İşlem başarısız oldu');
    }
  };

  const removeFriend = async (friendId: string) => {
    if (!confirm('Bu arkadaşınızı silmek istediğinizden emin misiniz?')) return;

    try {
      const response = await fetch('/api/friendship/remove', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ friendId }),
      });

      if (response.ok) {
        toast.success('Arkadaş silindi');
        fetchFriends();
      } else {
        toast.error('Silme işlemi başarısız oldu');
      }
    } catch (error) {
      console.error('Error removing friend:', error);
      toast.error('Silme işlemi başarısız oldu');
    }
  };

  if (status === 'loading' || loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto mb-4"></div>
          <p className="text-gray-400">Yükleniyor...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container max-w-6xl mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-6">
        <Link href="/dashboard">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-pink-600 bg-clip-text text-transparent">
          Arkadaşlarım
        </h1>
      </div>

      <Tabs defaultValue="friends" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3 bg-gray-800/50">
          <TabsTrigger value="friends" className="data-[state=active]:bg-purple-600">
            <Users className="h-4 w-4 mr-2" />
            Arkadaşlar ({friends.length})
          </TabsTrigger>
          <TabsTrigger value="requests" className="data-[state=active]:bg-purple-600">
            <UserPlus className="h-4 w-4 mr-2" />
            İstekler ({requests.length})
          </TabsTrigger>
          <TabsTrigger value="search" className="data-[state=active]:bg-purple-600">
            <Search className="h-4 w-4 mr-2" />
            Ara
          </TabsTrigger>
        </TabsList>

        <TabsContent value="friends" className="space-y-4">
          {friends.length === 0 ? (
            <Card className="p-8 text-center bg-gray-800/30 border-gray-700">
              <Users className="h-12 w-12 mx-auto mb-4 text-gray-500" />
              <p className="text-gray-400">Henüz arkadaşınız yok</p>
              <p className="text-sm text-gray-500 mt-2">
                Arkadaş bulmak için arama yapabilirsiniz
              </p>
            </Card>
          ) : (
            <div className="grid gap-4 md:grid-cols-2">
              {friends.map((friend) => (
                <Card key={friend.id} className="p-4 bg-gray-800/30 border-gray-700 hover:border-purple-500/50 transition-all">
                  <div className="flex items-start gap-4">
                    <Avatar className="h-12 w-12 border-2 border-purple-500/50">
                      <AvatarImage src={friend.image || undefined} />
                      <AvatarFallback className="bg-gradient-to-br from-purple-500 to-pink-500">
                        {friend.name?.[0] || friend.username?.[0] || 'U'}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <Link
                        href={`/dashboard/user/${friend.id}`}
                        className="font-semibold text-white hover:text-purple-400 transition-colors block truncate"
                      >
                        {friend.name || friend.username}
                      </Link>
                      {friend.username && friend.name && (
                        <p className="text-sm text-gray-500">@{friend.username}</p>
                      )}
                      {friend.bio && (
                        <p className="text-sm text-gray-400 mt-1 line-clamp-2">{friend.bio}</p>
                      )}
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeFriend(friend.id)}
                      className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                    >
                      <UserX className="h-4 w-4" />
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="requests" className="space-y-4">
          {requests.length === 0 ? (
            <Card className="p-8 text-center bg-gray-800/30 border-gray-700">
              <UserPlus className="h-12 w-12 mx-auto mb-4 text-gray-500" />
              <p className="text-gray-400">Bekleyen arkadaşlık isteği yok</p>
            </Card>
          ) : (
            <div className="grid gap-4">
              {requests.map((request) => {
                const user = request.sender.id === session?.user?.id ? request.receiver : request.sender;
                const isPending = request.status === 'PENDING';
                const isSent = request.sender.id === session?.user?.id;

                return (
                  <Card key={request.id} className="p-4 bg-gray-800/30 border-gray-700">
                    <div className="flex items-start gap-4">
                      <Avatar className="h-12 w-12 border-2 border-purple-500/50">
                        <AvatarImage src={user.image || undefined} />
                        <AvatarFallback className="bg-gradient-to-br from-purple-500 to-pink-500">
                          {user.name?.[0] || user.username?.[0] || 'U'}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <p className="font-semibold text-white">{user.name || user.username}</p>
                        {user.username && user.name && (
                          <p className="text-sm text-gray-500">@{user.username}</p>
                        )}
                        <p className="text-sm text-gray-400 mt-1">
                          {isSent ? 'Gönderilen istek' : 'Arkadaşlık isteği gönderdi'}
                        </p>
                      </div>
                      {!isSent && isPending && (
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            onClick={() => respondToRequest(request.id, true)}
                            className="bg-green-600 hover:bg-green-700"
                          >
                            <UserCheck className="h-4 w-4 mr-1" />
                            Kabul Et
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => respondToRequest(request.id, false)}
                            className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                          >
                            <UserX className="h-4 w-4 mr-1" />
                            Reddet
                          </Button>
                        </div>
                      )}
                    </div>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="search" className="space-y-4">
          <Card className="p-4 bg-gray-800/30 border-gray-700">
            <div className="flex gap-2">
              <Input
                placeholder="İsim veya kullanıcı adı ile ara..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                className="bg-gray-900/50 border-gray-700"
              />
              <Button onClick={handleSearch} disabled={searchLoading}>
                <Search className="h-4 w-4 mr-2" />
                Ara
              </Button>
            </div>
          </Card>

          {searchResults.length > 0 && (
            <div className="grid gap-4 md:grid-cols-2">
              {searchResults.map((user) => {
                const isSelf = user.id === session?.user?.id;
                const isFriend = friends.some((f) => f.id === user.id);
                const hasPendingRequest = requests.some(
                  (r) =>
                    (r.sender.id === user.id || r.receiver.id === user.id) &&
                    r.status === 'PENDING'
                );

                return (
                  <Card key={user.id} className="p-4 bg-gray-800/30 border-gray-700">
                    <div className="flex items-start gap-4">
                      <Avatar className="h-12 w-12 border-2 border-purple-500/50">
                        <AvatarImage src={user.image || undefined} />
                        <AvatarFallback className="bg-gradient-to-br from-purple-500 to-pink-500">
                          {user.name?.[0] || user.username?.[0] || 'U'}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <Link
                          href={`/dashboard/user/${user.id}`}
                          className="font-semibold text-white hover:text-purple-400 transition-colors block truncate"
                        >
                          {user.name || user.username}
                        </Link>
                        {user.username && user.name && (
                          <p className="text-sm text-gray-500">@{user.username}</p>
                        )}
                        {user.bio && (
                          <p className="text-sm text-gray-400 mt-1 line-clamp-2">{user.bio}</p>
                        )}
                      </div>
                      {!isSelf && (
                        <div>
                          {isFriend ? (
                            <Button size="sm" variant="ghost" disabled className="text-green-400">
                              <UserCheck className="h-4 w-4 mr-1" />
                              Arkadaş
                            </Button>
                          ) : hasPendingRequest ? (
                            <Button size="sm" variant="ghost" disabled className="text-gray-400">
                              İstek Gönderildi
                            </Button>
                          ) : (
                            <Button
                              size="sm"
                              onClick={() => sendFriendRequest(user.id)}
                              className="bg-purple-600 hover:bg-purple-700"
                            >
                              <UserPlus className="h-4 w-4 mr-1" />
                              Ekle
                            </Button>
                          )}
                        </div>
                      )}
                    </div>
                  </Card>
                );
              })}
            </div>
          )}

          {searchQuery && searchResults.length === 0 && !searchLoading && (
            <Card className="p-8 text-center bg-gray-800/30 border-gray-700">
              <Search className="h-12 w-12 mx-auto mb-4 text-gray-500" />
              <p className="text-gray-400">Sonuç bulunamadı</p>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
