
'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'react-hot-toast';
import { 
  Plus, 
  Pencil, 
  Trash2, 
  Loader2, 
  Shield,
  Users,
  BookOpen,
  TrendingUp,
  MessageSquare,
  Heart,
  Crown,
  Activity,
  Settings as SettingsIcon
} from 'lucide-react';

interface DreamSymbol {
  id: string;
  symbol: string;
  meaning: string;
  category: string;
}

interface Stats {
  overview: {
    totalUsers: number;
    premiumUsers: number;
    totalDreams: number;
    totalAnalyses: number;
    totalSharedDreams: number;
    totalComments: number;
    totalLikes: number;
  };
  activity: {
    todayDreams: number;
    weekDreams: number;
    monthDreams: number;
    weeklyActivity: Array<{ date: string; count: number }>;
  };
  dreamTypes: Array<{ type: string; count: number }>;
  topUsers: Array<{
    name: string;
    email: string;
    dreamCount: number;
    isPremium: boolean;
  }>;
  recentDreams: Array<{
    id: string;
    title: string;
    dreamType: string;
    createdAt: string;
    user: { name: string; email: string };
  }>;
}

interface PlatformSettings {
  id: string;
  siteName: string;
  siteDescription: string;
  registrationEnabled: boolean;
  communityEnabled: boolean;
  aiAnalysisEnabled: boolean;
  maintenanceMode: boolean;
  maxDreamsPerDay: number;
  maxAnalysesPerDay: number;
  welcomeMessage?: string;
  contactEmail?: string;
  contactPhone?: string;
  contactAddress?: string;
  contactWhatsapp?: string;
  socialFacebook?: string;
  socialTwitter?: string;
  socialInstagram?: string;
  socialLinkedin?: string;
  socialYoutube?: string;
  socialTiktok?: string;
  googleClientId?: string;
  googleClientSecret?: string;
  iyzicoApiKey?: string;
  iyzicoSecretKey?: string;
}

const categories = [
  { value: 'ANIMALS', label: 'Hayvanlar' },
  { value: 'NATURE', label: 'Doğa' },
  { value: 'PEOPLE', label: 'İnsanlar' },
  { value: 'OBJECTS', label: 'Nesneler' },
  { value: 'EMOTIONS', label: 'Duygular' },
  { value: 'ACTIONS', label: 'Eylemler' },
  { value: 'PLACES', label: 'Yerler' },
  { value: 'COLORS', label: 'Renkler' },
  { value: 'NUMBERS', label: 'Sayılar' },
  { value: 'SPIRITUAL', label: 'Ruhsal' },
];

export default function AdminAyarlarPage() {
  const { data: session, status } = useSession() || {};
  const router = useRouter();
  const [symbols, setSymbols] = useState<DreamSymbol[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [settings, setSettings] = useState<PlatformSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [statsLoading, setStatsLoading] = useState(false);
  const [settingsLoading, setSettingsLoading] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingSymbol, setEditingSymbol] = useState<DreamSymbol | null>(null);
  const [formData, setFormData] = useState({
    symbol: '',
    meaning: '',
    category: 'ANIMALS',
  });
  const [submitting, setSubmitting] = useState(false);

  // Admin kontrolü
  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/auth/giris');
    } else if (status === 'authenticated' && !session?.user?.isAdmin) {
      toast.error('Bu sayfaya erişim yetkiniz yok');
      router.push('/dashboard');
    }
  }, [status, session, router]);

  // Sembolleri yükle
  useEffect(() => {
    if (session?.user?.isAdmin) {
      loadSymbols();
    }
  }, [session]);

  // Ayarları otomatik yükle
  useEffect(() => {
    if (session?.user?.isAdmin && settings === null && !settingsLoading) {
      loadSettings();
    }
  }, [session, settings, settingsLoading]);

  const loadSymbols = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/admin/symbols');
      if (!response.ok) throw new Error('Semboller yüklenemedi');
      const data = await response.json();
      setSymbols(data);
    } catch (error) {
      toast.error('Semboller yüklenirken hata oluştu');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const loadStats = async () => {
    try {
      setStatsLoading(true);
      const response = await fetch('/api/admin/stats');
      if (!response.ok) throw new Error('İstatistikler yüklenemedi');
      const data = await response.json();
      setStats(data);
    } catch (error) {
      toast.error('İstatistikler yüklenirken hata oluştu');
      console.error(error);
    } finally {
      setStatsLoading(false);
    }
  };

  const loadSettings = async () => {
    try {
      setSettingsLoading(true);
      const response = await fetch('/api/admin/settings');
      if (!response.ok) throw new Error('Ayarlar yüklenemedi');
      const data = await response.json();
      setSettings(data);
    } catch (error) {
      toast.error('Ayarlar yüklenirken hata oluştu');
      console.error(error);
    } finally {
      setSettingsLoading(false);
    }
  };

  const saveSettings = async () => {
    if (!settings) return;

    try {
      setSubmitting(true);
      console.log('Saving settings:', settings);
      
      const response = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings),
      });

      const responseData = await response.json();
      console.log('Save settings response:', responseData);

      if (!response.ok) {
        throw new Error(responseData.error || 'Ayarlar kaydedilemedi');
      }

      toast.success('Ayarlar başarıyla kaydedildi');
      setSettings(responseData);
    } catch (error: any) {
      toast.error(error.message || 'Ayarlar kaydedilirken hata oluştu');
      console.error('Save settings error:', error);
    } finally {
      setSubmitting(false);
    }
  };

  const handleOpenDialog = (symbol?: DreamSymbol) => {
    if (symbol) {
      setEditingSymbol(symbol);
      setFormData({
        symbol: symbol.symbol,
        meaning: symbol.meaning,
        category: symbol.category,
      });
    } else {
      setEditingSymbol(null);
      setFormData({ symbol: '', meaning: '', category: 'ANIMALS' });
    }
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setEditingSymbol(null);
    setFormData({ symbol: '', meaning: '', category: 'ANIMALS' });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.symbol || !formData.meaning) {
      toast.error('Lütfen tüm alanları doldurun');
      return;
    }

    try {
      setSubmitting(true);
      const url = editingSymbol
        ? `/api/admin/symbols/${editingSymbol.id}`
        : '/api/admin/symbols';
      const method = editingSymbol ? 'PUT' : 'POST';

      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (!response.ok) throw new Error('İşlem başarısız');

      toast.success(
        editingSymbol ? 'Sembol güncellendi' : 'Sembol eklendi'
      );
      handleCloseDialog();
      loadSymbols();
    } catch (error) {
      toast.error('İşlem sırasında hata oluştu');
      console.error(error);
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Bu sembolü silmek istediğinizden emin misiniz?')) return;

    try {
      const response = await fetch(`/api/admin/symbols/${id}`, {
        method: 'DELETE',
      });

      if (!response.ok) throw new Error('Silme işlemi başarısız');

      toast.success('Sembol silindi');
      loadSymbols();
    } catch (error) {
      toast.error('Silme sırasında hata oluştu');
      console.error(error);
    }
  };

  if (status === 'loading' || loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
      </div>
    );
  }

  if (!session?.user?.isAdmin) {
    return null;
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <Shield className="w-8 h-8 text-purple-600" />
          <h1 className="text-3xl font-bold">Admin Ayarları</h1>
        </div>
        <p className="text-muted-foreground">
          Platform yönetimi ve içerik düzenleme
        </p>
      </div>

      <Tabs defaultValue="symbols" className="space-y-6">
        <TabsList>
          <TabsTrigger value="symbols">Sembol Yönetimi</TabsTrigger>
          <TabsTrigger value="stats">İstatistikler</TabsTrigger>
          <TabsTrigger value="settings">Genel Ayarlar</TabsTrigger>
        </TabsList>

        <TabsContent value="symbols" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Rüya Sembolleri</CardTitle>
                  <CardDescription>
                    Rüya analizi için kullanılan sembolleri yönetin
                  </CardDescription>
                </div>
                <Button onClick={() => handleOpenDialog()}>
                  <Plus className="w-4 h-4 mr-2" />
                  Yeni Sembol
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="border rounded-lg">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Sembol</TableHead>
                      <TableHead>Kategori</TableHead>
                      <TableHead>Anlam</TableHead>
                      <TableHead className="text-right">İşlemler</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {symbols.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={4} className="text-center py-8 text-muted-foreground">
                          Henüz sembol eklenmemiş
                        </TableCell>
                      </TableRow>
                    ) : (
                      symbols.map((symbol) => (
                        <TableRow key={symbol.id}>
                          <TableCell className="font-medium">
                            {symbol.symbol}
                          </TableCell>
                          <TableCell>
                            {categories.find((c) => c.value === symbol.category)?.label || symbol.category}
                          </TableCell>
                          <TableCell className="max-w-md truncate">
                            {symbol.meaning}
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex items-center justify-end gap-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleOpenDialog(symbol)}
                              >
                                <Pencil className="w-4 h-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleDelete(symbol.id)}
                              >
                                <Trash2 className="w-4 h-4 text-red-600" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="stats">
          {!stats ? (
            <div className="flex items-center justify-center py-12">
              <Button onClick={loadStats} disabled={statsLoading}>
                {statsLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Yükleniyor...
                  </>
                ) : (
                  'İstatistikleri Yükle'
                )}
              </Button>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Genel Bakış */}
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">
                      Toplam Kullanıcı
                    </CardTitle>
                    <Users className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{stats.overview.totalUsers}</div>
                    <p className="text-xs text-muted-foreground">
                      {stats.overview.premiumUsers} premium üye
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">
                      Toplam Rüya
                    </CardTitle>
                    <BookOpen className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{stats.overview.totalDreams}</div>
                    <p className="text-xs text-muted-foreground">
                      {stats.overview.totalAnalyses} analiz yapıldı
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">
                      Topluluk
                    </CardTitle>
                    <MessageSquare className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{stats.overview.totalSharedDreams}</div>
                    <p className="text-xs text-muted-foreground">
                      {stats.overview.totalComments} yorum
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">
                      Toplam Beğeni
                    </CardTitle>
                    <Heart className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{stats.overview.totalLikes}</div>
                  </CardContent>
                </Card>
              </div>

              {/* Aktivite */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="w-5 h-5" />
                    Aktivite
                  </CardTitle>
                  <CardDescription>Son günlerdeki aktivite özeti</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4 md:grid-cols-3">
                    <div className="space-y-2">
                      <p className="text-sm text-muted-foreground">Bugün</p>
                      <p className="text-2xl font-bold">{stats.activity.todayDreams}</p>
                      <p className="text-xs text-muted-foreground">yeni rüya</p>
                    </div>
                    <div className="space-y-2">
                      <p className="text-sm text-muted-foreground">Son 7 Gün</p>
                      <p className="text-2xl font-bold">{stats.activity.weekDreams}</p>
                      <p className="text-xs text-muted-foreground">yeni rüya</p>
                    </div>
                    <div className="space-y-2">
                      <p className="text-sm text-muted-foreground">Son 30 Gün</p>
                      <p className="text-2xl font-bold">{stats.activity.monthDreams}</p>
                      <p className="text-xs text-muted-foreground">yeni rüya</p>
                    </div>
                  </div>

                  {/* Haftalık Grafik */}
                  <div className="mt-6">
                    <h4 className="text-sm font-medium mb-4">Son 7 Gün</h4>
                    <div className="space-y-2">
                      {stats.activity.weeklyActivity.map((day) => (
                        <div key={day.date} className="flex items-center gap-4">
                          <div className="w-24 text-sm text-muted-foreground">
                            {new Date(day.date).toLocaleDateString('tr-TR', {
                              day: 'numeric',
                              month: 'short',
                            })}
                          </div>
                          <div className="flex-1">
                            <div
                              className="bg-purple-500 h-8 rounded flex items-center justify-end px-2"
                              style={{
                                width: `${Math.max((day.count / Math.max(...stats.activity.weeklyActivity.map((d) => d.count))) * 100, 10)}%`,
                              }}
                            >
                              <span className="text-xs text-white font-medium">
                                {day.count}
                              </span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* En Aktif Kullanıcılar */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="w-5 h-5" />
                    En Aktif Kullanıcılar
                  </CardTitle>
                  <CardDescription>En çok rüya ekleyen kullanıcılar</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="border rounded-lg">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Kullanıcı</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead className="text-center">Durum</TableHead>
                          <TableHead className="text-right">Rüya Sayısı</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {stats.topUsers.map((user, index) => (
                          <TableRow key={user.email}>
                            <TableCell className="font-medium">
                              <div className="flex items-center gap-2">
                                <span className="text-muted-foreground">#{index + 1}</span>
                                {user.name || 'İsimsiz'}
                              </div>
                            </TableCell>
                            <TableCell className="text-muted-foreground">
                              {user.email}
                            </TableCell>
                            <TableCell className="text-center">
                              {user.isPremium && (
                                <Crown className="w-4 h-4 text-yellow-500 mx-auto" />
                              )}
                            </TableCell>
                            <TableCell className="text-right font-bold">
                              {user.dreamCount}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>

              {/* Son Rüyalar */}
              <Card>
                <CardHeader>
                  <CardTitle>Son Eklenen Rüyalar</CardTitle>
                  <CardDescription>En son eklenen 10 rüya</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="border rounded-lg">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Başlık</TableHead>
                          <TableHead>Kullanıcı</TableHead>
                          <TableHead>Tür</TableHead>
                          <TableHead className="text-right">Tarih</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {stats.recentDreams.map((dream) => (
                          <TableRow key={dream.id}>
                            <TableCell className="font-medium">
                              {dream.title}
                            </TableCell>
                            <TableCell className="text-muted-foreground">
                              {dream.user.name || dream.user.email}
                            </TableCell>
                            <TableCell>
                              <span className="text-xs px-2 py-1 rounded-full bg-purple-100 text-purple-700">
                                {dream.dreamType}
                              </span>
                            </TableCell>
                            <TableCell className="text-right text-muted-foreground">
                              {new Date(dream.createdAt).toLocaleDateString('tr-TR')}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>

              {/* Yenile Butonu */}
              <div className="flex justify-end">
                <Button onClick={loadStats} disabled={statsLoading} variant="outline">
                  {statsLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Yükleniyor...
                    </>
                  ) : (
                    'Yenile'
                  )}
                </Button>
              </div>
            </div>
          )}
        </TabsContent>

        <TabsContent value="settings">
          {!settings ? (
            <div className="flex items-center justify-center py-12">
              <Button onClick={loadSettings} disabled={settingsLoading}>
                {settingsLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Yükleniyor...
                  </>
                ) : (
                  'Ayarları Yükle'
                )}
              </Button>
            </div>
          ) : (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <SettingsIcon className="w-5 h-5" />
                    Genel Ayarlar
                  </CardTitle>
                  <CardDescription>
                    Platform yapılandırması ve ayarları
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Site Bilgileri */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Site Bilgileri</h3>
                    
                    <div className="space-y-2">
                      <Label htmlFor="siteName">Site Adı</Label>
                      <Input
                        id="siteName"
                        value={settings.siteName}
                        onChange={(e) =>
                          setSettings({ ...settings, siteName: e.target.value })
                        }
                        placeholder="Rüya Günlüğü"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="siteDescription">Site Açıklaması</Label>
                      <Textarea
                        id="siteDescription"
                        value={settings.siteDescription}
                        onChange={(e) =>
                          setSettings({
                            ...settings,
                            siteDescription: e.target.value,
                          })
                        }
                        placeholder="AI destekli rüya analizi ve yorum platformu"
                        rows={3}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="welcomeMessage">Hoş Geldin Mesajı</Label>
                      <Textarea
                        id="welcomeMessage"
                        value={settings.welcomeMessage || ''}
                        onChange={(e) =>
                          setSettings({
                            ...settings,
                            welcomeMessage: e.target.value,
                          })
                        }
                        placeholder="Yeni kullanıcılara gösterilecek hoş geldin mesajı..."
                        rows={3}
                      />
                    </div>
                  </div>

                  {/* Özellik Ayarları */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Özellik Ayarları</h3>

                    <div className="flex items-center justify-between rounded-lg border p-4">
                      <div className="space-y-0.5">
                        <Label htmlFor="registrationEnabled" className="text-base">
                          Kayıt Açık
                        </Label>
                        <p className="text-sm text-muted-foreground">
                          Yeni kullanıcıların kayıt olmasına izin ver
                        </p>
                      </div>
                      <Switch
                        id="registrationEnabled"
                        checked={settings.registrationEnabled}
                        onCheckedChange={(checked) =>
                          setSettings({ ...settings, registrationEnabled: checked })
                        }
                      />
                    </div>

                    <div className="flex items-center justify-between rounded-lg border p-4">
                      <div className="space-y-0.5">
                        <Label htmlFor="communityEnabled" className="text-base">
                          Topluluk Özellikleri
                        </Label>
                        <p className="text-sm text-muted-foreground">
                          Rüya paylaşımı, yorum ve beğeni özelliklerini etkinleştir
                        </p>
                      </div>
                      <Switch
                        id="communityEnabled"
                        checked={settings.communityEnabled}
                        onCheckedChange={(checked) =>
                          setSettings({ ...settings, communityEnabled: checked })
                        }
                      />
                    </div>

                    <div className="flex items-center justify-between rounded-lg border p-4">
                      <div className="space-y-0.5">
                        <Label htmlFor="aiAnalysisEnabled" className="text-base">
                          AI Analiz
                        </Label>
                        <p className="text-sm text-muted-foreground">
                          Rüya analizinde AI kullanımını etkinleştir
                        </p>
                      </div>
                      <Switch
                        id="aiAnalysisEnabled"
                        checked={settings.aiAnalysisEnabled}
                        onCheckedChange={(checked) =>
                          setSettings({ ...settings, aiAnalysisEnabled: checked })
                        }
                      />
                    </div>

                    <div className="flex items-center justify-between rounded-lg border p-4 bg-red-50 dark:bg-red-950/10">
                      <div className="space-y-0.5">
                        <Label htmlFor="maintenanceMode" className="text-base text-red-600 dark:text-red-400">
                          Bakım Modu
                        </Label>
                        <p className="text-sm text-red-600/70 dark:text-red-400/70">
                          Siteyi bakım moduna al (sadece adminler erişebilir)
                        </p>
                      </div>
                      <Switch
                        id="maintenanceMode"
                        checked={settings.maintenanceMode}
                        onCheckedChange={(checked) =>
                          setSettings({ ...settings, maintenanceMode: checked })
                        }
                      />
                    </div>
                  </div>

                  {/* Limitler */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Günlük Limitler</h3>

                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="space-y-2">
                        <Label htmlFor="maxDreamsPerDay">
                          Günlük Maksimum Rüya Sayısı
                        </Label>
                        <Input
                          id="maxDreamsPerDay"
                          type="number"
                          min={1}
                          max={100}
                          value={settings.maxDreamsPerDay}
                          onChange={(e) =>
                            setSettings({
                              ...settings,
                              maxDreamsPerDay: parseInt(e.target.value) || 10,
                            })
                          }
                        />
                        <p className="text-xs text-muted-foreground">
                          Bir kullanıcının günde ekleyebileceği maksimum rüya sayısı
                        </p>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="maxAnalysesPerDay">
                          Günlük Maksimum Analiz Sayısı
                        </Label>
                        <Input
                          id="maxAnalysesPerDay"
                          type="number"
                          min={1}
                          max={100}
                          value={settings.maxAnalysesPerDay}
                          onChange={(e) =>
                            setSettings({
                              ...settings,
                              maxAnalysesPerDay: parseInt(e.target.value) || 5,
                            })
                          }
                        />
                        <p className="text-xs text-muted-foreground">
                          Bir kullanıcının günde yapabileceği maksimum analiz sayısı
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* İletişim Bilgileri */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">İletişim Bilgileri</h3>
                    <p className="text-sm text-muted-foreground">
                      Site genelinde görünecek iletişim bilgilerini düzenleyin
                    </p>
                    
                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="space-y-2">
                        <Label htmlFor="contactEmail">E-posta Adresi</Label>
                        <Input
                          id="contactEmail"
                          type="email"
                          value={settings.contactEmail || ''}
                          onChange={(e) =>
                            setSettings({
                              ...settings,
                              contactEmail: e.target.value,
                            })
                          }
                          placeholder="info@ruyagunlugu.com"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="contactPhone">Telefon Numarası</Label>
                        <Input
                          id="contactPhone"
                          type="tel"
                          value={settings.contactPhone || ''}
                          onChange={(e) =>
                            setSettings({
                              ...settings,
                              contactPhone: e.target.value,
                            })
                          }
                          placeholder="+90 (555) 123 45 67"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="contactWhatsapp">WhatsApp Numarası</Label>
                        <Input
                          id="contactWhatsapp"
                          type="tel"
                          value={settings.contactWhatsapp || ''}
                          onChange={(e) =>
                            setSettings({
                              ...settings,
                              contactWhatsapp: e.target.value,
                            })
                          }
                          placeholder="+90 (555) 123 45 67"
                        />
                        <p className="text-xs text-muted-foreground">
                          WhatsApp iletişim butonu için kullanılacak numara
                        </p>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="contactAddress">Adres</Label>
                      <Textarea
                        id="contactAddress"
                        value={settings.contactAddress || ''}
                        onChange={(e) =>
                          setSettings({
                            ...settings,
                            contactAddress: e.target.value,
                          })
                        }
                        placeholder="İstanbul, Türkiye"
                        rows={2}
                      />
                    </div>
                  </div>

                  {/* Sosyal Medya Linkleri */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Sosyal Medya Linkleri</h3>
                    <p className="text-sm text-muted-foreground">
                      Sosyal medya hesaplarınızın bağlantılarını ekleyin
                    </p>
                    
                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="space-y-2">
                        <Label htmlFor="socialFacebook">Facebook</Label>
                        <Input
                          id="socialFacebook"
                          type="url"
                          value={settings.socialFacebook || ''}
                          onChange={(e) =>
                            setSettings({
                              ...settings,
                              socialFacebook: e.target.value,
                            })
                          }
                          placeholder="https://facebook.com/..."
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="socialTwitter">Twitter / X</Label>
                        <Input
                          id="socialTwitter"
                          type="url"
                          value={settings.socialTwitter || ''}
                          onChange={(e) =>
                            setSettings({
                              ...settings,
                              socialTwitter: e.target.value,
                            })
                          }
                          placeholder="https://twitter.com/..."
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="socialInstagram">Instagram</Label>
                        <Input
                          id="socialInstagram"
                          type="url"
                          value={settings.socialInstagram || ''}
                          onChange={(e) =>
                            setSettings({
                              ...settings,
                              socialInstagram: e.target.value,
                            })
                          }
                          placeholder="https://instagram.com/..."
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="socialLinkedin">LinkedIn</Label>
                        <Input
                          id="socialLinkedin"
                          type="url"
                          value={settings.socialLinkedin || ''}
                          onChange={(e) =>
                            setSettings({
                              ...settings,
                              socialLinkedin: e.target.value,
                            })
                          }
                          placeholder="https://linkedin.com/..."
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="socialYoutube">YouTube</Label>
                        <Input
                          id="socialYoutube"
                          type="url"
                          value={settings.socialYoutube || ''}
                          onChange={(e) =>
                            setSettings({
                              ...settings,
                              socialYoutube: e.target.value,
                            })
                          }
                          placeholder="https://youtube.com/..."
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="socialTiktok">TikTok</Label>
                        <Input
                          id="socialTiktok"
                          type="url"
                          value={settings.socialTiktok || ''}
                          onChange={(e) =>
                            setSettings({
                              ...settings,
                              socialTiktok: e.target.value,
                            })
                          }
                          placeholder="https://tiktok.com/@..."
                        />
                      </div>
                    </div>
                  </div>

                  {/* API Ayarları */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">API Entegrasyonları</h3>
                    
                    <div className="space-y-4 p-4 rounded-lg border">
                      <h4 className="font-medium">Google OAuth (SSO)</h4>
                      <div className="grid gap-4 md:grid-cols-2">
                        <div className="space-y-2">
                          <Label htmlFor="googleClientId">Client ID</Label>
                          <Input
                            id="googleClientId"
                            type="text"
                            value={settings.googleClientId || ''}
                            onChange={(e) =>
                              setSettings({
                                ...settings,
                                googleClientId: e.target.value,
                              })
                            }
                            placeholder="Google Client ID"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="googleClientSecret">Client Secret</Label>
                          <Input
                            id="googleClientSecret"
                            type="password"
                            value={settings.googleClientSecret || ''}
                            onChange={(e) =>
                              setSettings({
                                ...settings,
                                googleClientSecret: e.target.value,
                              })
                            }
                            placeholder="Google Client Secret"
                          />
                        </div>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Google Console'dan alınan OAuth 2.0 kimlik bilgileri
                      </p>
                    </div>

                    <div className="space-y-4 p-4 rounded-lg border">
                      <h4 className="font-medium">iyzico Ödeme Sistemi</h4>
                      <div className="grid gap-4 md:grid-cols-2">
                        <div className="space-y-2">
                          <Label htmlFor="iyzicoApiKey">API Key</Label>
                          <Input
                            id="iyzicoApiKey"
                            type="text"
                            value={settings.iyzicoApiKey || ''}
                            onChange={(e) =>
                              setSettings({
                                ...settings,
                                iyzicoApiKey: e.target.value,
                              })
                            }
                            placeholder="iyzico API Key"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="iyzicoSecretKey">Secret Key</Label>
                          <Input
                            id="iyzicoSecretKey"
                            type="password"
                            value={settings.iyzicoSecretKey || ''}
                            onChange={(e) =>
                              setSettings({
                                ...settings,
                                iyzicoSecretKey: e.target.value,
                              })
                            }
                            placeholder="iyzico Secret Key"
                          />
                        </div>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        iyzico Panel'den alınan API kimlik bilgileri
                      </p>
                    </div>
                  </div>

                  {/* Kaydet Butonu */}
                  <div className="flex items-center gap-3 pt-4">
                    <Button onClick={saveSettings} disabled={submitting}>
                      {submitting ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Kaydediliyor...
                        </>
                      ) : (
                        'Ayarları Kaydet'
                      )}
                    </Button>
                    <Button
                      variant="outline"
                      onClick={loadSettings}
                      disabled={settingsLoading}
                    >
                      İptal
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </TabsContent>
      </Tabs>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {editingSymbol ? 'Sembol Düzenle' : 'Yeni Sembol Ekle'}
            </DialogTitle>
            <DialogDescription>
              Rüya analizi için sembol bilgilerini girin
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit}>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="symbol">Sembol Adı</Label>
                <Input
                  id="symbol"
                  value={formData.symbol}
                  onChange={(e) =>
                    setFormData({ ...formData, symbol: e.target.value })
                  }
                  placeholder="Örn: Su, Yılan, Uçmak"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="category">Kategori</Label>
                <Select
                  value={formData.category}
                  onValueChange={(value) =>
                    setFormData({ ...formData, category: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((cat) => (
                      <SelectItem key={cat.value} value={cat.value}>
                        {cat.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="meaning">Anlam</Label>
                <Textarea
                  id="meaning"
                  value={formData.meaning}
                  onChange={(e) =>
                    setFormData({ ...formData, meaning: e.target.value })
                  }
                  placeholder="Bu sembolün rüyalardaki anlamını açıklayın..."
                  rows={4}
                  required
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={handleCloseDialog}
                disabled={submitting}
              >
                İptal
              </Button>
              <Button type="submit" disabled={submitting}>
                {submitting ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Kaydediliyor...
                  </>
                ) : (
                  'Kaydet'
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
