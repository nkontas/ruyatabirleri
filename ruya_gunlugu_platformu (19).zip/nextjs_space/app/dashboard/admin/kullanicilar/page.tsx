
'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { toast } from 'react-hot-toast';
import { 
  Search,
  Loader2, 
  Shield,
  ShieldOff,
  Crown,
  Trash2,
  ChevronLeft,
  ChevronRight,
  Ban,
  CheckCircle,
  Edit
} from 'lucide-react';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import Image from 'next/image';

interface User {
  id: string;
  name: string | null;
  username: string | null;
  email: string;
  image: string | null;
  isPremium: boolean;
  premiumUntil: string | null;
  isAdmin: boolean;
  isBlocked: boolean;
  blockedReason: string | null;
  blockedAt: string | null;
  dreamCount: number;
  createdAt: string;
  _count: {
    dreams: number;
    comments: number;
    sharedDreams: number;
  };
}

interface Pagination {
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

export default function KullanicilarPage() {
  const { data: session, status } = useSession() || {};
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [users, setUsers] = useState<User[]>([]);
  const [pagination, setPagination] = useState<Pagination>({
    total: 0,
    page: 1,
    limit: 20,
    totalPages: 0
  });
  const [search, setSearch] = useState('');
  const [actionLoading, setActionLoading] = useState(false);
  
  // Dialog states
  const [blockDialog, setBlockDialog] = useState(false);
  const [deleteDialog, setDeleteDialog] = useState(false);
  const [editDialog, setEditDialog] = useState(false);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [blockReason, setBlockReason] = useState('');
  
  // Edit form states
  const [editForm, setEditForm] = useState({
    name: '',
    username: '',
    email: '',
    bio: '',
    isPremium: false,
    premiumUntil: ''
  });

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/auth/signin');
    }
  }, [status, router]);

  useEffect(() => {
    if (session?.user) {
      loadUsers();
    }
  }, [session, pagination.page, search]);

  const loadUsers = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams({
        page: pagination.page.toString(),
        limit: pagination.limit.toString(),
        ...(search && { search })
      });

      const response = await fetch(`/api/admin/users?${params}`);
      
      if (!response.ok) {
        throw new Error('Kullanıcılar yüklenemedi');
      }

      const data = await response.json();
      setUsers(data.users);
      setPagination(data.pagination);
    } catch (error) {
      console.error('Kullanıcılar yüklenirken hata:', error);
      toast.error('Kullanıcılar yüklenemedi');
    } finally {
      setLoading(false);
    }
  };

  const handleTogglePremium = async (user: User) => {
    try {
      setActionLoading(true);
      const response = await fetch('/api/admin/users', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          action: 'togglePremium'
        })
      });

      if (!response.ok) {
        throw new Error('İşlem başarısız');
      }

      toast.success(user.isPremium ? 'Premium kaldırıldı' : 'Premium verildi');
      loadUsers();
    } catch (error) {
      console.error('Premium durumu değiştirilirken hata:', error);
      toast.error('İşlem başarısız oldu');
    } finally {
      setActionLoading(false);
    }
  };

  const handleToggleAdmin = async (user: User) => {
    try {
      setActionLoading(true);
      const response = await fetch('/api/admin/users', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          action: 'toggleAdmin'
        })
      });

      if (!response.ok) {
        throw new Error('İşlem başarısız');
      }

      toast.success(user.isAdmin ? 'Admin yetkisi kaldırıldı' : 'Admin yetkisi verildi');
      loadUsers();
    } catch (error) {
      console.error('Admin durumu değiştirilirken hata:', error);
      toast.error('İşlem başarısız oldu');
    } finally {
      setActionLoading(false);
    }
  };

  const handleBlockUser = async () => {
    if (!selectedUser) return;

    try {
      setActionLoading(true);
      const response = await fetch('/api/admin/users', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: selectedUser.id,
          action: 'block',
          reason: blockReason.trim() || 'Yönetici tarafından engellendi'
        })
      });

      if (!response.ok) {
        throw new Error('Kullanıcı engellenemedi');
      }

      toast.success('Kullanıcı engellendi');
      setBlockDialog(false);
      setBlockReason('');
      setSelectedUser(null);
      loadUsers();
    } catch (error) {
      console.error('Kullanıcı engellenirken hata:', error);
      toast.error('Kullanıcı engellenemedi');
    } finally {
      setActionLoading(false);
    }
  };

  const handleUnblockUser = async (user: User) => {
    try {
      setActionLoading(true);
      const response = await fetch('/api/admin/users', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          action: 'unblock'
        })
      });

      if (!response.ok) {
        throw new Error('Engel kaldırılamadı');
      }

      toast.success('Engel kaldırıldı');
      loadUsers();
    } catch (error) {
      console.error('Engel kaldırılırken hata:', error);
      toast.error('Engel kaldırılamadı');
    } finally {
      setActionLoading(false);
    }
  };

  const handleDeleteUser = async () => {
    if (!selectedUser) return;

    try {
      setActionLoading(true);
      const response = await fetch(`/api/admin/users?userId=${selectedUser.id}`, {
        method: 'DELETE'
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Kullanıcı silinemedi');
      }

      toast.success('Kullanıcı silindi');
      setDeleteDialog(false);
      setSelectedUser(null);
      loadUsers();
    } catch (error: any) {
      console.error('Kullanıcı silinirken hata:', error);
      toast.error(error.message || 'Kullanıcı silinemedi');
    } finally {
      setActionLoading(false);
    }
  };

  const handleEditUser = async () => {
    if (!selectedUser) return;

    try {
      setActionLoading(true);
      const response = await fetch(`/api/admin/users/${selectedUser.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editForm)
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Kullanıcı güncellenemedi');
      }

      toast.success('Kullanıcı başarıyla güncellendi');
      setEditDialog(false);
      setSelectedUser(null);
      setEditForm({ name: '', username: '', email: '', bio: '', isPremium: false, premiumUntil: '' });
      loadUsers();
    } catch (error: any) {
      console.error('Kullanıcı güncellenirken hata:', error);
      toast.error(error.message || 'Kullanıcı güncellenemedi');
    } finally {
      setActionLoading(false);
    }
  };

  const openEditDialog = (user: User) => {
    setSelectedUser(user);
    setEditForm({
      name: user.name || '',
      username: user.username || '',
      email: user.email || '',
      bio: '',
      isPremium: user.isPremium,
      premiumUntil: user.premiumUntil ? new Date(user.premiumUntil).toISOString().split('T')[0] : ''
    });
    setEditDialog(true);
  };

  const handleSearchChange = (value: string) => {
    setSearch(value);
    setPagination(prev => ({ ...prev, page: 1 }));
  };

  if (status === 'loading' || loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-white mb-2">Kullanıcı Yönetimi</h2>
        <p className="text-purple-200">
          Kullanıcıları yönetin, engelleyin veya silin
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Tüm Kullanıcılar</CardTitle>
          <CardDescription>
            Toplam {pagination.total} kullanıcı
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                placeholder="İsim, email veya kullanıcı adı ile ara..."
                value={search}
                onChange={(e) => handleSearchChange(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Kullanıcı</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Rüyalar</TableHead>
                  <TableHead>Durum</TableHead>
                  <TableHead>Kayıt Tarihi</TableHead>
                  <TableHead className="text-right">İşlemler</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                      Kullanıcı bulunamadı
                    </TableCell>
                  </TableRow>
                ) : (
                  users.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <div className="relative w-10 h-10 rounded-full bg-muted overflow-hidden">
                            {user.image ? (
                              <Image
                                src={user.image}
                                alt={user.name || user.username || 'Kullanıcı'}
                                fill
                                className="object-cover"
                              />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center text-lg font-semibold">
                                {(user.name || user.username || user.email)?.[0]?.toUpperCase()}
                              </div>
                            )}
                          </div>
                          <div>
                            <div className="font-medium">
                              {user.name || user.username || 'İsimsiz'}
                            </div>
                            {user.username && (
                              <div className="text-sm text-muted-foreground">
                                @{user.username}
                              </div>
                            )}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>
                        <div className="text-sm">
                          <div>{user._count.dreams} rüya</div>
                          <div className="text-muted-foreground">
                            {user._count.comments} yorum
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-col gap-1">
                          {user.isAdmin && (
                            <Badge variant="default" className="w-fit">
                              <Shield className="w-3 h-3 mr-1" />
                              Admin
                            </Badge>
                          )}
                          {user.isPremium && (
                            <Badge variant="secondary" className="w-fit">
                              <Crown className="w-3 h-3 mr-1" />
                              Premium
                            </Badge>
                          )}
                          {user.isBlocked && (
                            <Badge variant="destructive" className="w-fit">
                              <Ban className="w-3 h-3 mr-1" />
                              Engelli
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        {new Date(user.createdAt).toLocaleDateString('tr-TR')}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center justify-end gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => openEditDialog(user)}
                            disabled={actionLoading}
                          >
                            <Edit className="w-4 h-4 mr-1" />
                            Düzenle
                          </Button>

                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleTogglePremium(user)}
                            disabled={actionLoading}
                          >
                            <Crown className="w-4 h-4 mr-1" />
                            {user.isPremium ? 'Premium Kaldır' : 'Premium Ver'}
                          </Button>
                          
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleToggleAdmin(user)}
                            disabled={actionLoading}
                          >
                            <Shield className="w-4 h-4 mr-1" />
                            {user.isAdmin ? 'Admin Kaldır' : 'Admin Yap'}
                          </Button>

                          {user.isBlocked ? (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleUnblockUser(user)}
                              disabled={actionLoading}
                            >
                              <CheckCircle className="w-4 h-4 mr-1" />
                              Engeli Kaldır
                            </Button>
                          ) : (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setSelectedUser(user);
                                setBlockDialog(true);
                              }}
                              disabled={actionLoading}
                            >
                              <Ban className="w-4 h-4 mr-1" />
                              Engelle
                            </Button>
                          )}

                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => {
                              setSelectedUser(user);
                              setDeleteDialog(true);
                            }}
                            disabled={actionLoading}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>

          {/* Pagination */}
          {pagination.totalPages > 1 && (
            <div className="flex items-center justify-between mt-4">
              <div className="text-sm text-muted-foreground">
                {pagination.page} / {pagination.totalPages} sayfa
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setPagination(prev => ({ ...prev, page: prev.page - 1 }))}
                  disabled={pagination.page === 1 || loading}
                >
                  <ChevronLeft className="w-4 h-4" />
                  Önceki
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setPagination(prev => ({ ...prev, page: prev.page + 1 }))}
                  disabled={pagination.page === pagination.totalPages || loading}
                >
                  Sonraki
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Block Dialog */}
      <Dialog open={blockDialog} onOpenChange={setBlockDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Kullanıcıyı Engelle</DialogTitle>
            <DialogDescription>
              {selectedUser?.name || selectedUser?.email} adlı kullanıcıyı engellemek istediğinize emin misiniz?
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <Label htmlFor="blockReason">Engelleme Nedeni</Label>
            <Textarea
              id="blockReason"
              placeholder="İsteğe bağlı - engelleme nedenini yazın..."
              value={blockReason}
              onChange={(e) => setBlockReason(e.target.value)}
              rows={3}
              className="mt-2"
            />
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setBlockDialog(false);
                setBlockReason('');
                setSelectedUser(null);
              }}
              disabled={actionLoading}
            >
              İptal
            </Button>
            <Button
              variant="destructive"
              onClick={handleBlockUser}
              disabled={actionLoading}
            >
              {actionLoading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Engelle
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={editDialog} onOpenChange={setEditDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Kullanıcıyı Düzenle</DialogTitle>
            <DialogDescription>
              {selectedUser?.name || selectedUser?.email} adlı kullanıcının bilgilerini düzenleyin
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <Label htmlFor="editName">İsim</Label>
              <Input
                id="editName"
                placeholder="İsim"
                value={editForm.name}
                onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                className="mt-2"
              />
            </div>
            
            <div>
              <Label htmlFor="editUsername">Kullanıcı Adı</Label>
              <Input
                id="editUsername"
                placeholder="Kullanıcı adı"
                value={editForm.username}
                onChange={(e) => setEditForm({ ...editForm, username: e.target.value })}
                className="mt-2"
              />
            </div>
            
            <div>
              <Label htmlFor="editEmail">Email</Label>
              <Input
                id="editEmail"
                type="email"
                placeholder="Email"
                value={editForm.email}
                onChange={(e) => setEditForm({ ...editForm, email: e.target.value })}
                className="mt-2"
              />
            </div>
            
            <div>
              <Label htmlFor="editBio">Biyografi</Label>
              <Textarea
                id="editBio"
                placeholder="Biyografi (isteğe bağlı)"
                value={editForm.bio}
                onChange={(e) => setEditForm({ ...editForm, bio: e.target.value })}
                rows={3}
                className="mt-2"
              />
            </div>
            
            <div className="flex items-center justify-between space-x-2">
              <div className="space-y-0.5">
                <Label htmlFor="isPremium">Premium Üyelik</Label>
                <p className="text-sm text-muted-foreground">
                  Kullanıcıya premium üyelik ver
                </p>
              </div>
              <Switch
                id="isPremium"
                checked={editForm.isPremium}
                onCheckedChange={(checked) => setEditForm({ ...editForm, isPremium: checked })}
              />
            </div>
            
            {editForm.isPremium && (
              <div>
                <Label htmlFor="premiumUntil">Premium Bitiş Tarihi</Label>
                <Input
                  id="premiumUntil"
                  type="date"
                  value={editForm.premiumUntil}
                  onChange={(e) => setEditForm({ ...editForm, premiumUntil: e.target.value })}
                  className="mt-2"
                />
                <p className="text-sm text-muted-foreground mt-1">
                  Premium üyeliğin geçerli olacağı son tarihi seçin
                </p>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setEditDialog(false);
                setSelectedUser(null);
                setEditForm({ name: '', username: '', email: '', bio: '', isPremium: false, premiumUntil: '' });
              }}
              disabled={actionLoading}
            >
              İptal
            </Button>
            <Button
              onClick={handleEditUser}
              disabled={actionLoading}
            >
              {actionLoading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Kaydet
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Dialog */}
      <Dialog open={deleteDialog} onOpenChange={setDeleteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Kullanıcıyı Sil</DialogTitle>
            <DialogDescription>
              {selectedUser?.name || selectedUser?.email} adlı kullanıcıyı ve tüm verilerini kalıcı olarak silmek istediğinize emin misiniz? Bu işlem geri alınamaz.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setDeleteDialog(false);
                setSelectedUser(null);
              }}
              disabled={actionLoading}
            >
              İptal
            </Button>
            <Button
              variant="destructive"
              onClick={handleDeleteUser}
              disabled={actionLoading}
            >
              {actionLoading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Sil
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
