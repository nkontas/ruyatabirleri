
'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Mail, MailOpen, Trash2, Send, Eye, Clock } from 'lucide-react';
import { format } from 'date-fns';
import { tr } from 'date-fns/locale';
import { toast } from 'react-hot-toast';

interface ContactMessage {
  id: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  isRead: boolean;
  isReplied: boolean;
  reply: string | null;
  repliedAt: Date | null;
  createdAt: Date;
}

export default function ContactMessagesPage() {
  const [messages, setMessages] = useState<ContactMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'unread' | 'read' | 'replied'>('all');
  const [selectedMessage, setSelectedMessage] = useState<ContactMessage | null>(null);
  const [showDetailDialog, setShowDetailDialog] = useState(false);
  const [showReplyDialog, setShowReplyDialog] = useState(false);
  const [replyText, setReplyText] = useState('');
  const [processing, setProcessing] = useState(false);

  const fetchMessages = async () => {
    try {
      setLoading(true);
      const response = await fetch(`/api/admin/contact-messages?filter=${filter}`);
      if (response.ok) {
        const data = await response.json();
        setMessages(data);
      } else {
        toast.error('Mesajlar yüklenirken hata oluştu');
      }
    } catch (error) {
      console.error('Fetch messages error:', error);
      toast.error('Mesajlar yüklenirken hata oluştu');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMessages();
  }, [filter]);

  const markAsRead = async (id: string) => {
    try {
      const response = await fetch(`/api/admin/contact-messages/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isRead: true }),
      });

      if (response.ok) {
        fetchMessages();
        toast.success('Mesaj okundu olarak işaretlendi');
      }
    } catch (error) {
      console.error('Mark as read error:', error);
      toast.error('İşlem başarısız');
    }
  };

  const deleteMessage = async (id: string) => {
    if (!confirm('Bu mesajı silmek istediğinizden emin misiniz?')) {
      return;
    }

    try {
      const response = await fetch(`/api/admin/contact-messages/${id}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        fetchMessages();
        toast.success('Mesaj silindi');
      } else {
        toast.error('Mesaj silinemedi');
      }
    } catch (error) {
      console.error('Delete message error:', error);
      toast.error('Mesaj silinemedi');
    }
  };

  const sendReply = async () => {
    if (!selectedMessage || !replyText.trim()) {
      toast.error('Lütfen bir yanıt yazın');
      return;
    }

    try {
      setProcessing(true);
      const response = await fetch(`/api/admin/contact-messages/${selectedMessage.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reply: replyText }),
      });

      if (response.ok) {
        toast.success('Yanıt kaydedildi');
        setShowReplyDialog(false);
        setReplyText('');
        fetchMessages();
      } else {
        toast.error('Yanıt gönderilemedi');
      }
    } catch (error) {
      console.error('Send reply error:', error);
      toast.error('Yanıt gönderilemedi');
    } finally {
      setProcessing(false);
    }
  };

  const openDetailDialog = async (message: ContactMessage) => {
    setSelectedMessage(message);
    setShowDetailDialog(true);

    if (!message.isRead) {
      await markAsRead(message.id);
    }
  };

  const openReplyDialog = (message: ContactMessage) => {
    setSelectedMessage(message);
    setReplyText(message.reply || '');
    setShowReplyDialog(true);
  };

  const stats = {
    total: messages.length,
    unread: messages.filter((m) => !m.isRead).length,
    replied: messages.filter((m) => m.isReplied).length,
  };

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <div className="mb-6">
        <h1 className="text-3xl font-bold mb-2">İletişim Mesajları</h1>
        <p className="text-muted-foreground">
          Kullanıcılardan gelen iletişim formları ve mesajları
        </p>
      </div>

      {/* İstatistikler */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Toplam Mesaj</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Okunmamış</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{stats.unread}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Yanıtlanan</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.replied}</div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs */}
      <Tabs value={filter} onValueChange={(v: any) => setFilter(v)} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="all">Tümü</TabsTrigger>
          <TabsTrigger value="unread">Okunmamış</TabsTrigger>
          <TabsTrigger value="read">Okundu</TabsTrigger>
          <TabsTrigger value="replied">Yanıtlanan</TabsTrigger>
        </TabsList>

        <TabsContent value={filter} className="mt-6">
          {loading ? (
            <div className="text-center py-12">
              <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto"></div>
              <p className="mt-4 text-muted-foreground">Mesajlar yükleniyor...</p>
            </div>
          ) : messages.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <Mail className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                <p className="text-muted-foreground">Henüz mesaj bulunmuyor</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {messages.map((message) => (
                <Card key={message.id} className={!message.isRead ? 'border-l-4 border-l-primary' : ''}>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <CardTitle className="text-lg">{message.subject}</CardTitle>
                          {!message.isRead && (
                            <Badge variant="secondary">Yeni</Badge>
                          )}
                          {message.isReplied && (
                            <Badge variant="default" className="bg-green-600">Yanıtlandı</Badge>
                          )}
                        </div>
                        <CardDescription>
                          <span className="font-medium">{message.name}</span> ({message.email})
                        </CardDescription>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => openDetailDialog(message)}
                        >
                          <Eye className="w-4 h-4 mr-2" />
                          Görüntüle
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => openReplyDialog(message)}
                        >
                          <Send className="w-4 h-4 mr-2" />
                          Yanıtla
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => deleteMessage(message.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground line-clamp-2">{message.message}</p>
                    <div className="flex items-center gap-4 mt-3 text-xs text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {format(new Date(message.createdAt), 'dd MMM yyyy HH:mm', { locale: tr })}
                      </div>
                      {message.isRead ? (
                        <div className="flex items-center gap-1">
                          <MailOpen className="w-3 h-3" />
                          Okundu
                        </div>
                      ) : (
                        <div className="flex items-center gap-1">
                          <Mail className="w-3 h-3" />
                          Okunmadı
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Detay Dialog */}
      <Dialog open={showDetailDialog} onOpenChange={setShowDetailDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{selectedMessage?.subject}</DialogTitle>
            <DialogDescription>
              <span className="font-medium">{selectedMessage?.name}</span> ({selectedMessage?.email})
              <br />
              {selectedMessage?.createdAt && format(new Date(selectedMessage.createdAt), 'dd MMMM yyyy HH:mm', { locale: tr })}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <h4 className="font-semibold mb-2">Mesaj:</h4>
              <p className="text-sm text-muted-foreground whitespace-pre-wrap">{selectedMessage?.message}</p>
            </div>
            {selectedMessage?.isReplied && selectedMessage?.reply && (
              <div className="bg-muted p-4 rounded-lg">
                <h4 className="font-semibold mb-2">Yanıtınız:</h4>
                <p className="text-sm text-muted-foreground whitespace-pre-wrap">{selectedMessage.reply}</p>
                {selectedMessage.repliedAt && (
                  <p className="text-xs text-muted-foreground mt-2">
                    {format(new Date(selectedMessage.repliedAt), 'dd MMM yyyy HH:mm', { locale: tr })}
                  </p>
                )}
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDetailDialog(false)}>
              Kapat
            </Button>
            <Button onClick={() => {
              setShowDetailDialog(false);
              openReplyDialog(selectedMessage!);
            }}>
              <Send className="w-4 h-4 mr-2" />
              Yanıtla
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Yanıt Dialog */}
      <Dialog open={showReplyDialog} onOpenChange={setShowReplyDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Mesajı Yanıtla</DialogTitle>
            <DialogDescription>
              {selectedMessage?.name} adlı kullanıcıya yanıt yazın
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="bg-muted p-4 rounded-lg">
              <p className="text-sm font-medium mb-1">Gelen Mesaj:</p>
              <p className="text-sm text-muted-foreground line-clamp-3">{selectedMessage?.message}</p>
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Yanıtınız:</label>
              <Textarea
                placeholder="Yanıtınızı buraya yazın..."
                value={replyText}
                onChange={(e) => setReplyText(e.target.value)}
                rows={6}
              />
              <p className="text-xs text-muted-foreground mt-2">
                Not: Bu yanıt sadece sisteme kaydedilecektir. Email gönderimi için ayrıca mail servisi entegrasyonu gereklidir.
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowReplyDialog(false)} disabled={processing}>
              İptal
            </Button>
            <Button onClick={sendReply} disabled={processing || !replyText.trim()}>
              {processing ? (
                <>
                  <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
                  Kaydediliyor...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4 mr-2" />
                  Yanıtı Kaydet
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
