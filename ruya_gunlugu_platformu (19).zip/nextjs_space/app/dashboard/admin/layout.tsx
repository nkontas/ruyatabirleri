
'use client';

import { usePathname } from 'next/navigation';
import Link from 'next/link';
import { cn } from '@/lib/utils';
import { 
  Settings, 
  Shield, 
  Users, 
  BarChart3,
  BookOpen,
  Mail
} from 'lucide-react';

const adminNavItems = [
  {
    title: 'Genel Ayarlar',
    href: '/dashboard/admin/ayarlar',
    icon: Settings
  },
  {
    title: 'Kullanıcı Yönetimi',
    href: '/dashboard/admin/kullanicilar',
    icon: Users
  },
  {
    title: 'İletişim Mesajları',
    href: '/dashboard/admin/iletisim-mesajlari',
    icon: Mail
  },
  {
    title: 'Kötü Kelimeler',
    href: '/dashboard/admin/kotu-kelimeler',
    icon: Shield
  }
];

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      <div className="container mx-auto p-6">
        {/* Admin Header */}
        <div className="mb-6 bg-white/10 backdrop-blur-md rounded-lg p-6 border border-white/20">
          <div className="flex items-center gap-3 mb-4">
            <Shield className="w-8 h-8 text-yellow-400" />
            <div>
              <h1 className="text-2xl font-bold text-white">Admin Paneli</h1>
              <p className="text-purple-200">Platform yönetim merkezi</p>
            </div>
          </div>
          
          {/* Navigation Tabs */}
          <nav className="flex gap-2 overflow-x-auto">
            {adminNavItems.map((item) => {
              const Icon = item.icon;
              const isActive = pathname === item.href;
              
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    'flex items-center gap-2 px-4 py-2 rounded-lg transition-all whitespace-nowrap',
                    isActive
                      ? 'bg-white/20 text-white font-semibold'
                      : 'text-purple-200 hover:bg-white/10 hover:text-white'
                  )}
                >
                  <Icon className="w-4 h-4" />
                  {item.title}
                </Link>
              );
            })}
          </nav>
        </div>

        {/* Page Content */}
        {children}
      </div>
    </div>
  );
}
