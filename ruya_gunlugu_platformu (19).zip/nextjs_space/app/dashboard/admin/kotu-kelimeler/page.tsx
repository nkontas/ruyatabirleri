
'use client';

import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from 'react-hot-toast';
import { 
  Plus,
  Loader2, 
  Trash2,
  Shield,
  ShieldAlert,
  ShieldCheck
} from 'lucide-react';

interface BadWord {
  id: string;
  word: string;
  severity: number;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export default function KotuKelimelerPage() {
  const { data: session, status } = useSession() || {};
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [badWords, setBadWords] = useState<BadWord[]>([]);
  const [actionLoading, setActionLoading] = useState(false);
  
  // Dialog states
  const [addDialog, setAddDialog] = useState(false);
  const [deleteDialog, setDeleteDialog] = useState(false);
  const [selectedWord, setSelectedWord] = useState<BadWord | null>(null);
  
  // Form states
  const [newWord, setNewWord] = useState('');
  const [severity, setSeverity] = useState('5');

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/auth/signin');
    }
  }, [status, router]);

  useEffect(() => {
    if (session?.user) {
      loadBadWords();
    }
  }, [session]);

  const loadBadWords = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/admin/bad-words');
      
      if (!response.ok) {
        throw new Error('Kötü kelimeler yüklenemedi');
      }

      const data = await response.json();
      setBadWords(data);
    } catch (error) {
      console.error('Kötü kelimeler yüklenirken hata:', error);
      toast.error('Kötü kelimeler yüklenemedi');
    } finally {
      setLoading(false);
    }
  };

  const handleAddWord = async () => {
    if (!newWord.trim()) {
      toast.error('Kelime boş olamaz');
      return;
    }

    try {
      setActionLoading(true);
      const response = await fetch('/api/admin/bad-words', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          word: newWord.trim(),
          severity: parseInt(severity)
        })
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Kelime eklenemedi');
      }

      toast.success('Kötü kelime eklendi');
      setAddDialog(false);
      setNewWord('');
      setSeverity('5');
      loadBadWords();
    } catch (error: any) {
      console.error('Kötü kelime eklenirken hata:', error);
      toast.error(error.message || 'Kelime eklenemedi');
    } finally {
      setActionLoading(false);
    }
  };

  const handleToggleActive = async (word: BadWord) => {
    try {
      setActionLoading(true);
      const response = await fetch('/api/admin/bad-words', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: word.id,
          isActive: !word.isActive
        })
      });

      if (!response.ok) {
        throw new Error('Durum değiştirilemedi');
      }

      toast.success(word.isActive ? 'Kelime pasifleştirildi' : 'Kelime aktifleştirildi');
      loadBadWords();
    } catch (error) {
      console.error('Durum değiştirilirken hata:', error);
      toast.error('Durum değiştirilemedi');
    } finally {
      setActionLoading(false);
    }
  };

  const handleDeleteWord = async () => {
    if (!selectedWord) return;

    try {
      setActionLoading(true);
      const response = await fetch(`/api/admin/bad-words?id=${selectedWord.id}`, {
        method: 'DELETE'
      });

      if (!response.ok) {
        throw new Error('Kelime silinemedi');
      }

      toast.success('Kötü kelime silindi');
      setDeleteDialog(false);
      setSelectedWord(null);
      loadBadWords();
    } catch (error) {
      console.error('Kelime silinirken hata:', error);
      toast.error('Kelime silinemedi');
    } finally {
      setActionLoading(false);
    }
  };

  const getSeverityBadge = (severity: number) => {
    if (severity <= 3) {
      return (
        <Badge variant="secondary" className="gap-1">
          <ShieldCheck className="w-3 h-3" />
          Düşük ({severity})
        </Badge>
      );
    } else if (severity <= 7) {
      return (
        <Badge variant="default" className="gap-1">
          <Shield className="w-3 h-3" />
          Orta ({severity})
        </Badge>
      );
    } else {
      return (
        <Badge variant="destructive" className="gap-1">
          <ShieldAlert className="w-3 h-3" />
          Yüksek ({severity})
        </Badge>
      );
    }
  };

  if (status === 'loading' || loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white mb-2">Kötü Kelimeler</h2>
          <p className="text-purple-200">
            Platformda engellenen kelimeleri yönetin
          </p>
        </div>
        <Button onClick={() => setAddDialog(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Yeni Kelime Ekle
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Kötü Kelimeler Listesi</CardTitle>
          <CardDescription>
            Toplam {badWords.length} kötü kelime ({badWords.filter(w => w.isActive).length} aktif)
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Kelime</TableHead>
                  <TableHead>Şiddet Seviyesi</TableHead>
                  <TableHead>Durum</TableHead>
                  <TableHead>Eklenme Tarihi</TableHead>
                  <TableHead className="text-right">İşlemler</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {badWords.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                      Henüz kötü kelime eklenmemiş
                    </TableCell>
                  </TableRow>
                ) : (
                  badWords.map((word) => (
                    <TableRow key={word.id}>
                      <TableCell className="font-medium">
                        {word.word}
                      </TableCell>
                      <TableCell>
                        {getSeverityBadge(word.severity)}
                      </TableCell>
                      <TableCell>
                        <Badge variant={word.isActive ? 'default' : 'secondary'}>
                          {word.isActive ? 'Aktif' : 'Pasif'}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {new Date(word.createdAt).toLocaleDateString('tr-TR')}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center justify-end gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleToggleActive(word)}
                            disabled={actionLoading}
                          >
                            {word.isActive ? 'Pasifleştir' : 'Aktifleştir'}
                          </Button>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => {
                              setSelectedWord(word);
                              setDeleteDialog(true);
                            }}
                            disabled={actionLoading}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Add Dialog */}
      <Dialog open={addDialog} onOpenChange={setAddDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Yeni Kötü Kelime Ekle</DialogTitle>
            <DialogDescription>
              Platformda engellenecek yeni bir kelime ekleyin
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <Label htmlFor="word">Kelime</Label>
              <Input
                id="word"
                placeholder="Engellenecek kelimeyi girin..."
                value={newWord}
                onChange={(e) => setNewWord(e.target.value)}
                className="mt-2"
              />
            </div>
            <div>
              <Label htmlFor="severity">Şiddet Seviyesi (1-10)</Label>
              <Select value={severity} onValueChange={setSeverity}>
                <SelectTrigger className="mt-2">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">1 - Çok Düşük</SelectItem>
                  <SelectItem value="2">2</SelectItem>
                  <SelectItem value="3">3 - Düşük</SelectItem>
                  <SelectItem value="4">4</SelectItem>
                  <SelectItem value="5">5 - Orta</SelectItem>
                  <SelectItem value="6">6</SelectItem>
                  <SelectItem value="7">7 - Yüksek</SelectItem>
                  <SelectItem value="8">8</SelectItem>
                  <SelectItem value="9">9</SelectItem>
                  <SelectItem value="10">10 - Çok Yüksek</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setAddDialog(false);
                setNewWord('');
                setSeverity('5');
              }}
              disabled={actionLoading}
            >
              İptal
            </Button>
            <Button
              onClick={handleAddWord}
              disabled={actionLoading || !newWord.trim()}
            >
              {actionLoading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Ekle
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Dialog */}
      <Dialog open={deleteDialog} onOpenChange={setDeleteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Kötü Kelimeyi Sil</DialogTitle>
            <DialogDescription>
              &quot;{selectedWord?.word}&quot; kelimesini silmek istediğinize emin misiniz?
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setDeleteDialog(false);
                setSelectedWord(null);
              }}
              disabled={actionLoading}
            >
              İptal
            </Button>
            <Button
              variant="destructive"
              onClick={handleDeleteWord}
              disabled={actionLoading}
            >
              {actionLoading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Sil
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
