"use client";

import { useState, useEffect } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { UserAvatar } from "@/components/user-avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, Users, UserPlus, ArrowLeft, UserCheck, UserX, MessageCircle } from "lucide-react";
import { toast } from "react-hot-toast";
import Link from "next/link";

interface Friend {
  id: string;
  name: string | null;
  username: string | null;
  image: string | null;
  bio: string | null;
  friendshipId: string;
  since: string;
}

interface FriendRequest {
  id: string;
  sender: {
    id: string;
    name: string | null;
    username: string | null;
    image: string | null;
    bio: string | null;
  };
  createdAt: string;
}

export default function ArkadaslarPage() {
  const router = useRouter();
  const { data: session, status } = useSession() || {};
  const [loading, setLoading] = useState(true);
  const [friends, setFriends] = useState<Friend[]>([]);
  const [requests, setRequests] = useState<FriendRequest[]>([]);
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  useEffect(() => {
    if (status === "unauthenticated") {
      router.push("/auth/giris");
    } else if (status === "authenticated") {
      fetchData();
    }
  }, [status, router]);

  const fetchData = async () => {
    try {
      const [friendsRes, requestsRes] = await Promise.all([
        fetch("/api/friendship/list"),
        fetch("/api/friendship/requests"),
      ]);

      if (friendsRes.ok) {
        const friendsData = await friendsRes.json();
        setFriends(friendsData.friends || []);
      }

      if (requestsRes.ok) {
        const requestsData = await requestsRes.json();
        setRequests(requestsData.requests || []);
      }
    } catch (error) {
      console.error("Veri yükleme hatası:", error);
      toast.error("Veriler yüklenirken hata oluştu");
    } finally {
      setLoading(false);
    }
  };

  const handleRespond = async (friendshipId: string, action: "accept" | "reject") => {
    setActionLoading(friendshipId);
    try {
      const response = await fetch("/api/friendship/respond", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ friendshipId, action }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || "İstek yanıtlanamadı");
      }

      toast.success(action === "accept" ? "Arkadaşlık isteği kabul edildi" : "Arkadaşlık isteği reddedildi");
      fetchData();
    } catch (error: any) {
      toast.error(error.message || "Bir hata oluştu");
    } finally {
      setActionLoading(null);
    }
  };

  if (loading || status === "loading") {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-purple-600" />
      </div>
    );
  }

  return (
    <div className="container max-w-5xl mx-auto px-4 py-8">
      <Button
        variant="ghost"
        onClick={() => router.push("/dashboard")}
        className="mb-4 hover:bg-purple-100 dark:hover:bg-purple-900/20"
      >
        <ArrowLeft className="mr-2 h-4 w-4" />
        Ana Menüye Dön
      </Button>

      <h1 className="text-3xl font-bold mb-8 bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
        Arkadaşlarım
      </h1>

      <Tabs defaultValue="friends" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="friends" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            Arkadaşlar ({friends.length})
          </TabsTrigger>
          <TabsTrigger value="requests" className="flex items-center gap-2">
            <UserPlus className="h-4 w-4" />
            İstekler ({requests.length})
          </TabsTrigger>
        </TabsList>

        {/* Arkadaş Listesi */}
        <TabsContent value="friends">
          {friends.length === 0 ? (
            <Card>
              <CardContent className="pt-6">
                <div className="text-center py-12">
                  <Users className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground mb-4">
                    Henüz arkadaşınız yok
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Topluluk bölümünden diğer kullanıcıların rüyalarını keşfedin ve arkadaşlık isteği gönderin
                  </p>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4 md:grid-cols-2">
              {friends.map((friend) => (
                <Card key={friend.id} className="hover:shadow-lg transition-shadow">
                  <CardContent className="pt-6">
                    <div className="flex items-start gap-4">
                      <Link href={`/dashboard/kullanici/${friend.id}`}>
                        <div className="cursor-pointer hover:ring-2 hover:ring-purple-500 transition-all rounded-full">
                          <UserAvatar 
                            image={friend.image}
                            name={friend.name || friend.username}
                            className="w-16 h-16"
                          />
                        </div>
                      </Link>

                      <div className="flex-1 min-w-0">
                        <Link 
                          href={`/dashboard/kullanici/${friend.id}`}
                          className="hover:underline"
                        >
                          <h3 className="font-semibold truncate">
                            {friend.name || friend.username}
                          </h3>
                        </Link>
                        {friend.username && (
                          <p className="text-sm text-muted-foreground truncate">
                            @{friend.username}
                          </p>
                        )}
                        {friend.bio && (
                          <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                            {friend.bio}
                          </p>
                        )}
                        <p className="text-xs text-muted-foreground mt-2">
                          Arkadaş: {new Date(friend.since).toLocaleDateString("tr-TR")}
                        </p>

                        <Link href={`/dashboard/mesajlar/${friend.id}`}>
                          <Button 
                            variant="outline" 
                            size="sm" 
                            className="mt-3 w-full"
                          >
                            <MessageCircle className="mr-2 h-3 w-3" />
                            Mesaj Gönder
                          </Button>
                        </Link>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* Arkadaşlık İstekleri */}
        <TabsContent value="requests">
          {requests.length === 0 ? (
            <Card>
              <CardContent className="pt-6">
                <div className="text-center py-12">
                  <UserPlus className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">
                    Bekleyen arkadaşlık isteğiniz yok
                  </p>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4">
              {requests.map((request) => (
                <Card key={request.id}>
                  <CardContent className="pt-6">
                    <div className="flex items-start gap-4">
                      <Link href={`/dashboard/kullanici/${request.sender.id}`}>
                        <div className="cursor-pointer hover:ring-2 hover:ring-purple-500 transition-all rounded-full">
                          <UserAvatar 
                            image={request.sender.image}
                            name={request.sender.name || request.sender.username}
                            className="w-16 h-16"
                          />
                        </div>
                      </Link>

                      <div className="flex-1 min-w-0">
                        <Link 
                          href={`/dashboard/kullanici/${request.sender.id}`}
                          className="hover:underline"
                        >
                          <h3 className="font-semibold">
                            {request.sender.name || request.sender.username}
                          </h3>
                        </Link>
                        {request.sender.username && (
                          <p className="text-sm text-muted-foreground">
                            @{request.sender.username}
                          </p>
                        )}
                        {request.sender.bio && (
                          <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                            {request.sender.bio}
                          </p>
                        )}
                        <p className="text-xs text-muted-foreground mt-2">
                          {new Date(request.createdAt).toLocaleDateString("tr-TR", {
                            year: "numeric",
                            month: "long",
                            day: "numeric",
                          })}
                        </p>

                        <div className="flex gap-2 mt-3">
                          <Button
                            size="sm"
                            className="bg-green-600 hover:bg-green-700"
                            onClick={() => handleRespond(request.id, "accept")}
                            disabled={actionLoading === request.id}
                          >
                            {actionLoading === request.id ? (
                              <Loader2 className="h-4 w-4 animate-spin" />
                            ) : (
                              <>
                                <UserCheck className="mr-2 h-3 w-3" />
                                Kabul Et
                              </>
                            )}
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleRespond(request.id, "reject")}
                            disabled={actionLoading === request.id}
                          >
                            <UserX className="mr-2 h-3 w-3" />
                            Reddet
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
