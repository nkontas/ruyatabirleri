
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { redirect } from 'next/navigation';
import AllDreamsPage from '@/components/dashboard/all-dreams-page';

export default async function RuyalarimPage() {
  const session = await getServerSession(authOptions);

  if (!session) {
    redirect('/auth/giris');
  }

  return <AllDreamsPage />;
}
