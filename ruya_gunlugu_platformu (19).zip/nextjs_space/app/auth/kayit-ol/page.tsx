
'use client';

import { useState } from 'react';
import { signIn } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Moon, Mail, Lock, Eye, EyeOff, User, Chrome, Sparkles } from 'lucide-react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Textarea } from '@/components/ui/textarea';

export default function RegisterPage() {
  const [formData, setFormData] = useState({
    name: '',
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
    acceptTerms: false,
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [profileCompleteData, setProfileCompleteData] = useState({
    bio: '',
    dateOfBirth: '',
    gender: '',
    showDreamCount: true,
    showBio: true,
    showAge: false,
    showGender: false,
  });
  const [isSavingProfile, setIsSavingProfile] = useState(false);
  const router = useRouter();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Form validasyonu
    if (formData.password !== formData.confirmPassword) {
      toast.error('Şifreler eşleşmiyor. Lütfen kontrol edin.');
      setIsLoading(false);
      return;
    }

    if (!formData.acceptTerms) {
      toast.error('Kullanım şartlarını kabul etmeniz gerekir.');
      setIsLoading(false);
      return;
    }

    try {
      // Kayıt API'sine istek gönder
      const response = await fetch('/api/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Kayıt işlemi başarısız');
      }

      toast.success('Hesap oluşturuldu! Başarıyla kayıt oldunuz.');

      // Otomatik giriş yap
      const result = await signIn('credentials', {
        email: formData.email,
        password: formData.password,
        redirect: false,
      });

      if (result?.ok) {
        // Profil tamamlama modalını göster
        setShowProfileModal(true);
      } else {
        router.push('/auth/giris');
      }

    } catch (error: any) {
      toast.error(error.message || 'Bir hata oluştu. Lütfen tekrar deneyin.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleProfileComplete = async () => {
    setIsSavingProfile(true);
    
    try {
      const response = await fetch('/api/user/profile', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          bio: profileCompleteData.bio || null,
          dateOfBirth: profileCompleteData.dateOfBirth || null,
          gender: profileCompleteData.gender || null,
          showDreamCount: profileCompleteData.showDreamCount,
          showBio: profileCompleteData.showBio,
          showAge: profileCompleteData.showAge,
          showGender: profileCompleteData.showGender,
        }),
      });

      if (!response.ok) throw new Error('Profil güncellenemedi');

      toast.success('Profil bilgileri kaydedildi!');
      setShowProfileModal(false);
      router.replace('/dashboard');
    } catch (error) {
      console.error('Profil güncelleme hatası:', error);
      toast.error('Profil güncellenirken bir hata oluştu');
    } finally {
      setIsSavingProfile(false);
    }
  };

  const handleSkipProfile = () => {
    setShowProfileModal(false);
    router.replace('/dashboard');
  };

  const handleGoogleLogin = () => {
    signIn('google', { callbackUrl: '/dashboard' });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Animated background */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div
          animate={{ 
            scale: [1, 1.2, 1],
            rotate: [0, 180, 360],
          }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          className="absolute top-10 left-10 w-32 h-32 bg-purple-500/10 rounded-full blur-3xl"
        />
        <motion.div
          animate={{ 
            scale: [1.2, 1, 1.2],
            rotate: [360, 180, 0],
          }}
          transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
          className="absolute bottom-10 right-10 w-40 h-40 bg-blue-500/10 rounded-full blur-3xl"
        />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="relative z-10 w-full max-w-md"
      >
        <Card className="bg-white/10 backdrop-blur-md border-white/20">
          <CardHeader className="text-center space-y-4">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
              className="flex justify-center"
            >
              <Moon className="w-12 h-12 text-purple-300" />
            </motion.div>
            <CardTitle className="text-2xl font-bold text-white glow-text">
              Rüya Yolculuğuna Katılın
            </CardTitle>
            <p className="text-purple-200">
              Ücretsiz hesap oluşturun ve rüya dünyanızı keşfetmeye başlayın
            </p>
          </CardHeader>

          <CardContent className="space-y-6">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name" className="text-white">Ad Soyad</Label>
                <div className="relative">
                  <User className="absolute left-3 top-3 h-4 w-4 text-purple-300" />
                  <Input
                    id="name"
                    name="name"
                    type="text"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Adınız ve soyadınız"
                    className="pl-10 bg-white/5 border-white/20 text-white placeholder:text-purple-200"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="username" className="text-white">Kullanıcı Adı</Label>
                <div className="relative">
                  <User className="absolute left-3 top-3 h-4 w-4 text-purple-300" />
                  <Input
                    id="username"
                    name="username"
                    type="text"
                    value={formData.username}
                    onChange={handleChange}
                    placeholder="kullaniciadi"
                    className="pl-10 bg-white/5 border-white/20 text-white placeholder:text-purple-200"
                    required
                  />
                </div>
                <p className="text-xs text-purple-200 mt-1">
                  Diğer kullanıcılar sizi bu adla görecek
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="email" className="text-white">Email</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 h-4 w-4 text-purple-300" />
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="ornek@email.com"
                    className="pl-10 bg-white/5 border-white/20 text-white placeholder:text-purple-200"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-white">Şifre</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-4 w-4 text-purple-300" />
                  <Input
                    id="password"
                    name="password"
                    type={showPassword ? 'text' : 'password'}
                    value={formData.password}
                    onChange={handleChange}
                    placeholder="••••••••"
                    className="pl-10 pr-10 bg-white/5 border-white/20 text-white placeholder:text-purple-200"
                    required
                    minLength={6}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-3 text-purple-300 hover:text-white"
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirmPassword" className="text-white">Şifre Tekrar</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-4 w-4 text-purple-300" />
                  <Input
                    id="confirmPassword"
                    name="confirmPassword"
                    type={showConfirmPassword ? 'text' : 'password'}
                    value={formData.confirmPassword}
                    onChange={handleChange}
                    placeholder="••••••••"
                    className="pl-10 pr-10 bg-white/5 border-white/20 text-white placeholder:text-purple-200"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute right-3 top-3 text-purple-300 hover:text-white"
                  >
                    {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="acceptTerms"
                  name="acceptTerms"
                  checked={formData.acceptTerms}
                  onCheckedChange={(checked) => 
                    setFormData(prev => ({ ...prev, acceptTerms: checked as boolean }))
                  }
                  className="border-white/20"
                />
                <Label htmlFor="acceptTerms" className="text-sm text-purple-200">
                  Kullanım şartlarını ve gizlilik politikasını kabul ediyorum
                </Label>
              </div>

              <Button 
                type="submit" 
                className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                disabled={isLoading}
              >
                {isLoading ? 'Hesap oluşturuluyor...' : 'Hesap Oluştur'}
              </Button>
            </form>

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t border-white/20" />
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="bg-card px-2 text-purple-200">veya</span>
              </div>
            </div>

            <Button
              variant="outline"
              onClick={handleGoogleLogin}
              className="w-full border-white/20 text-white hover:bg-white/10"
            >
              <Chrome className="mr-2 h-4 w-4" />
              Google ile Kayıt Ol
            </Button>

            <div className="text-center text-sm text-purple-200">
              Zaten hesabınız var mı?{' '}
              <Link
                href="/auth/giris"
                className="text-purple-300 hover:text-white underline transition-colors"
              >
                Giriş yapın
              </Link>
            </div>

            <div className="text-center">
              <Link
                href="/"
                className="text-sm text-purple-300 hover:text-white transition-colors"
              >
                ← Ana Sayfaya Dön
              </Link>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Profil Tamamlama Modal */}
      <Dialog open={showProfileModal} onOpenChange={setShowProfileModal}>
        <DialogContent className="sm:max-w-[500px] bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-950 dark:to-pink-950 border-purple-200 dark:border-purple-800">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-2xl">
              <Sparkles className="h-6 w-6 text-purple-600" />
              Profilini Tamamla
            </DialogTitle>
            <DialogDescription className="text-base">
              Son bir adım! Profilini tamamla ve rüya yolculuğuna başla 🌙
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 mt-4">
            <div className="space-y-2">
              <Label htmlFor="modal-bio">Hakkında</Label>
              <Textarea
                id="modal-bio"
                placeholder="Kendinizden kısaca bahsedin..."
                value={profileCompleteData.bio}
                onChange={(e) => setProfileCompleteData({ ...profileCompleteData, bio: e.target.value })}
                rows={3}
                className="resize-none"
              />
              <p className="text-xs text-muted-foreground">
                Bu bilgi profilinizde görünecektir
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="modal-dateOfBirth">Doğum Tarihi</Label>
                <Input
                  id="modal-dateOfBirth"
                  type="date"
                  max={new Date().toISOString().split('T')[0]}
                  value={profileCompleteData.dateOfBirth}
                  onChange={(e) => setProfileCompleteData({ ...profileCompleteData, dateOfBirth: e.target.value })}
                />
                <p className="text-xs text-muted-foreground">
                  Yaşınız otomatik hesaplanacaktır
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="modal-gender">Cinsiyet</Label>
                <select
                  id="modal-gender"
                  value={profileCompleteData.gender}
                  onChange={(e) => setProfileCompleteData({ ...profileCompleteData, gender: e.target.value })}
                  className="w-full px-3 py-2 rounded-md border border-input bg-background"
                >
                  <option value="">Seçiniz</option>
                  <option value="erkek">Erkek</option>
                  <option value="kadin">Kadın</option>
                  <option value="diger">Diğer</option>
                  <option value="belirtmek_istemiyorum">Belirtmek İstemiyorum</option>
                </select>
              </div>
            </div>

            <div className="space-y-3 pt-2">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="modal-showDreamCount"
                  checked={profileCompleteData.showDreamCount}
                  onCheckedChange={(checked) => 
                    setProfileCompleteData({ ...profileCompleteData, showDreamCount: checked as boolean })
                  }
                />
                <Label htmlFor="modal-showDreamCount" className="text-sm font-normal">
                  Rüya sayımı diğer kullanıcılara göster
                </Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="modal-showBio"
                  checked={profileCompleteData.showBio}
                  onCheckedChange={(checked) => 
                    setProfileCompleteData({ ...profileCompleteData, showBio: checked as boolean })
                  }
                />
                <Label htmlFor="modal-showBio" className="text-sm font-normal">
                  Hakkımda bilgisini diğer kullanıcılara göster
                </Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="modal-showAge"
                  checked={profileCompleteData.showAge}
                  onCheckedChange={(checked) => 
                    setProfileCompleteData({ ...profileCompleteData, showAge: checked as boolean })
                  }
                />
                <Label htmlFor="modal-showAge" className="text-sm font-normal">
                  Yaşımı diğer kullanıcılara göster
                </Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="modal-showGender"
                  checked={profileCompleteData.showGender}
                  onCheckedChange={(checked) => 
                    setProfileCompleteData({ ...profileCompleteData, showGender: checked as boolean })
                  }
                />
                <Label htmlFor="modal-showGender" className="text-sm font-normal">
                  Cinsiyetimi diğer kullanıcılara göster
                </Label>
              </div>
            </div>

            <div className="flex gap-3 pt-4">
              <Button
                variant="outline"
                onClick={handleSkipProfile}
                className="flex-1"
                disabled={isSavingProfile}
              >
                Şimdi Değil
              </Button>
              <Button
                onClick={handleProfileComplete}
                className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                disabled={isSavingProfile}
              >
                {isSavingProfile ? 'Kaydediliyor...' : 'Kaydet ve Devam Et'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
