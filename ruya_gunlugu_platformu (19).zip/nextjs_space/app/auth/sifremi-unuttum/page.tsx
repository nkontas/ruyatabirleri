
'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Moon, Mail, ArrowLeft, CheckCircle } from 'lucide-react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import toast from 'react-hot-toast';

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const res = await fetch('/api/auth/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });

      const data = await res.json();

      if (res.ok) {
        setIsSuccess(true);
        toast.success('Şifre sıfırlama bağlantısı email adresinize gönderildi.');
      } else {
        toast.error(data.error || 'Bir hata oluştu.');
      }
    } catch (error) {
      toast.error('Bir hata oluştu. Lütfen tekrar deneyin.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Animated background */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div
          animate={{ 
            scale: [1, 1.2, 1],
            rotate: [0, 180, 360],
          }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          className="absolute top-10 left-10 w-32 h-32 bg-purple-500/10 rounded-full blur-3xl"
        />
        <motion.div
          animate={{ 
            scale: [1.2, 1, 1.2],
            rotate: [360, 180, 0],
          }}
          transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
          className="absolute bottom-10 right-10 w-40 h-40 bg-blue-500/10 rounded-full blur-3xl"
        />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="relative z-10 w-full max-w-md"
      >
        <Card className="bg-white/10 backdrop-blur-md border-white/20">
          <CardHeader className="text-center space-y-4">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
              className="flex justify-center"
            >
              <Moon className="w-12 h-12 text-purple-300" />
            </motion.div>
            <CardTitle className="text-2xl font-bold text-white glow-text">
              Şifremi Unuttum
            </CardTitle>
            <p className="text-purple-200">
              {isSuccess 
                ? 'Email adresinizi kontrol edin' 
                : 'Şifrenizi sıfırlamak için email adresinizi girin'}
            </p>
          </CardHeader>

          <CardContent className="space-y-6">
            {isSuccess ? (
              <div className="space-y-4 text-center">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", duration: 0.6 }}
                  className="flex justify-center"
                >
                  <CheckCircle className="w-16 h-16 text-green-400" />
                </motion.div>
                <p className="text-white">
                  Şifre sıfırlama bağlantısı <strong>{email}</strong> adresine gönderildi.
                </p>
                <p className="text-sm text-purple-200">
                  Lütfen email kutunuzu kontrol edin ve gelen bağlantıya tıklayarak şifrenizi sıfırlayın.
                  Email gelmediyse spam klasörünü kontrol etmeyi unutmayın.
                </p>
                <Button
                  asChild
                  className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                >
                  <Link href="/auth/giris">
                    <ArrowLeft className="mr-2 h-4 w-4" />
                    Giriş Sayfasına Dön
                  </Link>
                </Button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-white">Email Adresiniz</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 h-4 w-4 text-purple-300" />
                    <Input
                      id="email"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="ornek@email.com"
                      className="pl-10 bg-white/5 border-white/20 text-white placeholder:text-purple-200"
                      required
                    />
                  </div>
                  <p className="text-xs text-purple-200">
                    Kayıtlı email adresinize şifre sıfırlama bağlantısı göndereceğiz.
                  </p>
                </div>

                <Button 
                  type="submit" 
                  className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                  disabled={isLoading}
                >
                  {isLoading ? 'Gönderiliyor...' : 'Şifre Sıfırlama Bağlantısı Gönder'}
                </Button>
              </form>
            )}

            <div className="text-center space-y-2">
              <Link
                href="/auth/giris"
                className="text-sm text-purple-300 hover:text-white transition-colors flex items-center justify-center gap-2"
              >
                <ArrowLeft className="h-4 w-4" />
                Giriş Sayfasına Dön
              </Link>
              <div className="text-sm text-purple-200">
                Hesabınız yok mu?{' '}
                <Link
                  href="/auth/kayit-ol"
                  className="text-purple-300 hover:text-white underline transition-colors"
                >
                  Kayıt olun
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
