
'use client';

import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { 
  Moon, 
  Brain, 
  Users, 
  Shield, 
  Sparkles, 
  Heart,
  Eye,
  Lock,
  Zap,
  MessageCircle
} from 'lucide-react';
import Link from 'next/link';
import { motion } from 'framer-motion';

export default function AboutPage() {
  const features = [
    {
      icon: Brain,
      title: 'Yapay Zeka Analizi',
      description: 'Jung, Freud ve İslami yaklaşımlarla rüya yorumu'
    },
    {
      icon: Lock,
      title: 'Gizlilik ve Güvenlik',
      description: 'Verileriniz tamamen gizli ve güvende'
    },
    {
      icon: Users,
      title: 'Topluluk',
      description: 'Rüyalarınızı paylaşın, diğer kullanıcılarla etkileşime geçin'
    },
    {
      icon: MessageCircle,
      title: 'Sesli Kayıt',
      description: 'Rüyalarınızı sesli olarak kaydedin'
    },
    {
      icon: Eye,
      title: 'Görselleştirme',
      description: 'Rüyalarınızı AI ile görselleştirin'
    },
    {
      icon: Zap,
      title: 'Hızlı ve Kolay',
      description: 'Kullanıcı dostu arayüz ile kolay kullanım'
    }
  ];

  const values = [
    {
      icon: Heart,
      title: 'Kullanıcı Odaklı',
      description: 'Her zaman kullanıcı deneyimini ön planda tutuyoruz'
    },
    {
      icon: Shield,
      title: 'Güvenilirlik',
      description: 'Verilerinizin güvenliği bizim önceliğimiz'
    },
    {
      icon: Sparkles,
      title: 'İnovasyon',
      description: 'En son teknolojilerle sürekli gelişiyoruz'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 relative overflow-hidden">
      {/* Animated background */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div
          animate={{ 
            scale: [1, 1.2, 1],
            rotate: [0, 180, 360],
          }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          className="absolute top-10 left-10 w-32 h-32 bg-purple-500/10 rounded-full blur-3xl"
        />
        <motion.div
          animate={{ 
            scale: [1.2, 1, 1.2],
            rotate: [360, 180, 0],
          }}
          transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
          className="absolute bottom-10 right-10 w-40 h-40 bg-blue-500/10 rounded-full blur-3xl"
        />
      </div>

      {/* Navigation */}
      <nav className="relative z-10 p-4 bg-black/20 backdrop-blur-sm border-b border-white/10">
        <div className="container mx-auto flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <Moon className="w-8 h-8 text-purple-300" />
            <span className="text-xl font-bold text-white">Rüya Günlüğü</span>
          </Link>
          <div className="flex gap-4">
            <Link href="/auth/giris">
              <Button variant="ghost" className="text-white hover:text-purple-300">
                Giriş Yap
              </Button>
            </Link>
            <Link href="/auth/kayit-ol">
              <Button className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
                Kayıt Ol
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="relative z-10 container mx-auto px-4 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-6xl mx-auto space-y-12"
        >
          {/* Header */}
          <div className="text-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6 }}
              className="flex justify-center mb-6"
            >
              <Moon className="w-20 h-20 text-purple-300" />
            </motion.div>
            <h1 className="text-4xl md:text-5xl font-bold text-white glow-text mb-4">
              Hakkımızda
            </h1>
            <p className="text-xl text-purple-200 max-w-3xl mx-auto">
              Rüya Günlüğü, rüyalarınızı kaydetmeniz, analiz etmeniz ve anlamlandırmanız için 
              yapay zeka destekli bir platformdur.
            </p>
          </div>

          {/* Mission */}
          <Card className="bg-white/10 backdrop-blur-md border-white/20">
            <CardContent className="pt-6">
              <h2 className="text-2xl font-bold text-white mb-4">Misyonumuz</h2>
              <p className="text-purple-200 leading-relaxed">
                Rüyalar, bilinçaltımızın gizemli dilidir. Her gece yaşadığımız bu deneyimler, 
                içimizdeki duyguları, korkuları ve umutları yansıtır. Rüya Günlüğü olarak, 
                modern teknoloji ile geleneksel rüya yorumu bilgisini birleştirerek, 
                rüyalarınızı daha iyi anlamanıza yardımcı oluyoruz.
              </p>
              <p className="text-purple-200 leading-relaxed mt-4">
                Amacımız, her bireyin rüya dünyasını keşfetmesine, rüyalarından öğrenmesine ve 
                bu sayede kendini daha iyi tanımasına olanak sağlamaktır. Yapay zeka destekli 
                analizlerimiz sayesinde Jung, Freud ve İslami perspektiflerden rüya yorumları 
                sunarak, farklı bakış açılarını bir araya getiriyoruz.
              </p>
            </CardContent>
          </Card>

          {/* Features */}
          <div>
            <h2 className="text-3xl font-bold text-white text-center mb-8">Özelliklerimiz</h2>
            <div className="grid md:grid-cols-3 gap-6">
              {features.map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                >
                  <Card className="bg-white/10 backdrop-blur-md border-white/20 h-full hover:bg-white/20 transition-all">
                    <CardContent className="pt-6">
                      <feature.icon className="w-12 h-12 text-purple-300 mb-4" />
                      <h3 className="text-xl font-semibold text-white mb-2">{feature.title}</h3>
                      <p className="text-purple-200">{feature.description}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Values */}
          <div>
            <h2 className="text-3xl font-bold text-white text-center mb-8">Değerlerimiz</h2>
            <div className="grid md:grid-cols-3 gap-6">
              {values.map((value, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                >
                  <Card className="bg-white/10 backdrop-blur-md border-white/20 h-full">
                    <CardContent className="pt-6 text-center">
                      <value.icon className="w-12 h-12 text-purple-300 mx-auto mb-4" />
                      <h3 className="text-xl font-semibold text-white mb-2">{value.title}</h3>
                      <p className="text-purple-200">{value.description}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Technology */}
          <Card className="bg-white/10 backdrop-blur-md border-white/20">
            <CardContent className="pt-6">
              <h2 className="text-2xl font-bold text-white mb-4">Teknolojimiz</h2>
              <p className="text-purple-200 leading-relaxed mb-4">
                Rüya Günlüğü, OpenAI'nin en son yapay zeka modellerini kullanarak 
                rüyalarınızı analiz eder. Sesli kayıt özelliğimiz sayesinde rüyanızı 
                uyandığınız anda kaydetmeniz mümkün. Whisper teknolojisi ile ses kaydınız 
                otomatik olarak metne dönüştürülür.
              </p>
              <p className="text-purple-200 leading-relaxed">
                Rüya görselleştirme özelliğimiz ise DALL-E ile çalışarak, rüyanızın 
                tanımından etkileyici görseller oluşturur. Böylece rüyanızı sadece kelimelerle 
                değil, görsel olarak da saklamanız mümkün olur.
              </p>
            </CardContent>
          </Card>

          {/* CTA */}
          <Card className="bg-gradient-to-r from-purple-600/20 to-blue-600/20 backdrop-blur-md border-white/20">
            <CardContent className="pt-6 text-center">
              <h2 className="text-2xl font-bold text-white mb-4">
                Rüya Yolculuğunuza Başlayın
              </h2>
              <p className="text-purple-200 mb-6">
                Hemen kayıt olun ve rüyalarınızı keşfetmeye başlayın. Ücretsiz hesabınızla 
                tüm temel özelliklere erişim sağlayabilirsiniz.
              </p>
              <div className="flex gap-4 justify-center">
                <Link href="/auth/kayit-ol">
                  <Button size="lg" className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
                    Ücretsiz Başla
                  </Button>
                </Link>
                <Link href="/iletisim">
                  <Button size="lg" variant="outline" className="border-white/20 text-white hover:bg-white/10">
                    İletişime Geç
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
