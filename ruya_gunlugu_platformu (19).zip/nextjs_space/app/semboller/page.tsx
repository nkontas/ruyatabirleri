
import { prisma } from '@/lib/db';
import SymbolsPage from '@/components/symbols-page';

export default async function SymbolsPublicPage() {
  // Tüm sembolleri kategorilere göre al
  const symbols = await prisma.dreamSymbol.findMany({
    orderBy: [
      { category: 'asc' },
      { symbol: 'asc' }
    ]
  });

  // Kategorilere göre grupla
  const symbolsByCategory = symbols.reduce((acc, symbol) => {
    if (!acc[symbol.category]) {
      acc[symbol.category] = [];
    }
    acc[symbol.category].push(symbol);
    return acc;
  }, {} as Record<string, typeof symbols>);

  return <SymbolsPage symbolsByCategory={symbolsByCategory} />;
}
