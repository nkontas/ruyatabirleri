
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const userId = session.user.id;
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const startOfWeek = new Date(now.setDate(now.getDate() - now.getDay()));

    // Toplam rüya sayısı
    const totalDreams = await prisma.dream.count({
      where: { userId }
    });

    // Bu ay eklenen rüyalar
    const thisMonthDreams = await prisma.dream.count({
      where: {
        userId,
        createdAt: {
          gte: startOfMonth
        }
      }
    });

    // Analiz edilmiş rüyalar
    const analyzedDreams = await prisma.dream.count({
      where: {
        userId,
        analysis: {
          isNot: null
        }
      }
    });

    // AI görseli olan rüyalar
    const generatedImages = await prisma.dreamAnalysis.count({
      where: {
        dream: { userId },
        imageUrl: {
          not: null
        }
      }
    });

    // Ortalama uyku kalitesi
    const sleepQualityResult = await prisma.dream.aggregate({
      where: {
        userId,
        sleepQuality: {
          not: null
        }
      },
      _avg: {
        sleepQuality: true
      }
    });

    const averageSleepQuality = Math.round((sleepQualityResult._avg.sleepQuality || 0) * 10) / 10;

    // Rüya serisi (ardışık günler)
    const recentDreams = await prisma.dream.findMany({
      where: { userId },
      orderBy: { date: 'desc' },
      take: 30,
      select: { date: true }
    });

    let dreamStreak = 0;
    if (recentDreams.length > 0) {
      let currentDate = new Date();
      currentDate.setHours(0, 0, 0, 0);
      
      for (let i = 0; i < recentDreams.length; i++) {
        const dreamDate = new Date(recentDreams[i]?.date);
        dreamDate.setHours(0, 0, 0, 0);
        
        const dayDiff = Math.floor((currentDate.getTime() - dreamDate.getTime()) / (1000 * 60 * 60 * 24));
        
        if (dayDiff === i) {
          dreamStreak++;
        } else {
          break;
        }
      }
    }

    // Keşfedilen semboller
    const symbolsResult = await prisma.dreamAnalysis.findMany({
      where: {
        dream: { userId }
      },
      select: {
        symbols: true
      }
    });

    const allSymbols = symbolsResult.flatMap(analysis => analysis.symbols || []);
    const uniqueSymbols = [...new Set(allSymbols)];
    const totalSymbols = uniqueSymbols.length;

    // Tamamlama oranı (profil bilgileri doluluk oranı)
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        name: true,
        bio: true,
        image: true,
        email: true
      }
    });

    let completionRate = 0;
    if (user) {
      const fields = [user.name, user.bio, user.image, user.email];
      const filledFields = fields.filter(field => field && field.trim() !== '').length;
      completionRate = Math.round((filledFields / fields.length) * 100);
    }

    return NextResponse.json({
      totalDreams,
      thisMonthDreams,
      analyzedDreams,
      generatedImages,
      averageSleepQuality,
      dreamStreak,
      totalSymbols,
      completionRate,
    });

  } catch (error) {
    console.error('Stats API error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
