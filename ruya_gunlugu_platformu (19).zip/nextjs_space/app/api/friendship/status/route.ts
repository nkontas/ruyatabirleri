
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const currentUser = await prisma.user.findUnique({
      where: { email: session.user.email },
    });

    if (!currentUser) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');

    if (!userId) {
      return NextResponse.json({ error: 'User ID is required' }, { status: 400 });
    }

    // Check if they are friends
    const friendship = await prisma.friendship.findFirst({
      where: {
        OR: [
          {
            senderId: currentUser.id,
            receiverId: userId,
            status: 'ACCEPTED',
          },
          {
            senderId: userId,
            receiverId: currentUser.id,
            status: 'ACCEPTED',
          },
        ],
      },
    });

    if (friendship) {
      return NextResponse.json({ status: 'friend' });
    }

    // Check if there's a pending request
    const pendingRequest = await prisma.friendship.findFirst({
      where: {
        OR: [
          {
            senderId: currentUser.id,
            receiverId: userId,
            status: 'PENDING',
          },
          {
            senderId: userId,
            receiverId: currentUser.id,
            status: 'PENDING',
          },
        ],
      },
    });

    if (pendingRequest) {
      if (pendingRequest.senderId === currentUser.id) {
        return NextResponse.json({ status: 'pending_sent' });
      } else {
        return NextResponse.json({ status: 'pending_received' });
      }
    }

    return NextResponse.json({ status: 'none' });
  } catch (error) {
    console.error('Error checking friend status:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
