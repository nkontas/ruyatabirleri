
import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { createNotification } from "@/lib/notifications";

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
      return NextResponse.json(
        { error: "Yetkisiz erişim" },
        { status: 401 }
      );
    }

    const { friendshipId, requestId, action, accept } = await request.json();
    
    const id = friendshipId || requestId;

    if (!id) {
      return NextResponse.json(
        { error: "Eksik parametreler" },
        { status: 400 }
      );
    }

    // action veya accept değerini kullan
    const shouldAccept = accept !== undefined ? accept : action === "accept";

    // Arkadaşlık isteğini kontrol et
    const friendship = await prisma.friendship.findUnique({
      where: { id },
    });

    if (!friendship) {
      return NextResponse.json(
        { error: "Arkadaşlık isteği bulunamadı" },
        { status: 404 }
      );
    }

    if (friendship.receiverId !== session.user.id) {
      return NextResponse.json(
        { error: "Bu isteği yanıtlama yetkiniz yok" },
        { status: 403 }
      );
    }

    if (friendship.status !== "PENDING") {
      return NextResponse.json(
        { error: "Bu istek zaten yanıtlanmış" },
        { status: 400 }
      );
    }

    // İsteği güncelle
    const updatedFriendship = await prisma.friendship.update({
      where: { id },
      data: {
        status: shouldAccept ? "ACCEPTED" : "REJECTED",
      },
      include: {
        sender: {
          select: {
            id: true,
            name: true,
            username: true,
            image: true,
          },
        },
      },
    });

    // Kabul edildiyse gönderene bildirim gönder
    if (shouldAccept) {
      const accepter = await prisma.user.findUnique({
        where: { id: session.user.id },
        select: { name: true, username: true },
      });

      await createNotification({
        userId: friendship.senderId,
        type: 'FRIEND_ACCEPTED',
        title: 'Arkadaşlık isteğiniz kabul edildi',
        message: `${accepter?.name || accepter?.username || 'Birisi'} arkadaşlık isteğinizi kabul etti`,
        link: '/dashboard/friends',
        fromUserId: session.user.id,
      });
    }

    return NextResponse.json({
      message: shouldAccept 
        ? "Arkadaşlık isteği kabul edildi" 
        : "Arkadaşlık isteği reddedildi",
      friendship: updatedFriendship,
    });
  } catch (error) {
    console.error("Arkadaşlık isteği yanıtlama hatası:", error);
    return NextResponse.json(
      { error: "Arkadaşlık isteği yanıtlanırken hata oluştu" },
      { status: 500 }
    );
  }
}
