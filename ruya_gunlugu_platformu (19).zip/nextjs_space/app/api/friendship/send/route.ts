
import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { createNotification } from "@/lib/notifications";

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
      return NextResponse.json(
        { error: "Yetkisiz erişim" },
        { status: 401 }
      );
    }

    const { receiverId } = await request.json();

    if (!receiverId) {
      return NextResponse.json(
        { error: "Alıcı ID gerekli" },
        { status: 400 }
      );
    }

    if (receiverId === session.user.id) {
      return NextResponse.json(
        { error: "Kendinize arkadaşlık isteği gönderemezsiniz" },
        { status: 400 }
      );
    }

    // Kullanıcının var olup olmadığını kontrol et
    const receiver = await prisma.user.findUnique({
      where: { id: receiverId },
    });

    if (!receiver) {
      return NextResponse.json(
        { error: "Kullanıcı bulunamadı" },
        { status: 404 }
      );
    }

    // Var olan arkadaşlık durumunu kontrol et
    const existingFriendship = await prisma.friendship.findFirst({
      where: {
        OR: [
          { senderId: session.user.id, receiverId },
          { senderId: receiverId, receiverId: session.user.id },
        ],
      },
    });

    if (existingFriendship) {
      if (existingFriendship.status === "ACCEPTED") {
        return NextResponse.json(
          { error: "Zaten arkadaşsınız" },
          { status: 400 }
        );
      }
      if (existingFriendship.status === "PENDING") {
        return NextResponse.json(
          { error: "Bekleyen bir arkadaşlık isteği zaten var" },
          { status: 400 }
        );
      }
      // REJECTED ise yeni istek gönderebilir
      await prisma.friendship.delete({
        where: { id: existingFriendship.id },
      });
    }

    // Yeni arkadaşlık isteği oluştur
    const friendship = await prisma.friendship.create({
      data: {
        senderId: session.user.id,
        receiverId,
        status: "PENDING",
      },
      include: {
        receiver: {
          select: {
            id: true,
            name: true,
            username: true,
            image: true,
          },
        },
      },
    });

    // Alıcıya bildirim gönder
    const sender = await prisma.user.findUnique({
      where: { id: session.user.id },
      select: { name: true, username: true },
    });

    await createNotification({
      userId: receiverId,
      type: 'FRIEND_REQUEST',
      title: 'Yeni arkadaşlık isteği',
      message: `${sender?.name || sender?.username || 'Birisi'} size arkadaşlık isteği gönderdi`,
      link: '/dashboard/friends?tab=requests',
      fromUserId: session.user.id,
    });

    return NextResponse.json({
      message: "Arkadaşlık isteği gönderildi",
      friendship,
    });
  } catch (error) {
    console.error("Arkadaşlık isteği gönderme hatası:", error);
    return NextResponse.json(
      { error: "Arkadaşlık isteği gönderilirken hata oluştu" },
      { status: 500 }
    );
  }
}
