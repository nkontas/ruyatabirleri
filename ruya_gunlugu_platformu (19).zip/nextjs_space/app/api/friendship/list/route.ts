
import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
      return NextResponse.json(
        { error: "Yetkisiz erişim" },
        { status: 401 }
      );
    }

    // Tüm arkadaşları getir
    const friendships = await prisma.friendship.findMany({
      where: {
        OR: [
          { senderId: session.user.id, status: "ACCEPTED" },
          { receiverId: session.user.id, status: "ACCEPTED" },
        ],
      },
      include: {
        sender: {
          select: {
            id: true,
            name: true,
            username: true,
            image: true,
            bio: true,
          },
        },
        receiver: {
          select: {
            id: true,
            name: true,
            username: true,
            image: true,
            bio: true,
          },
        },
      },
      orderBy: {
        updatedAt: "desc",
      },
    });

    // Arkadaş listesini düzenle
    const friends = friendships.map((friendship) => {
      const friend =
        friendship.senderId === session.user.id
          ? friendship.receiver
          : friendship.sender;
      return {
        ...friend,
        friendshipId: friendship.id,
        since: friendship.updatedAt,
      };
    });

    return NextResponse.json({ friends });
  } catch (error) {
    console.error("Arkadaş listesi getirme hatası:", error);
    return NextResponse.json(
      { error: "Arkadaş listesi getirilirken hata oluştu" },
      { status: 500 }
    );
  }
}
