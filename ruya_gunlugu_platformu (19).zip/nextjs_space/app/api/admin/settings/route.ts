
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Yetkisiz erişim' }, { status: 401 });
    }

    // Admin kontrolü
    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
      select: { isAdmin: true },
    });

    if (!user?.isAdmin) {
      return NextResponse.json(
        { error: 'Bu işlem için admin yetkisi gerekiyor' },
        { status: 403 }
      );
    }

    // Ayarları getir (yoksa oluştur)
    let settings = await prisma.platformSettings.findFirst();

    if (!settings) {
      settings = await prisma.platformSettings.create({
        data: {},
      });
    }

    return NextResponse.json(settings);
  } catch (error) {
    console.error('Get settings error:', error);
    return NextResponse.json(
      { error: 'Ayarlar alınırken hata oluştu' },
      { status: 500 }
    );
  }
}

export async function PUT(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Yetkisiz erişim' }, { status: 401 });
    }

    // Admin kontrolü
    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
      select: { isAdmin: true },
    });

    if (!user?.isAdmin) {
      return NextResponse.json(
        { error: 'Bu işlem için admin yetkisi gerekiyor' },
        { status: 403 }
      );
    }

    const body = await request.json();
    const {
      siteName,
      siteDescription,
      registrationEnabled,
      communityEnabled,
      aiAnalysisEnabled,
      maintenanceMode,
      maxDreamsPerDay,
      maxAnalysesPerDay,
      welcomeMessage,
      contactEmail,
      contactPhone,
      contactAddress,
      contactWhatsapp,
      socialFacebook,
      socialTwitter,
      socialInstagram,
      socialLinkedin,
      socialYoutube,
      socialTiktok,
      googleClientId,
      googleClientSecret,
      iyzicoApiKey,
      iyzicoSecretKey,
    } = body;

    // Mevcut ayarları bul veya oluştur
    let settings = await prisma.platformSettings.findFirst();

    if (!settings) {
      settings = await prisma.platformSettings.create({
        data: {
          siteName,
          siteDescription,
          registrationEnabled,
          communityEnabled,
          aiAnalysisEnabled,
          maintenanceMode,
          maxDreamsPerDay,
          maxAnalysesPerDay,
          welcomeMessage,
          contactEmail,
          contactPhone,
          contactAddress,
          contactWhatsapp,
          socialFacebook,
          socialTwitter,
          socialInstagram,
          socialLinkedin,
          socialYoutube,
          socialTiktok,
          googleClientId,
          googleClientSecret,
          iyzicoApiKey,
          iyzicoSecretKey,
        },
      });
    } else {
      settings = await prisma.platformSettings.update({
        where: { id: settings.id },
        data: {
          siteName,
          siteDescription,
          registrationEnabled,
          communityEnabled,
          aiAnalysisEnabled,
          maintenanceMode,
          maxDreamsPerDay,
          maxAnalysesPerDay,
          welcomeMessage,
          contactEmail,
          contactPhone,
          contactAddress,
          contactWhatsapp,
          socialFacebook,
          socialTwitter,
          socialInstagram,
          socialLinkedin,
          socialYoutube,
          socialTiktok,
          googleClientId,
          googleClientSecret,
          iyzicoApiKey,
          iyzicoSecretKey,
        },
      });
    }

    return NextResponse.json(settings);
  } catch (error) {
    console.error('Update settings error:', error);
    return NextResponse.json(
      { error: 'Ayarlar güncellenirken hata oluştu' },
      { status: 500 }
    );
  }
}
