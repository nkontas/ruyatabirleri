
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.isAdmin) {
      return NextResponse.json(
        { error: 'Yetkisiz erişim' },
        { status: 403 }
      );
    }

    const body = await request.json();
    const { symbol, meaning, category } = body;

    if (!symbol || !meaning || !category) {
      return NextResponse.json(
        { error: 'Tüm alanlar gereklidir' },
        { status: 400 }
      );
    }

    // Başka bir semboldeki isimle çakışma kontrolü
    const existing = await prisma.dreamSymbol.findFirst({
      where: {
        symbol,
        id: { not: params.id },
      },
    });

    if (existing) {
      return NextResponse.json(
        { error: 'Bu isimde başka bir sembol zaten mevcut' },
        { status: 400 }
      );
    }

    const updatedSymbol = await prisma.dreamSymbol.update({
      where: { id: params.id },
      data: {
        symbol,
        meaning,
        category,
      },
    });

    return NextResponse.json(updatedSymbol);
  } catch (error) {
    console.error('Sembol güncellenirken hata:', error);
    return NextResponse.json(
      { error: 'Sembol güncellenemedi' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.isAdmin) {
      return NextResponse.json(
        { error: 'Yetkisiz erişim' },
        { status: 403 }
      );
    }

    await prisma.dreamSymbol.delete({
      where: { id: params.id },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Sembol silinirken hata:', error);
    return NextResponse.json(
      { error: 'Sembol silinemedi' },
      { status: 500 }
    );
  }
}
