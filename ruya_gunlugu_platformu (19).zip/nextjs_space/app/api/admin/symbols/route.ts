
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.isAdmin) {
      return NextResponse.json(
        { error: 'Yetkisiz erişim' },
        { status: 403 }
      );
    }

    const symbols = await prisma.dreamSymbol.findMany({
      orderBy: [{ category: 'asc' }, { symbol: 'asc' }],
    });

    return NextResponse.json(symbols);
  } catch (error) {
    console.error('Semboller yüklenirken hata:', error);
    return NextResponse.json(
      { error: 'Semboller yüklenemedi' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.isAdmin) {
      return NextResponse.json(
        { error: 'Yetkisiz erişim' },
        { status: 403 }
      );
    }

    const body = await request.json();
    const { symbol, meaning, category } = body;

    if (!symbol || !meaning || !category) {
      return NextResponse.json(
        { error: 'Tüm alanlar gereklidir' },
        { status: 400 }
      );
    }

    // Aynı isimde sembol var mı kontrol et
    const existing = await prisma.dreamSymbol.findUnique({
      where: { symbol },
    });

    if (existing) {
      return NextResponse.json(
        { error: 'Bu sembol zaten mevcut' },
        { status: 400 }
      );
    }

    const newSymbol = await prisma.dreamSymbol.create({
      data: {
        symbol,
        meaning,
        category,
      },
    });

    return NextResponse.json(newSymbol, { status: 201 });
  } catch (error) {
    console.error('Sembol eklenirken hata:', error);
    return NextResponse.json(
      { error: 'Sembol eklenemedi' },
      { status: 500 }
    );
  }
}
