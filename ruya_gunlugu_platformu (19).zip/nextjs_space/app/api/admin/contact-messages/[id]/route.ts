
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';

export async function PATCH(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Yetkisiz erişim' }, { status: 401 });
    }

    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
    });

    if (!user?.isAdmin) {
      return NextResponse.json({ error: 'Admin yetkisi gerekli' }, { status: 403 });
    }

    const body = await request.json();
    const { isRead, isReplied, reply } = body;

    const updateData: any = {};
    if (typeof isRead === 'boolean') {
      updateData.isRead = isRead;
    }
    if (typeof isReplied === 'boolean') {
      updateData.isReplied = isReplied;
    }
    if (reply !== undefined) {
      updateData.reply = reply;
      updateData.repliedAt = new Date();
      updateData.isReplied = true;
    }

    const message = await prisma.contactMessage.update({
      where: { id: params.id },
      data: updateData,
    });

    return NextResponse.json(message);
  } catch (error) {
    console.error('Update contact message error:', error);
    return NextResponse.json(
      { error: 'Mesaj güncellenemedi' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Yetkisiz erişim' }, { status: 401 });
    }

    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
    });

    if (!user?.isAdmin) {
      return NextResponse.json({ error: 'Admin yetkisi gerekli' }, { status: 403 });
    }

    await prisma.contactMessage.delete({
      where: { id: params.id },
    });

    return NextResponse.json({ message: 'Mesaj silindi' });
  } catch (error) {
    console.error('Delete contact message error:', error);
    return NextResponse.json(
      { error: 'Mesaj silinemedi' },
      { status: 500 }
    );
  }
}
