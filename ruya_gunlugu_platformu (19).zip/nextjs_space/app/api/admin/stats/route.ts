
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Yetkisiz erişim' }, { status: 401 });
    }

    // Admin kontrolü
    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
      select: { isAdmin: true },
    });

    if (!user?.isAdmin) {
      return NextResponse.json(
        { error: 'Bu işlem için admin yetkisi gerekiyor' },
        { status: 403 }
      );
    }

    // İstatistikleri topla
    const [
      totalUsers,
      premiumUsers,
      totalDreams,
      totalAnalyses,
      totalSharedDreams,
      totalComments,
      totalLikes,
      todayDreams,
      weekDreams,
      monthDreams,
    ] = await Promise.all([
      // Toplam kullanıcı sayısı
      prisma.user.count(),

      // Premium kullanıcı sayısı
      prisma.user.count({ where: { isPremium: true } }),

      // Toplam rüya sayısı
      prisma.dream.count(),

      // Toplam analiz sayısı
      prisma.dreamAnalysis.count(),

      // Toplam paylaşılan rüya sayısı
      prisma.sharedDream.count({ where: { isActive: true } }),

      // Toplam yorum sayısı
      prisma.comment.count(),

      // Toplam beğeni sayısı
      prisma.dreamLike.count(),

      // Bugünkü rüyalar
      prisma.dream.count({
        where: {
          createdAt: {
            gte: new Date(new Date().setHours(0, 0, 0, 0)),
          },
        },
      }),

      // Son 7 gündeki rüyalar
      prisma.dream.count({
        where: {
          createdAt: {
            gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
          },
        },
      }),

      // Son 30 gündeki rüyalar
      prisma.dream.count({
        where: {
          createdAt: {
            gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
          },
        },
      }),
    ]);

    // En aktif kullanıcılar (en çok rüya ekleyen)
    const topUsers = await prisma.user.findMany({
      where: { dreamCount: { gt: 0 } },
      select: {
        name: true,
        email: true,
        dreamCount: true,
        isPremium: true,
        createdAt: true,
      },
      orderBy: { dreamCount: 'desc' },
      take: 10,
    });

    // Son eklenen rüyalar
    const recentDreams = await prisma.dream.findMany({
      select: {
        id: true,
        title: true,
        dreamType: true,
        createdAt: true,
        user: {
          select: {
            name: true,
            email: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
      take: 10,
    });

    // Rüya türleri dağılımı
    const dreamTypeStats = await prisma.dream.groupBy({
      by: ['dreamType'],
      _count: true,
    });

    // Haftalık aktivite (son 7 gün)
    const weeklyActivity = [];
    for (let i = 6; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      date.setHours(0, 0, 0, 0);
      
      const nextDate = new Date(date);
      nextDate.setDate(nextDate.getDate() + 1);

      const count = await prisma.dream.count({
        where: {
          createdAt: {
            gte: date,
            lt: nextDate,
          },
        },
      });

      weeklyActivity.push({
        date: date.toISOString().split('T')[0],
        count,
      });
    }

    const stats = {
      overview: {
        totalUsers,
        premiumUsers,
        totalDreams,
        totalAnalyses,
        totalSharedDreams,
        totalComments,
        totalLikes,
      },
      activity: {
        todayDreams,
        weekDreams,
        monthDreams,
        weeklyActivity,
      },
      dreamTypes: dreamTypeStats.map((stat: any) => ({
        type: stat.dreamType,
        count: stat._count,
      })),
      topUsers,
      recentDreams,
    };

    return NextResponse.json(stats);
  } catch (error) {
    console.error('Stats error:', error);
    return NextResponse.json(
      { error: 'İstatistikler alınırken hata oluştu' },
      { status: 500 }
    );
  }
}
