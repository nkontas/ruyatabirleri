
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';
import { clearBadWordsCache } from '@/lib/bad-words';

// GET - Tüm kötü kelimeleri getir
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user) {
      return NextResponse.json({ error: 'Oturum açmanız gerekiyor' }, { status: 401 });
    }

    // Admin kontrolü
    const user = await prisma.user.findUnique({
      where: { email: session.user.email! },
      select: { isAdmin: true }
    });

    if (!user?.isAdmin) {
      return NextResponse.json({ error: 'Bu işlem için yetkiniz yok' }, { status: 403 });
    }

    const badWords = await prisma.badWord.findMany({
      orderBy: { createdAt: 'desc' }
    });

    return NextResponse.json(badWords);
  } catch (error) {
    console.error('Kötü kelimeler getirilirken hata:', error);
    return NextResponse.json(
      { error: 'Kötü kelimeler getirilirken bir hata oluştu' },
      { status: 500 }
    );
  }
}

// POST - Yeni kötü kelime ekle
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user) {
      return NextResponse.json({ error: 'Oturum açmanız gerekiyor' }, { status: 401 });
    }

    // Admin kontrolü
    const user = await prisma.user.findUnique({
      where: { email: session.user.email! },
      select: { isAdmin: true }
    });

    if (!user?.isAdmin) {
      return NextResponse.json({ error: 'Bu işlem için yetkiniz yok' }, { status: 403 });
    }

    const body = await request.json();
    const { word, severity = 1 } = body;

    if (!word || typeof word !== 'string') {
      return NextResponse.json({ error: 'Geçerli bir kelime girmelisiniz' }, { status: 400 });
    }

    // Kelime zaten var mı kontrol et
    const existing = await prisma.badWord.findUnique({
      where: { word: word.toLowerCase().trim() }
    });

    if (existing) {
      return NextResponse.json({ error: 'Bu kelime zaten listede' }, { status: 400 });
    }

    const badWord = await prisma.badWord.create({
      data: {
        word: word.toLowerCase().trim(),
        severity: Math.max(1, Math.min(10, severity)) // 1-10 arası
      }
    });

    // Cache'i temizle
    clearBadWordsCache();

    return NextResponse.json(badWord, { status: 201 });
  } catch (error) {
    console.error('Kötü kelime eklenirken hata:', error);
    return NextResponse.json(
      { error: 'Kötü kelime eklenirken bir hata oluştu' },
      { status: 500 }
    );
  }
}

// PUT - Kötü kelime güncelle
export async function PUT(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user) {
      return NextResponse.json({ error: 'Oturum açmanız gerekiyor' }, { status: 401 });
    }

    // Admin kontrolü
    const user = await prisma.user.findUnique({
      where: { email: session.user.email! },
      select: { isAdmin: true }
    });

    if (!user?.isAdmin) {
      return NextResponse.json({ error: 'Bu işlem için yetkiniz yok' }, { status: 403 });
    }

    const body = await request.json();
    const { id, word, severity, isActive } = body;

    if (!id) {
      return NextResponse.json({ error: 'Kelime ID gerekli' }, { status: 400 });
    }

    const updateData: any = {};
    if (word !== undefined) updateData.word = word.toLowerCase().trim();
    if (severity !== undefined) updateData.severity = Math.max(1, Math.min(10, severity));
    if (isActive !== undefined) updateData.isActive = isActive;

    const badWord = await prisma.badWord.update({
      where: { id },
      data: updateData
    });

    // Cache'i temizle
    clearBadWordsCache();

    return NextResponse.json(badWord);
  } catch (error) {
    console.error('Kötü kelime güncellenirken hata:', error);
    return NextResponse.json(
      { error: 'Kötü kelime güncellenirken bir hata oluştu' },
      { status: 500 }
    );
  }
}

// DELETE - Kötü kelime sil
export async function DELETE(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user) {
      return NextResponse.json({ error: 'Oturum açmanız gerekiyor' }, { status: 401 });
    }

    // Admin kontrolü
    const user = await prisma.user.findUnique({
      where: { email: session.user.email! },
      select: { isAdmin: true }
    });

    if (!user?.isAdmin) {
      return NextResponse.json({ error: 'Bu işlem için yetkiniz yok' }, { status: 403 });
    }

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'Kelime ID gerekli' }, { status: 400 });
    }

    await prisma.badWord.delete({
      where: { id }
    });

    // Cache'i temizle
    clearBadWordsCache();

    return NextResponse.json({ message: 'Kötü kelime silindi' });
  } catch (error) {
    console.error('Kötü kelime silinirken hata:', error);
    return NextResponse.json(
      { error: 'Kötü kelime silinirken bir hata oluştu' },
      { status: 500 }
    );
  }
}
