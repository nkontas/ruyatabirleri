
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

// GET - Tüm kullanıcıları getir
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user) {
      return NextResponse.json({ error: 'Oturum açmanız gerekiyor' }, { status: 401 });
    }

    // Admin kontrolü
    const user = await prisma.user.findUnique({
      where: { email: session.user.email! },
      select: { isAdmin: true }
    });

    if (!user?.isAdmin) {
      return NextResponse.json({ error: 'Bu işlem için yetkiniz yok' }, { status: 403 });
    }

    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const search = searchParams.get('search') || '';

    const where: any = {};
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { email: { contains: search, mode: 'insensitive' } },
        { username: { contains: search, mode: 'insensitive' } }
      ];
    }

    const [users, total] = await Promise.all([
      prisma.user.findMany({
        where,
        select: {
          id: true,
          name: true,
          username: true,
          email: true,
          image: true,
          isPremium: true,
          premiumUntil: true,
          isAdmin: true,
          isBlocked: true,
          blockedReason: true,
          blockedAt: true,
          dreamCount: true,
          createdAt: true,
          _count: {
            select: {
              dreams: true,
              comments: true,
              sharedDreams: true
            }
          }
        },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit
      }),
      prisma.user.count({ where })
    ]);

    return NextResponse.json({
      users,
      pagination: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error('Kullanıcılar getirilirken hata:', error);
    return NextResponse.json(
      { error: 'Kullanıcılar getirilirken bir hata oluştu' },
      { status: 500 }
    );
  }
}

// PUT - Kullanıcı güncelle (bloke/bloktan çıkar)
export async function PUT(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user) {
      return NextResponse.json({ error: 'Oturum açmanız gerekiyor' }, { status: 401 });
    }

    // Admin kontrolü
    const adminUser = await prisma.user.findUnique({
      where: { email: session.user.email! },
      select: { isAdmin: true }
    });

    if (!adminUser?.isAdmin) {
      return NextResponse.json({ error: 'Bu işlem için yetkiniz yok' }, { status: 403 });
    }

    const body = await request.json();
    const { userId, action, reason } = body;

    if (!userId || !action) {
      return NextResponse.json({ error: 'Kullanıcı ID ve işlem gerekli' }, { status: 400 });
    }

    const updateData: any = {};

    if (action === 'block') {
      updateData.isBlocked = true;
      updateData.blockedReason = reason || 'Yönetici tarafından engellendi';
      updateData.blockedAt = new Date();
    } else if (action === 'unblock') {
      updateData.isBlocked = false;
      updateData.blockedReason = null;
      updateData.blockedAt = null;
    } else if (action === 'togglePremium') {
      const user = await prisma.user.findUnique({
        where: { id: userId },
        select: { isPremium: true }
      });
      updateData.isPremium = !user?.isPremium;
    } else if (action === 'toggleAdmin') {
      const user = await prisma.user.findUnique({
        where: { id: userId },
        select: { isAdmin: true }
      });
      updateData.isAdmin = !user?.isAdmin;
    }

    const updatedUser = await prisma.user.update({
      where: { id: userId },
      data: updateData,
      select: {
        id: true,
        name: true,
        email: true,
        isBlocked: true,
        blockedReason: true,
        isPremium: true,
        isAdmin: true
      }
    });

    return NextResponse.json(updatedUser);
  } catch (error) {
    console.error('Kullanıcı güncellenirken hata:', error);
    return NextResponse.json(
      { error: 'Kullanıcı güncellenirken bir hata oluştu' },
      { status: 500 }
    );
  }
}

// DELETE - Kullanıcı sil
export async function DELETE(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user) {
      return NextResponse.json({ error: 'Oturum açmanız gerekiyor' }, { status: 401 });
    }

    // Admin kontrolü
    const adminUser = await prisma.user.findUnique({
      where: { email: session.user.email! },
      select: { isAdmin: true, id: true }
    });

    if (!adminUser?.isAdmin) {
      return NextResponse.json({ error: 'Bu işlem için yetkiniz yok' }, { status: 403 });
    }

    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');

    if (!userId) {
      return NextResponse.json({ error: 'Kullanıcı ID gerekli' }, { status: 400 });
    }

    // Kullanıcı kendi kendini silmeye çalışıyor mu?
    if (userId === adminUser.id) {
      return NextResponse.json({ error: 'Kendi hesabınızı silemezsiniz' }, { status: 400 });
    }

    // Kullanıcıyı sil (Cascade ile ilişkili tüm veriler silinecek)
    await prisma.user.delete({
      where: { id: userId }
    });

    return NextResponse.json({ message: 'Kullanıcı başarıyla silindi' });
  } catch (error) {
    console.error('Kullanıcı silinirken hata:', error);
    return NextResponse.json(
      { error: 'Kullanıcı silinirken bir hata oluştu' },
      { status: 500 }
    );
  }
}
