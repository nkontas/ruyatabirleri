
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import crypto from 'crypto';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { email } = body;

    if (!email) {
      return NextResponse.json(
        { error: 'Email adresi gereklidir' },
        { status: 400 }
      );
    }

    // Check if user exists
    const user = await prisma.user.findUnique({
      where: { email },
    });

    // Always return success to prevent email enumeration
    if (!user) {
      return NextResponse.json(
        { message: 'Şifre sıfırlama bağlantısı email adresinize gönderildi.' },
        { status: 200 }
      );
    }

    // Generate reset token
    const resetToken = crypto.randomBytes(32).toString('hex');
    const resetTokenExpiry = new Date(Date.now() + 3600000); // 1 hour

    // Save reset token to database
    await prisma.user.update({
      where: { email },
      data: {
        resetToken,
        resetTokenExpiry,
      },
    });

    // TODO: In production, send email with reset link
    // For now, we'll just log it
    const resetUrl = `${process.env.NEXTAUTH_URL}/auth/sifre-sifirla?token=${resetToken}`;
    console.log('Password reset URL:', resetUrl);

    // In a real application, you would send an email here using a service like SendGrid, AWS SES, etc.
    // Example:
    // await sendEmail({
    //   to: email,
    //   subject: 'Şifre Sıfırlama',
    //   html: `<p>Şifrenizi sıfırlamak için <a href="${resetUrl}">buraya tıklayın</a></p>`
    // });

    return NextResponse.json(
      { message: 'Şifre sıfırlama bağlantısı email adresinize gönderildi.' },
      { status: 200 }
    );
  } catch (error) {
    console.error('Forgot password error:', error);
    return NextResponse.json(
      { error: 'Bir hata oluştu' },
      { status: 500 }
    );
  }
}
