
import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";

// Mesaj gönder
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
      return NextResponse.json(
        { error: "Yetkisiz erişim" },
        { status: 401 }
      );
    }

    const { receiverId, content } = await request.json();

    if (!receiverId || !content?.trim()) {
      return NextResponse.json(
        { error: "Eksik parametreler" },
        { status: 400 }
      );
    }

    // Arkadaş kontrolü
    const friendship = await prisma.friendship.findFirst({
      where: {
        OR: [
          { senderId: session.user.id, receiverId, status: "ACCEPTED" },
          { senderId: receiverId, receiverId: session.user.id, status: "ACCEPTED" },
        ],
      },
    });

    if (!friendship) {
      return NextResponse.json(
        { error: "Sadece arkadaşlarınıza mesaj gönderebilirsiniz" },
        { status: 403 }
      );
    }

    // Mesaj oluştur
    const message = await prisma.message.create({
      data: {
        senderId: session.user.id,
        receiverId,
        content: content.trim(),
      },
      include: {
        sender: {
          select: {
            id: true,
            name: true,
            username: true,
            image: true,
          },
        },
        receiver: {
          select: {
            id: true,
            name: true,
            username: true,
            image: true,
          },
        },
      },
    });

    return NextResponse.json({ message });
  } catch (error) {
    console.error("Mesaj gönderme hatası:", error);
    return NextResponse.json(
      { error: "Mesaj gönderilirken hata oluştu" },
      { status: 500 }
    );
  }
}

// Mesaj listesini getir (konuşma listesi)
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
      return NextResponse.json(
        { error: "Yetkisiz erişim" },
        { status: 401 }
      );
    }

    // Tüm konuşmaları getir
    const messages = await prisma.message.findMany({
      where: {
        OR: [
          { senderId: session.user.id },
          { receiverId: session.user.id },
        ],
      },
      include: {
        sender: {
          select: {
            id: true,
            name: true,
            username: true,
            image: true,
          },
        },
        receiver: {
          select: {
            id: true,
            name: true,
            username: true,
            image: true,
          },
        },
      },
      orderBy: {
        createdAt: "desc",
      },
    });

    // Konuşmaları kullanıcılara göre grupla
    const conversationsMap = new Map();

    messages.forEach((message) => {
      const otherUserId =
        message.senderId === session.user.id
          ? message.receiverId
          : message.senderId;

      if (!conversationsMap.has(otherUserId)) {
        const otherUser =
          message.senderId === session.user.id
            ? message.receiver
            : message.sender;

        conversationsMap.set(otherUserId, {
          user: otherUser,
          lastMessage: message,
          unreadCount: 0,
        });
      }

      // Okunmamış mesaj sayısını hesapla
      if (
        message.receiverId === session.user.id &&
        !message.isRead
      ) {
        const conversation = conversationsMap.get(otherUserId);
        conversation.unreadCount++;
      }
    });

    const conversations = Array.from(conversationsMap.values());

    return NextResponse.json({ conversations });
  } catch (error) {
    console.error("Mesaj listesi getirme hatası:", error);
    return NextResponse.json(
      { error: "Mesaj listesi getirilirken hata oluştu" },
      { status: 500 }
    );
  }
}
