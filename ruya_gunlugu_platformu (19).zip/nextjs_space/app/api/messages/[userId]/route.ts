
import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";

// Belirli bir kullanıcı ile olan mesajları getir
export async function GET(
  request: NextRequest,
  { params }: { params: { userId: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
      return NextResponse.json(
        { error: "Yetkisiz erişim" },
        { status: 401 }
      );
    }

    const otherUserId = params.userId;

    // Arkadaş kontrolü
    const friendship = await prisma.friendship.findFirst({
      where: {
        OR: [
          { senderId: session.user.id, receiverId: otherUserId, status: "ACCEPTED" },
          { senderId: otherUserId, receiverId: session.user.id, status: "ACCEPTED" },
        ],
      },
    });

    if (!friendship) {
      return NextResponse.json(
        { error: "Bu kullanıcı ile mesajlaşma yetkiniz yok" },
        { status: 403 }
      );
    }

    // Mesajları getir
    const messages = await prisma.message.findMany({
      where: {
        OR: [
          { senderId: session.user.id, receiverId: otherUserId },
          { senderId: otherUserId, receiverId: session.user.id },
        ],
      },
      include: {
        sender: {
          select: {
            id: true,
            name: true,
            username: true,
            image: true,
          },
        },
      },
      orderBy: {
        createdAt: "asc",
      },
    });

    // Okunmamış mesajları okundu olarak işaretle
    await prisma.message.updateMany({
      where: {
        senderId: otherUserId,
        receiverId: session.user.id,
        isRead: false,
      },
      data: {
        isRead: true,
      },
    });

    return NextResponse.json({ messages });
  } catch (error) {
    console.error("Mesaj getirme hatası:", error);
    return NextResponse.json(
      { error: "Mesajlar getirilirken hata oluştu" },
      { status: 500 }
    );
  }
}
