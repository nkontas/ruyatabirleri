
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';
import { createNotification } from '@/lib/notifications';

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user) {
      return NextResponse.json(
        { error: 'Oturum açmanız gerekiyor' },
        { status: 401 }
      );
    }

    const sharedDreamId = params.id;

    // Check if shared dream exists
    const sharedDream = await prisma.sharedDream.findUnique({
      where: { id: sharedDreamId },
    });

    if (!sharedDream) {
      return NextResponse.json(
        { error: 'Paylaşılan rüya bulunamadı' },
        { status: 404 }
      );
    }

    // Check if already liked
    const existingLike = await prisma.dreamLike.findUnique({
      where: {
        sharedDreamId_userId: {
          sharedDreamId,
          userId: session.user.id,
        },
      },
    });

    if (existingLike) {
      // Unlike
      await prisma.dreamLike.delete({
        where: { id: existingLike.id },
      });

      return NextResponse.json({
        success: true,
        isLiked: false,
        message: 'Beğeni kaldırıldı',
      });
    } else {
      // Like
      await prisma.dreamLike.create({
        data: {
          sharedDreamId,
          userId: session.user.id,
        },
      });

      // Rüya sahibine bildirim gönder (kendi rüyasını beğenmişse bildirim gönderme)
      if (sharedDream.userId !== session.user.id) {
        const liker = await prisma.user.findUnique({
          where: { id: session.user.id },
          select: { name: true, username: true },
        });

        await createNotification({
          userId: sharedDream.userId,
          type: 'LIKE',
          title: 'Rüyanız beğenildi',
          message: `${liker?.name || liker?.username || 'Birisi'} rüyanızı beğendi`,
          link: `/dashboard/community/${sharedDreamId}`,
          fromUserId: session.user.id,
        });
      }

      return NextResponse.json({
        success: true,
        isLiked: true,
        message: 'Beğenildi',
      });
    }
  } catch (error) {
    console.error('Beğeni işlemi sırasında hata:', error);
    return NextResponse.json(
      { error: 'Beğeni işlemi başarısız' },
      { status: 500 }
    );
  }
}
