
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user) {
      return NextResponse.json(
        { error: 'Oturum açmanız gerekiyor' },
        { status: 401 }
      );
    }

    const sharedDream = await prisma.sharedDream.findUnique({
      where: { id: params.id },
      include: {
        dream: {
          include: {
            analysis: true,
          },
        },
        _count: {
          select: {
            likes: true,
            comments: true,
          },
        },
        likes: {
          where: {
            userId: session.user.id,
          },
          select: {
            id: true,
          },
        },
      },
    });

    if (!sharedDream) {
      return NextResponse.json(
        { error: 'Paylaşılan rüya bulunamadı' },
        { status: 404 }
      );
    }

    const formattedDream = {
      id: sharedDream.id,
      dreamId: sharedDream.dream.id,
      title: sharedDream.dream.title,
      content: sharedDream.dream.content,
      dreamType: sharedDream.dream.dreamType,
      date: sharedDream.dream.date,
      anonymousName: sharedDream.anonymousName,
      shareDate: sharedDream.shareDate,
      likeCount: sharedDream._count.likes,
      commentCount: sharedDream._count.comments,
      isLiked: sharedDream.likes.length > 0,
      analysis: sharedDream.dream.analysis,
    };

    return NextResponse.json(formattedDream);
  } catch (error) {
    console.error('Rüya detayı getirilirken hata:', error);
    return NextResponse.json(
      { error: 'Rüya detayı yüklenemedi' },
      { status: 500 }
    );
  }
}
