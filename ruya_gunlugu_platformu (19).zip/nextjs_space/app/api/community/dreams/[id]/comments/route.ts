
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';
import { createNotification } from '@/lib/notifications';
import { checkBadWords } from '@/lib/bad-words';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user) {
      return NextResponse.json(
        { error: 'Oturum açmanız gerekiyor' },
        { status: 401 }
      );
    }

    const sharedDreamId = params.id;

    const comments = await prisma.comment.findMany({
      where: {
        sharedDreamId,
        isApproved: true,
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            username: true,
            image: true,
          },
        },
      },
      orderBy: {
        createdAt: 'desc',
      },
    });

    return NextResponse.json(comments);
  } catch (error) {
    console.error('Yorumlar getirilirken hata:', error);
    return NextResponse.json(
      { error: 'Yorumlar yüklenemedi' },
      { status: 500 }
    );
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user) {
      return NextResponse.json(
        { error: 'Oturum açmanız gerekiyor' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { content } = body;

    if (!content || content.trim().length === 0) {
      return NextResponse.json(
        { error: 'Yorum içeriği boş olamaz' },
        { status: 400 }
      );
    }

    // Kötü kelime kontrolü
    const badWordCheck = await checkBadWords(content);
    
    if (!badWordCheck.isClean) {
      return NextResponse.json(
        { 
          error: 'Yorumunuz uygunsuz içerik içeriyor. Lütfen daha uygun bir dil kullanın.',
          foundWords: badWordCheck.foundWords,
          filteredText: badWordCheck.filteredText
        },
        { status: 400 }
      );
    }

    const sharedDreamId = params.id;

    // Check if shared dream exists
    const sharedDream = await prisma.sharedDream.findUnique({
      where: { id: sharedDreamId },
    });

    if (!sharedDream) {
      return NextResponse.json(
        { error: 'Paylaşılan rüya bulunamadı' },
        { status: 404 }
      );
    }

    // Kullanıcı bloke edilmiş mi kontrol et
    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      select: { isBlocked: true, blockedReason: true }
    });

    if (user?.isBlocked) {
      return NextResponse.json(
        { error: `Hesabınız engellenmiş: ${user.blockedReason || 'Yönetici tarafından engellendi'}` },
        { status: 403 }
      );
    }

    // Create comment
    const comment = await prisma.comment.create({
      data: {
        sharedDreamId,
        userId: session.user.id,
        content: content.trim(),
        isApproved: true, // Auto-approve for now
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            username: true,
            image: true,
          },
        },
      },
    });

    // Rüya sahibine bildirim gönder (kendi rüyasına yorum yapmışsa bildirim gönderme)
    if (sharedDream.userId !== session.user.id) {
      const commenter = await prisma.user.findUnique({
        where: { id: session.user.id },
        select: { name: true, username: true },
      });

      await createNotification({
        userId: sharedDream.userId,
        type: 'COMMENT',
        title: 'Rüyanıza yorum yapıldı',
        message: `${commenter?.name || commenter?.username || 'Birisi'} rüyanıza yorum yaptı: "${content.substring(0, 50)}${content.length > 50 ? '...' : ''}"`,
        link: `/dashboard/community/${sharedDreamId}`,
        fromUserId: session.user.id,
      });
    }

    return NextResponse.json(comment, { status: 201 });
  } catch (error) {
    console.error('Yorum eklenirken hata:', error);
    return NextResponse.json(
      { error: 'Yorum eklenemedi' },
      { status: 500 }
    );
  }
}
