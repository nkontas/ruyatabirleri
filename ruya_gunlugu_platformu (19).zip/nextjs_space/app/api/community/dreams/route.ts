
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user) {
      return NextResponse.json(
        { error: 'Oturum açmanız gerekiyor' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const filter = searchParams.get('filter') || 'recent';
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '10');
    const skip = (page - 1) * limit;

    let orderBy: any = { shareDate: 'desc' };

    if (filter === 'popular') {
      orderBy = { likes: { _count: 'desc' } };
    } else if (filter === 'commented') {
      orderBy = { comments: { _count: 'desc' } };
    }

    const sharedDreams = await prisma.sharedDream.findMany({
      where: {
        isActive: true,
      },
      include: {
        dream: {
          select: {
            id: true,
            title: true,
            content: true,
            dreamType: true,
            date: true,
          },
        },
        user: {
          select: {
            id: true,
            username: true,
            name: true,
            image: true,
          },
        },
        _count: {
          select: {
            likes: true,
            comments: true,
          },
        },
        likes: {
          where: {
            userId: session.user.id,
          },
          select: {
            id: true,
          },
        },
      },
      orderBy,
      skip,
      take: limit,
    });

    const total = await prisma.sharedDream.count({
      where: { isActive: true },
    });

    const formattedDreams = sharedDreams.map((shared) => ({
      id: shared.id,
      dreamId: shared.dream.id,
      title: shared.dream.title,
      excerpt: shared.dream.content.substring(0, 200) + '...',
      content: shared.dream.content,
      dreamType: shared.dream.dreamType,
      anonymousName: shared.anonymousName,
      user: {
        id: shared.user.id,
        username: shared.user.username,
        name: shared.user.name,
        image: shared.user.image,
      },
      shareDate: shared.shareDate,
      likeCount: shared._count.likes,
      commentCount: shared._count.comments,
      isLiked: shared.likes.length > 0,
    }));

    return NextResponse.json({
      dreams: formattedDreams,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Topluluk rüyaları getirilirken hata:', error);
    return NextResponse.json(
      { error: 'Rüyalar yüklenemedi' },
      { status: 500 }
    );
  }
}
