
import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";

export async function DELETE() {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.email) {
      return NextResponse.json({ error: "Oturum açılmamış" }, { status: 401 });
    }

    // Kullanıcıyı ve ilişkili tüm verileri sil
    await prisma.user.delete({
      where: { email: session.user.email },
    });

    return NextResponse.json({ message: "Hesap başarıyla silindi" });
  } catch (error) {
    console.error("Hesap silme hatası:", error);
    return NextResponse.json(
      { error: "Hesap silinirken bir hata oluştu" },
      { status: 500 }
    );
  }
}
