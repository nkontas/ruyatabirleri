
import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: "Yetkisiz erişim" },
        { status: 401 }
      );
    }

    const userId = params.id;
    const currentUserId = session.user.id;

    // Kullanıcı bilgilerini getir
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        name: true,
        username: true,
        email: true,
        bio: true,
        dateOfBirth: true,
        gender: true,
        image: true,
        dreamCount: true,
        isPremium: true,
        createdAt: true,
        profileVisibility: true,
        showEmail: true,
        showDreamCount: true,
        showBio: true,
        showAge: true,
        showGender: true,
        _count: {
          select: {
            dreams: true,
            sharedDreams: true,
          },
        },
      },
    });

    if (!user) {
      return NextResponse.json(
        { error: "Kullanıcı bulunamadı" },
        { status: 404 }
      );
    }

    // Arkadaşlık durumunu kontrol et
    const friendship = await prisma.friendship.findFirst({
      where: {
        OR: [
          { senderId: currentUserId, receiverId: userId },
          { senderId: userId, receiverId: currentUserId },
        ],
      },
    });

    const isFriend = friendship?.status === "ACCEPTED";
    const friendshipStatus = friendship?.status || null;
    const isSender = friendship?.senderId === currentUserId;

    // Gizlilik kontrolü
    const canViewProfile =
      userId === currentUserId ||
      user.profileVisibility === "public" ||
      (user.profileVisibility === "friends" && isFriend);

    if (!canViewProfile) {
      return NextResponse.json(
        {
          error: "Bu profili görüntüleme yetkiniz yok",
          profileVisibility: user.profileVisibility,
        },
        { status: 403 }
      );
    }

    // Kullanıcı bilgilerini gizlilik ayarlarına göre filtrele
    const profileData = {
      id: user.id,
      name: user.name,
      username: user.username,
      email: user.showEmail || userId === currentUserId ? user.email : null,
      bio: user.showBio || userId === currentUserId ? user.bio : null,
      dateOfBirth: user.showAge || userId === currentUserId ? user.dateOfBirth : null,
      gender: user.showGender || userId === currentUserId ? user.gender : null,
      image: user.image,
      dreamCount: user.showDreamCount || userId === currentUserId 
        ? user._count.dreams 
        : null,
      sharedDreamCount: user._count.sharedDreams,
      isPremium: user.isPremium,
      createdAt: user.createdAt,
      isOwnProfile: userId === currentUserId,
      isFriend,
      friendshipStatus,
      isSender,
      showAge: user.showAge,
      showGender: user.showGender,
    };

    return NextResponse.json(profileData);
  } catch (error) {
    console.error("Profil getirme hatası:", error);
    return NextResponse.json(
      { error: "Profil getirilirken hata oluştu" },
      { status: 500 }
    );
  }
}
