
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

// POST - Kullanıcıyı bloke et
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user) {
      return NextResponse.json({ error: 'Oturum açmanız gerekiyor' }, { status: 401 });
    }

    const currentUser = await prisma.user.findUnique({
      where: { email: session.user.email! },
      select: { id: true }
    });

    if (!currentUser) {
      return NextResponse.json({ error: 'Kullanıcı bulunamadı' }, { status: 404 });
    }

    const body = await request.json();
    const { userId, reason } = body;

    if (!userId) {
      return NextResponse.json({ error: 'Kullanıcı ID gerekli' }, { status: 400 });
    }

    // Kendi kendini bloklayamaz
    if (userId === currentUser.id) {
      return NextResponse.json({ error: 'Kendinizi bloklayamazsınız' }, { status: 400 });
    }

    // Zaten bloke edilmiş mi kontrol et
    const existing = await prisma.userBlock.findUnique({
      where: {
        blockerId_blockedId: {
          blockerId: currentUser.id,
          blockedId: userId
        }
      }
    });

    if (existing) {
      return NextResponse.json({ error: 'Bu kullanıcı zaten bloke edilmiş' }, { status: 400 });
    }

    const block = await prisma.userBlock.create({
      data: {
        blockerId: currentUser.id,
        blockedId: userId,
        reason: reason || null
      }
    });

    return NextResponse.json({ message: 'Kullanıcı bloke edildi', block }, { status: 201 });
  } catch (error) {
    console.error('Kullanıcı bloke edilirken hata:', error);
    return NextResponse.json(
      { error: 'Kullanıcı bloke edilirken bir hata oluştu' },
      { status: 500 }
    );
  }
}

// DELETE - Blokaj kaldır
export async function DELETE(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user) {
      return NextResponse.json({ error: 'Oturum açmanız gerekiyor' }, { status: 401 });
    }

    const currentUser = await prisma.user.findUnique({
      where: { email: session.user.email! },
      select: { id: true }
    });

    if (!currentUser) {
      return NextResponse.json({ error: 'Kullanıcı bulunamadı' }, { status: 404 });
    }

    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');

    if (!userId) {
      return NextResponse.json({ error: 'Kullanıcı ID gerekli' }, { status: 400 });
    }

    await prisma.userBlock.delete({
      where: {
        blockerId_blockedId: {
          blockerId: currentUser.id,
          blockedId: userId
        }
      }
    });

    return NextResponse.json({ message: 'Blokaj kaldırıldı' });
  } catch (error) {
    console.error('Blokaj kaldırılırken hata:', error);
    return NextResponse.json(
      { error: 'Blokaj kaldırılırken bir hata oluştu' },
      { status: 500 }
    );
  }
}

// GET - Bloke ettiğim kullanıcıları listele
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user) {
      return NextResponse.json({ error: 'Oturum açmanız gerekiyor' }, { status: 401 });
    }

    const currentUser = await prisma.user.findUnique({
      where: { email: session.user.email! },
      select: { id: true }
    });

    if (!currentUser) {
      return NextResponse.json({ error: 'Kullanıcı bulunamadı' }, { status: 404 });
    }

    const blocks = await prisma.userBlock.findMany({
      where: { blockerId: currentUser.id },
      include: {
        blocked: {
          select: {
            id: true,
            name: true,
            username: true,
            image: true
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    });

    return NextResponse.json(blocks);
  } catch (error) {
    console.error('Bloke listesi getirilirken hata:', error);
    return NextResponse.json(
      { error: 'Bloke listesi getirilirken bir hata oluştu' },
      { status: 500 }
    );
  }
}
