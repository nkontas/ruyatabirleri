
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';
import { downloadFile, deleteFile, uploadFile } from '@/lib/s3';

// GET - S3'ten signed URL al
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const key = searchParams.get('key');

    if (!key) {
      return NextResponse.json({ error: 'Key parametresi gerekli' }, { status: 400 });
    }

    // S3'ten signed URL al
    const url = await downloadFile(key);

    return NextResponse.json({ url });
  } catch (error) {
    console.error('Resim URL\'si alınırken hata:', error);
    return NextResponse.json(
      { error: 'Resim yüklenirken bir hata oluştu' },
      { status: 500 }
    );
  }
}

// POST - Profil resmi yükle
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.email) {
      return NextResponse.json(
        { error: 'Yetkisiz erişim' },
        { status: 401 }
      );
    }

    const formData = await request.formData();
    const file = formData.get('file') as File;

    if (!file) {
      return NextResponse.json({ error: 'Dosya gerekli' }, { status: 400 });
    }

    // Dosya boyutu kontrolü (5MB)
    const maxSize = 5 * 1024 * 1024;
    if (file.size > maxSize) {
      return NextResponse.json({ error: 'Dosya boyutu en fazla 5MB olabilir' }, { status: 400 });
    }

    // Dosya tipi kontrolü
    if (!file.type.startsWith('image/')) {
      return NextResponse.json({ error: 'Sadece resim dosyaları yüklenebilir' }, { status: 400 });
    }

    // Get current user
    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
      select: { id: true, image: true }
    });

    if (!user) {
      return NextResponse.json({ error: 'Kullanıcı bulunamadı' }, { status: 404 });
    }

    // Delete old image if exists
    if (user.image && user.image.startsWith('6664/')) {
      try {
        await deleteFile(user.image);
      } catch (error) {
        console.error('Eski resim silinirken hata:', error);
      }
    }

    // Upload new image
    const buffer = Buffer.from(await file.arrayBuffer());
    const fileName = `profile-${user.id}-${Date.now()}.jpg`;
    const cloud_storage_path = await uploadFile(buffer, fileName);

    // Update user's image in database
    await prisma.user.update({
      where: { id: user.id },
      data: { image: cloud_storage_path }
    });

    return NextResponse.json({ 
      success: true,
      image: cloud_storage_path,
      message: 'Profil resmi başarıyla yüklendi' 
    });
  } catch (error) {
    console.error('Profil resmi yüklenirken hata:', error);
    return NextResponse.json(
      { error: 'Profil resmi yüklenirken bir hata oluştu' },
      { status: 500 }
    );
  }
}

// DELETE - Profil resmini sil
export async function DELETE(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.email) {
      return NextResponse.json(
        { error: 'Yetkisiz erişim' },
        { status: 401 }
      );
    }

    // Get current user
    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
      select: { id: true, image: true }
    });

    if (!user) {
      return NextResponse.json({ error: 'Kullanıcı bulunamadı' }, { status: 404 });
    }

    // Delete image from S3 if exists
    if (user.image && user.image.startsWith('6664/')) {
      try {
        await deleteFile(user.image);
      } catch (error) {
        console.error('S3 resim silinirken hata:', error);
      }
    }

    // Update user's image in database
    await prisma.user.update({
      where: { id: user.id },
      data: { image: null }
    });

    return NextResponse.json({ 
      success: true,
      message: 'Profil resmi başarıyla silindi' 
    });
  } catch (error) {
    console.error('Profil resmi silinirken hata:', error);
    return NextResponse.json(
      { error: 'Profil resmi silinirken bir hata oluştu' },
      { status: 500 }
    );
  }
}
