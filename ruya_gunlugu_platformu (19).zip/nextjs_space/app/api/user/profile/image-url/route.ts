
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { downloadFile } from '@/lib/s3';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user) {
      return NextResponse.json(
        { error: 'Yetkisiz erişim' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const key = searchParams.get('key');

    if (!key) {
      return NextResponse.json(
        { error: 'Resim anahtarı gerekli' },
        { status: 400 }
      );
    }

    // Generate signed URL
    const url = await downloadFile(key);

    return NextResponse.json({ url });
  } catch (error) {
    console.error('Resim URL oluşturma hatası:', error);
    return NextResponse.json(
      { error: 'Resim URL oluşturulamadı' },
      { status: 500 }
    );
  }
}
