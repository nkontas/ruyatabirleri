
import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/db";

export async function GET() {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.email) {
      return NextResponse.json({ error: "Oturum açılmamış" }, { status: 401 });
    }

    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
      select: {
        id: true,
        name: true,
        email: true,
        bio: true,
        dateOfBirth: true,
        gender: true,
        image: true,
        isPremium: true,
        showDreamCount: true,
        showBio: true,
        showAge: true,
        showGender: true,
        emailNotifications: true,
        dreamReminders: true,
        communityNotifications: true,
        theme: true,
      },
    });

    if (!user) {
      return NextResponse.json({ error: "Kullanıcı bulunamadı" }, { status: 404 });
    }

    return NextResponse.json(user);
  } catch (error) {
    console.error("Ayarlar yükleme hatası:", error);
    return NextResponse.json(
      { error: "Ayarlar yüklenirken bir hata oluştu" },
      { status: 500 }
    );
  }
}

export async function PUT(request: Request) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.email) {
      return NextResponse.json({ error: "Oturum açılmamış" }, { status: 401 });
    }

    const body = await request.json();
    const { emailNotifications, dreamReminders, communityNotifications, theme, showDreamCount, showBio, showAge, showGender } = body;

    const updatedUser = await prisma.user.update({
      where: { email: session.user.email },
      data: {
        emailNotifications: emailNotifications ?? undefined,
        dreamReminders: dreamReminders ?? undefined,
        communityNotifications: communityNotifications ?? undefined,
        theme: theme ?? undefined,
        showDreamCount: showDreamCount ?? undefined,
        showBio: showBio ?? undefined,
        showAge: showAge ?? undefined,
        showGender: showGender ?? undefined,
      },
      select: {
        id: true,
        name: true,
        email: true,
        bio: true,
        dateOfBirth: true,
        gender: true,
        image: true,
        isPremium: true,
        showDreamCount: true,
        showBio: true,
        showAge: true,
        showGender: true,
        emailNotifications: true,
        dreamReminders: true,
        communityNotifications: true,
        theme: true,
      },
    });

    return NextResponse.json(updatedUser);
  } catch (error) {
    console.error("Ayarlar güncelleme hatası:", error);
    return NextResponse.json(
      { error: "Ayarlar güncellenirken bir hata oluştu" },
      { status: 500 }
    );
  }
}
