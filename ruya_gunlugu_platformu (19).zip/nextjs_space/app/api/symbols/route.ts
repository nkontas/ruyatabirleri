
import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get("search") || "";
    const category = searchParams.get("category") || "";

    let where: any = {};

    if (search) {
      where = {
        OR: [
          { symbol: { contains: search, mode: "insensitive" } },
          { meaning: { contains: search, mode: "insensitive" } },
        ],
      };
    }

    if (category) {
      where.category = category;
    }

    const symbols = await prisma.dreamSymbol.findMany({
      where,
      orderBy: [{ category: "asc" }, { symbol: "asc" }],
    });

    // Group by category
    const symbolsByCategory = symbols.reduce((acc: any, symbol) => {
      if (!acc[symbol.category]) {
        acc[symbol.category] = [];
      }
      acc[symbol.category].push({
        id: symbol.id,
        symbol: symbol.symbol,
        meaning: symbol.meaning,
        category: symbol.category,
      });
      return acc;
    }, {});

    return NextResponse.json(symbolsByCategory);
  } catch (error) {
    console.error("Semboller getirilirken hata:", error);
    return NextResponse.json(
      { error: "Semboller yüklenirken bir hata oluştu" },
      { status: 500 }
    );
  }
}
