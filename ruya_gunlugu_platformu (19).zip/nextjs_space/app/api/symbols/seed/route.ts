import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { SymbolCategory } from "@prisma/client";

const dreamSymbols = [
  // ANIMALS
  { symbol: "Kedi", meaning: "Bağımsızlık, gizemlilik, dişil enerji. Sezgisel yetenekler ve özgürlük arayışını temsil eder.", category: SymbolCategory.ANIMALS },
  { symbol: "Köpek", meaning: "Sadakat, dostluk, koruma. Güvenilir ilişkiler ve sadık arkadaşlıklar anlamına gelir.", category: SymbolCategory.ANIMALS },
  { symbol: "Kuş", meaning: "Özgürlük, yükseliş, ruhsal uyanış. Hayallerinize ulaşma ve sınırlardan kurtulma arzusunu ifade eder.", category: SymbolCategory.ANIMALS },
  { symbol: "Yılan", meaning: "Dönüşüm, yenilenme, şifa. Bilinçaltındaki korkular veya cinsel enerjiyi sembolize edebilir.", category: SymbolCategory.ANIMALS },
  { symbol: "At", meaning: "Güç, özgürlük, tutku. İçsel gücünüz ve yaşam enerjinizi temsil eder.", category: SymbolCategory.ANIMALS },
  { symbol: "Kelebek", meaning: "Dönüşüm, metamorfoz, yeniden doğuş. Hayatınızdaki büyük değişimleri işaret eder.", category: SymbolCategory.ANIMALS },
  { symbol: "Balık", meaning: "Bilinçaltı, duygular, bolluk. Ruhsal derinlik ve duygusal zenginliği sembolize eder.", category: SymbolCategory.ANIMALS },
  { symbol: "Aslan", meaning: "Cesaret, liderlik, güç. İçinizdeki güçlü yanları ve cesaretinizi temsil eder.", category: SymbolCategory.ANIMALS },
  { symbol: "Kartal", meaning: "Vizyon, yükseliş, güç. Yüksek perspektif ve ruhsal yükseliş anlamına gelir.", category: SymbolCategory.ANIMALS },
  { symbol: "Kurtlar", meaning: "İçgüdü, özgürlük, grup dinamiği. Vahşi doğanız veya aidiyet duygusunu ifade eder.", category: SymbolCategory.ANIMALS },

  // NATURE
  { symbol: "Su", meaning: "Duygular, bilinçaltı, temizlenme. Duygusal durumunuzu ve yaşam akışınızı yansıtır.", category: SymbolCategory.NATURE },
  { symbol: "Ateş", meaning: "Tutku, dönüşüm, enerji. İçsel gücünüzü ve tutkularınızı sembolize eder.", category: SymbolCategory.NATURE },
  { symbol: "Ağaç", meaning: "Büyüme, kökenler, yaşam. Kişisel gelişiminizi ve kökenlerinize bağlılığınızı temsil eder.", category: SymbolCategory.NATURE },
  { symbol: "Dağ", meaning: "Hedefler, engeller, başarı. Karşılaştığınız zorlukları ve ulaşmak istediğiniz zirveleri ifade eder.", category: SymbolCategory.NATURE },
  { symbol: "Deniz", meaning: "Bilinçaltı, duygular, sonsuzluk. Derin duygularınızı ve bilinmeyen yönlerinizi yansıtır.", category: SymbolCategory.NATURE },
  { symbol: "Yağmur", meaning: "Temizlenme, yenilenme, bereket. Duygusal arınma ve yeni başlangıçları sembolize eder.", category: SymbolCategory.NATURE },
  { symbol: "Güneş", meaning: "Aydınlanma, yaşam enerjisi, bilinç. Pozitif enerji ve netlik kazanmayı ifade eder.", category: SymbolCategory.NATURE },
  { symbol: "Ay", meaning: "Bilinçaltı, dişil enerji, döngüler. İçsel dünyanızı ve duygusal döngülerinizi temsil eder.", category: SymbolCategory.NATURE },
  { symbol: "Yıldızlar", meaning: "Rehberlik, umut, amaç. Hayalleriniz ve rehber nitelikteki fikirlerinizi sembolize eder.", category: SymbolCategory.NATURE },
  { symbol: "Orman", meaning: "Bilinmeyen, keşif, doğal içgüdüler. İçsel yolculuğunuzu ve bilinmeyen yönlerinizi ifade eder.", category: SymbolCategory.NATURE },

  // PEOPLE
  { symbol: "Anne", meaning: "Beslenme, koruma, kaynak. İçsel bakım ihtiyacınızı ve dişil enerjinizi temsil eder.", category: SymbolCategory.PEOPLE },
  { symbol: "Baba", meaning: "Otorite, koruma, rehberlik. Eril enerji ve yönlendirme ihtiyacınızı sembolize eder.", category: SymbolCategory.PEOPLE },
  { symbol: "Çocuk", meaning: "Masumiyet, potansiyel, yeni başlangıçlar. İçinizdeki çocuksu yanı ve yeni olasılıkları ifade eder.", category: SymbolCategory.PEOPLE },
  { symbol: "Yaşlı Bilge", meaning: "Bilgelik, deneyim, rehberlik. İçsel bilgeliğinizi ve yaşam deneyimlerinizi temsil eder.", category: SymbolCategory.PEOPLE },
  { symbol: "Sevgili", meaning: "Aşk, birleşme, tamamlanma. Romantik ilişkinizi veya kendinizle bütünleşme arzunuzu sembolize eder.", category: SymbolCategory.PEOPLE },
  { symbol: "Arkadaş", meaning: "Destek, güven, sosyal bağlantı. Sosyal çevrenizi ve destek sistemlerinizi ifade eder.", category: SymbolCategory.PEOPLE },
  { symbol: "Yabancı", meaning: "Bilinmeyen, yeni yönler, keşif. Kendinizin tanımadığınız yanlarını temsil edebilir.", category: SymbolCategory.PEOPLE },
  { symbol: "Düşman", meaning: "Çatışma, gölge yanlar, karşıtlık. İçsel çatışmalarınızı ve bastırdığınız yönlerinizi sembolize eder.", category: SymbolCategory.PEOPLE },

  // OBJECTS
  { symbol: "Ev", meaning: "Benlik, güvenlik, kimlik. Kişiliğinizi ve güvenli alanınızı temsil eder.", category: SymbolCategory.OBJECTS },
  { symbol: "Anahtar", meaning: "Çözüm, fırsat, erişim. Yeni kapılar açma ve çözüm bulma potansiyelinizi ifade eder.", category: SymbolCategory.OBJECTS },
  { symbol: "Kapı", meaning: "Geçiş, fırsat, değişim. Yeni olasılıklara açılma veya kapatma durumunuzu sembolize eder.", category: SymbolCategory.OBJECTS },
  { symbol: "Araba", meaning: "Kontrol, ilerleme, yön. Hayatınızdaki yönünüzü ve kontrolünüzü temsil eder.", category: SymbolCategory.OBJECTS },
  { symbol: "Kitap", meaning: "Bilgi, öğrenme, hikaye. Yaşam hikayenizi ve öğrenme arzunuzu ifade eder.", category: SymbolCategory.OBJECTS },
  { symbol: "Ayna", meaning: "Öz farkındalık, gerçeklik, yansıma. Kendinizi görme ve anlamanızı temsil eder.", category: SymbolCategory.OBJECTS },
  { symbol: "Köprü", meaning: "Geçiş, bağlantı, değişim. İki durum arasında geçiş yapma durumunuzu sembolize eder.", category: SymbolCategory.OBJECTS },
  { symbol: "Merdiven", meaning: "İlerleme, yükseliş, gelişim. Kişisel gelişim yolculuğunuzu ve ilerleyişinizi ifade eder.", category: SymbolCategory.OBJECTS },
  { symbol: "Telefon", meaning: "İletişim, bağlantı, mesaj. İletişim ihtiyacınızı ve önemli mesajları temsil eder.", category: SymbolCategory.OBJECTS },
  { symbol: "Para", meaning: "Değer, güç, kaynak. Kendinize verdiğiniz değeri ve kaynaklarınızı sembolize eder.", category: SymbolCategory.OBJECTS },

  // EMOTIONS
  { symbol: "Korku", meaning: "Kaygı, tehdit, belirsizlik. Karşılaşmadığınız korkularınızı ve endişelerinizi yansıtır.", category: SymbolCategory.EMOTIONS },
  { symbol: "Mutluluk", meaning: "Tatmin, başarı, uyum. İçsel huzurunuzu ve yaşam doyumunuzu ifade eder.", category: SymbolCategory.EMOTIONS },
  { symbol: "Üzüntü", meaning: "Kayıp, yas, dönüşüm. İşlenmemiş duygularınızı ve kayıplarınızı temsil eder.", category: SymbolCategory.EMOTIONS },
  { symbol: "Öfke", meaning: "Bastırılmış duygular, sınır ihlali, güç. Bastırdığınız öfkeyi ve sınırlarınızı sembolize eder.", category: SymbolCategory.EMOTIONS },
  { symbol: "Aşk", meaning: "Bağlantı, birleşme, kabul. Kendinizi ve başkalarını sevme kapasitesi.", category: SymbolCategory.EMOTIONS },

  // ACTIONS
  { symbol: "Uçmak", meaning: "Özgürlük, aşkınlık, yükseliş. Sınırlamalardan kurtulma ve yükselme arzunuzu ifade eder.", category: SymbolCategory.ACTIONS },
  { symbol: "Düşmek", meaning: "Kontrol kaybı, korku, başarısızlık. Güvensizlik ve kontrol kaybı endişelerinizi yansıtır.", category: SymbolCategory.ACTIONS },
  { symbol: "Koşmak", meaning: "Kaçış, hedef, acele. Bir şeyden kaçma veya bir hedefe ulaşma çabanızı temsil eder.", category: SymbolCategory.ACTIONS },
  { symbol: "Yüzmek", meaning: "Duygularla başa çıkma, akış. Duygusal durumlarla başa çıkma yeteneğinizi sembolize eder.", category: SymbolCategory.ACTIONS },
  { symbol: "Ölmek", meaning: "Dönüşüm, son, yeni başlangıç. Yaşamınızdaki büyük değişimleri ve dönüşümleri ifade eder.", category: SymbolCategory.ACTIONS },
  { symbol: "Doğum", meaning: "Yeni başlangıç, yaratıcılık, potansiyel. Yeni projeleri ve olasılıkları temsil eder.", category: SymbolCategory.ACTIONS },
  { symbol: "Arama", meaning: "Keşif, arayış, kayıp. İçsel arayışınızı ve eksik hissettiğiniz şeyleri sembolize eder.", category: SymbolCategory.ACTIONS },
  { symbol: "Kaybetmek", meaning: "Belirsizlik, yön kaybı, kayıp. Yönünüzü bulamama durumunuzu ifade eder.", category: SymbolCategory.ACTIONS },

  // PLACES
  { symbol: "Okul", meaning: "Öğrenme, gelişim, geçmiş. Öğrenim sürecinizi ve geçmiş deneyimlerinizi temsil eder.", category: SymbolCategory.PLACES },
  { symbol: "Hastane", meaning: "Şifa, bakım, iyileşme. İyileşme ihtiyacınızı ve sağlık konularınızı sembolize eder.", category: SymbolCategory.PLACES },
  { symbol: "Kilise/Cami", meaning: "Maneviyat, inanç, kutsal. Manevi arayışınızı ve inançlarınızı ifade eder.", category: SymbolCategory.PLACES },
  { symbol: "Hapishane", meaning: "Kısıtlama, sınırlama, mahkumiyet. Özgürlük eksikliğinizi ve sınırlamalarınızı temsil eder.", category: SymbolCategory.PLACES },
  { symbol: "Mezarlık", meaning: "Son, geçmiş, dönüşüm. Geçmişle yüzleşme ve dönüşüm sürecinizi sembolize eder.", category: SymbolCategory.PLACES },
  { symbol: "Bahçe", meaning: "Büyüme, potansiyel, yetiştirme. Kişisel gelişiminizi ve bakım verme yeteneğinizi ifade eder.", category: SymbolCategory.PLACES },

  // COLORS
  { symbol: "Beyaz", meaning: "Saflık, temizlik, yeni başlangıç. Masumiyet ve temiz bir başlangıcı temsil eder.", category: SymbolCategory.COLORS },
  { symbol: "Siyah", meaning: "Bilinmeyen, gizem, dönüşüm. Bilinçaltınızı ve gölge yönlerinizi sembolize eder.", category: SymbolCategory.COLORS },
  { symbol: "Kırmızı", meaning: "Tutku, enerji, öfke. Güçlü duygularınızı ve yaşam enerjinizi ifade eder.", category: SymbolCategory.COLORS },
  { symbol: "Mavi", meaning: "Huzur, iletişim, sakinlik. İçsel huzurunuzu ve iletişim ihtiyacınızı temsil eder.", category: SymbolCategory.COLORS },
  { symbol: "Yeşil", meaning: "Büyüme, şifa, doğa. Yenilenme ve iyileşme sürecinizi sembolize eder.", category: SymbolCategory.COLORS },
  { symbol: "Sarı", meaning: "Neşe, aydınlanma, zeka. Zihinsel netlik ve mutluluğunuzu ifade eder.", category: SymbolCategory.COLORS },
  { symbol: "Mor", meaning: "Maneviyat, sezgi, dönüşüm. Ruhsal yolculuğunuzu ve sezgilerinizi temsil eder.", category: SymbolCategory.COLORS },

  // NUMBERS
  { symbol: "Bir", meaning: "Başlangıç, birlik, kendilik. Yeni başlangıçları ve bütünlüğü temsil eder.", category: SymbolCategory.NUMBERS },
  { symbol: "İki", meaning: "Denge, ikili, seçim. Karşıtlıkları ve dengeyi sembolize eder.", category: SymbolCategory.NUMBERS },
  { symbol: "Üç", meaning: "Yaratıcılık, bütünlük, üçleme. Tamamlanmayı ve yaratıcılığı ifade eder.", category: SymbolCategory.NUMBERS },
  { symbol: "Dört", meaning: "İstikrar, temel, yapı. Sağlam temelleri ve güvenliği temsil eder.", category: SymbolCategory.NUMBERS },
  { symbol: "Yedi", meaning: "Ruhsal tamamlanma, şans, mistisizm. Manevi bütünlüğü ve şansı sembolize eder.", category: SymbolCategory.NUMBERS },

  // SPIRITUAL
  { symbol: "Melek", meaning: "Koruma, rehberlik, manevi destek. İlahi rehberlik ve korumayı temsil eder.", category: SymbolCategory.SPIRITUAL },
  { symbol: "Işık", meaning: "Aydınlanma, farkındalık, gerçek. Ruhsal aydınlanmayı ve gerçeği sembolize eder.", category: SymbolCategory.SPIRITUAL },
  { symbol: "Altın", meaning: "Değer, dönüşüm, mükemmellik. İçsel değerinizi ve manevi zenginliğinizi ifade eder.", category: SymbolCategory.SPIRITUAL },
  { symbol: "Mandala", meaning: "Bütünlük, merkez, kendini gerçekleştirme. Ruhsal bütünlüğünüzü ve merkezinizi temsil eder.", category: SymbolCategory.SPIRITUAL },
  { symbol: "Kuşatma", meaning: "Koruma, kutsal alan, sınır. Manevi sınırlarınızı ve korumayı sembolize eder.", category: SymbolCategory.SPIRITUAL },
];

export async function POST() {
  try {
    // Check if symbols already exist
    const existingCount = await prisma.dreamSymbol.count();
    
    if (existingCount > 0) {
      return NextResponse.json({ 
        message: "Semboller zaten mevcut", 
        count: existingCount 
      });
    }

    // Create symbols
    const created = await prisma.dreamSymbol.createMany({
      data: dreamSymbols,
      skipDuplicates: true,
    });

    return NextResponse.json({
      message: "Semboller başarıyla eklendi",
      count: created.count,
    });
  } catch (error) {
    console.error("Sembol ekleme hatası:", error);
    return NextResponse.json(
      { error: "Semboller eklenirken bir hata oluştu" },
      { status: 500 }
    );
  }
}
