import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const dream = await prisma.dream.findUnique({
      where: { id: params.id },
      include: {
        analysis: true,
        sharedDream: {
          select: {
            id: true,
            isActive: true,
          },
        },
      },
    });

    if (!dream) {
      return NextResponse.json({ error: 'Dream not found' }, { status: 404 });
    }

    // Allow access if it's the user's own dream OR if it's a shared dream
    const isOwnDream = dream.userId === session.user.id;
    const isSharedDream = dream.sharedDream && dream.sharedDream.isActive;
    
    if (!isOwnDream && !isSharedDream) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Görüntülenme sayısını artır
    await prisma.dream.update({
      where: { id: params.id },
      data: {
        viewCount: {
          increment: 1,
        },
      },
    });

    return NextResponse.json(dream);
  } catch (error) {
    console.error('Dream fetch error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const dream = await prisma.dream.findUnique({
      where: { id: params.id },
    });

    if (!dream) {
      return NextResponse.json({ error: 'Dream not found' }, { status: 404 });
    }

    if (dream.userId !== session.user.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Delete analysis first (if exists)
    await prisma.dreamAnalysis.deleteMany({
      where: { dreamId: params.id },
    });

    // Delete dream
    await prisma.dream.delete({
      where: { id: params.id },
    });

    // Update user dream count
    await prisma.user.update({
      where: { id: session.user.id },
      data: {
        dreamCount: {
          decrement: 1,
        },
      },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Dream delete error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
