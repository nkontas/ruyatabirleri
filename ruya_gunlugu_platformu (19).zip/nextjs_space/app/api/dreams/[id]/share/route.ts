
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const dreamId = params.id;

    // Verify dream belongs to user
    const dream = await prisma.dream.findFirst({
      where: {
        id: dreamId,
        userId: session.user.id,
      },
    });

    if (!dream) {
      return NextResponse.json({ error: 'Dream not found' }, { status: 404 });
    }

    // Check if already shared
    const existingShare = await prisma.sharedDream.findFirst({
      where: {
        dreamId: dreamId,
      },
    });

    if (existingShare) {
      return NextResponse.json(
        { error: 'Bu rüya zaten paylaşılmış' },
        { status: 400 }
      );
    }

    // Generate anonymous name
    const adjectives = [
      'Gizemli',
      'Rüyacı',
      'Derin',
      'Sessiz',
      'Parlak',
      'Gizli',
      'Karanlık',
      'Aydınlık',
      'Mistik',
    ];
    const nouns = [
      'Kaşif',
      'Gezgin',
      'Düşünür',
      'Gözlemci',
      'Bilge',
      'Arayan',
      'Yolcu',
      'Ruh',
    ];
    const randomAdjective =
      adjectives[Math.floor(Math.random() * adjectives.length)];
    const randomNoun = nouns[Math.floor(Math.random() * nouns.length)];
    const anonymousName = `${randomAdjective} ${randomNoun}`;

    // Share to community
    const sharedDream = await prisma.sharedDream.create({
      data: {
        dreamId: dream.id,
        userId: session.user.id,
        anonymousName: anonymousName,
      },
    });

    return NextResponse.json(sharedDream);
  } catch (error) {
    console.error('Share dream error:', error);
    return NextResponse.json(
      { error: 'Failed to share dream' },
      { status: 500 }
    );
  }
}
