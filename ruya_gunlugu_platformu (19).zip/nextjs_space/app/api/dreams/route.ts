
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const limit = parseInt(searchParams.get('limit') || '10');
    const offset = parseInt(searchParams.get('offset') || '0');

    const dreams = await prisma.dream.findMany({
      where: { userId: session.user.id },
      include: {
        analysis: {
          select: {
            emotions: true,
            symbols: true,
            imageUrl: true,
          }
        }
      },
      orderBy: { createdAt: 'desc' },
      take: limit,
      skip: offset,
    });

    return NextResponse.json(dreams);

  } catch (error) {
    console.error('Dreams API error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const {
      title,
      content,
      date,
      dreamType,
      sleepQuality,
      sleepHours,
      moonPhase,
      audioUrl,
      isAnonymous
    } = body;

    // Validation
    if (!title || !content) {
      return NextResponse.json(
        { error: 'Başlık ve içerik gerekli' },
        { status: 400 }
      );
    }

    // Premium olmayan kullanıcılar için limit kontrolü
    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      select: { isPremium: true, dreamCount: true }
    });

    if (!user?.isPremium) {
      const now = new Date();
      const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      
      const monthlyDreamCount = await prisma.dream.count({
        where: {
          userId: session.user.id,
          createdAt: {
            gte: startOfMonth
          }
        }
      });

      if (monthlyDreamCount >= 10) {
        return NextResponse.json(
          { error: 'Aylık rüya limite ulaştınız. Premium hesaba yükseltin.' },
          { status: 403 }
        );
      }
    }

    // Rüya oluştur
    const dream = await prisma.dream.create({
      data: {
        userId: session.user.id,
        title,
        content,
        date: new Date(date),
        dreamType: dreamType || 'NORMAL',
        sleepQuality: sleepQuality ? parseInt(sleepQuality) : null,
        sleepHours: sleepHours ? parseFloat(sleepHours) : null,
        moonPhase: moonPhase || null,
        audioUrl: audioUrl || null,
        isAnonymous: isAnonymous || false,
      },
      include: {
        analysis: true
      }
    });

    // Kullanıcının rüya sayısını güncelle
    await prisma.user.update({
      where: { id: session.user.id },
      data: {
        dreamCount: {
          increment: 1
        }
      }
    });

    return NextResponse.json(dream, { status: 201 });

  } catch (error) {
    console.error('Dream creation error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
