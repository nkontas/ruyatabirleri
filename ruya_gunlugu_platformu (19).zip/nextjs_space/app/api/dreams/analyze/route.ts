import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';
import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { content, dreamId } = await request.json();

    if (!content) {
      return NextResponse.json({ error: 'Rüya içeriği gerekli' }, { status: 400 });
    }

    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
    });

    if (!user) {
      return NextResponse.json({ error: 'Kullanıcı bulunamadı' }, { status: 404 });
    }

    // AI Analysis with GPT
    const analysisPrompt = `
Sen bir rüya analizi uzmanısın. Aşağıdaki rüyayı analiz et ve şunları çıkar:

1. Rüyadaki ana semboller (en az 5 sembol)
2. Duygusal tonlar (örn: korku, mutluluk, endişe, heyecan)
3. Tekrarlayan temalar veya karakterler
4. Jung'un analitik psikoloji teorisine göre yorum
5. Freud'un psikanaliz teorisine göre yorum
6. İslami rüya yorumu (İbn-i Sirin ve klasik İslami kaynaklar referans alınarak)
7. Genel kişisel anlam ve öneriler

Rüya:
${content}

Lütfen JSON formatında yanıt ver:
{
  "symbols": ["sembol1", "sembol2", ...],
  "emotions": ["duygu1", "duygu2", ...],
  "themes": ["tema1", "tema2", ...],
  "characters": ["karakter1", "karakter2", ...],
  "jungInterpretation": "Jung yorumu buraya",
  "freudInterpretation": "Freud yorumu buraya",
  "islamicInterpretation": "İslami yorum buraya (İbn-i Sirin ve klasik kaynaklar referans alınarak)",
  "personalInsights": "Kişisel öneriler buraya",
  "overallMeaning": "Genel anlam buraya"
}
`;

    const completion = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        {
          role: 'system',
          content: 'Sen Türkçe konuşan bir rüya analizi uzmanısın. Mistik ve bilimsel yaklaşımları birleştiriyorsun. Yanıtlarını SADECE geçerli JSON formatında ver, başka metin ekleme.',
        },
        {
          role: 'user',
          content: analysisPrompt,
        },
      ],
      temperature: 0.7,
    });

    let analysisResult;
    try {
      const content = completion.choices[0].message.content || '{}';
      // Extract JSON from markdown code blocks if present
      const jsonMatch = content.match(/```json\s*([\s\S]*?)\s*```/) || content.match(/```\s*([\s\S]*?)\s*```/);
      const jsonString = jsonMatch ? jsonMatch[1] : content;
      analysisResult = JSON.parse(jsonString.trim());
    } catch (parseError) {
      console.error('JSON parse error:', parseError);
      analysisResult = {
        symbols: [],
        emotions: [],
        themes: [],
        characters: [],
        jungInterpretation: 'Analiz sonucu işlenemedi.',
        freudInterpretation: 'Analiz sonucu işlenemedi.',
        islamicInterpretation: 'Analiz sonucu işlenemedi.',
        personalInsights: 'Analiz sonucu işlenemedi.',
        overallMeaning: 'Analiz sonucu işlenemedi.',
      };
    }

    // Generate image with DALL-E
    let imageUrl = null;
    try {
      const imagePrompt = `Create a mystical, artistic, dreamlike illustration representing this dream: ${content.substring(0, 200)}. Style: ethereal, surreal, beautiful colors, mystical atmosphere.`;
      
      const imageResponse = await openai.images.generate({
        model: 'dall-e-3',
        prompt: imagePrompt,
        n: 1,
        size: '1024x1024',
        quality: 'standard',
      });

      imageUrl = imageResponse.data?.[0]?.url || null;
    } catch (imgError) {
      console.error('DALL-E error:', imgError);
      // Continue without image
    }

    // Save or update analysis
    let dream;
    if (dreamId) {
      dream = await prisma.dream.findUnique({
        where: { id: dreamId },
      });
    }

    const analysisData = {
      symbols: analysisResult.symbols || [],
      emotions: analysisResult.emotions || [],
      themes: analysisResult.themes || [],
      characters: analysisResult.characters || [],
      jungInterpretation: analysisResult.jungInterpretation || '',
      freudInterpretation: analysisResult.freudInterpretation || '',
      islamicInterpretation: analysisResult.islamicInterpretation || '',
      personalInsights: analysisResult.personalInsights || '',
      overallMeaning: analysisResult.overallMeaning || '',
      report: analysisResult.overallMeaning || '',
      imageUrl: imageUrl,
    };

    let analysis;
    if (dream) {
      analysis = await prisma.dreamAnalysis.upsert({
        where: { dreamId: dream.id },
        update: analysisData,
        create: {
          ...analysisData,
          dreamId: dream.id,
        },
      });
    }

    return NextResponse.json({
      success: true,
      dreamId: dream?.id,
      analysis: analysisData,
    });
  } catch (error: any) {
    console.error('Analysis error:', error);
    return NextResponse.json(
      { error: error?.message || 'Analiz başarısız oldu' },
      { status: 500 }
    );
  }
}
