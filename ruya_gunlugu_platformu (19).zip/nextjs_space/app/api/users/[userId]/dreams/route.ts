
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ userId: string }> }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { userId } = await params;

    const currentUser = await prisma.user.findUnique({
      where: { email: session.user.email },
    });

    if (!currentUser) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    // Get shared dreams from the user
    const sharedDreams = await prisma.sharedDream.findMany({
      where: {
        userId: userId,
        isActive: true,
      },
      include: {
        dream: {
          select: {
            id: true,
            title: true,
            content: true,
            dreamType: true,
            createdAt: true,
          },
        },
        _count: {
          select: {
            likes: true,
            comments: true,
          },
        },
        likes: {
          where: {
            userId: currentUser.id,
          },
          select: {
            id: true,
          },
        },
      },
      orderBy: {
        shareDate: 'desc',
      },
    });

    const dreamsWithCounts = sharedDreams.map((sharedDream) => ({
      id: sharedDream.dream.id,
      title: sharedDream.dream.title,
      content: sharedDream.dream.content,
      mood: sharedDream.dream.dreamType,
      isPublic: true,
      createdAt: sharedDream.dream.createdAt,
      likesCount: sharedDream._count.likes,
      commentsCount: sharedDream._count.comments,
      isLiked: sharedDream.likes.length > 0,
    }));

    return NextResponse.json({ dreams: dreamsWithCounts });
  } catch (error) {
    console.error('Error fetching user dreams:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
