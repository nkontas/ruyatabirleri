
import { NextRequest, NextResponse } from 'next/server';
import bcryptjs from 'bcryptjs';
import { prisma } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { 
      email, 
      password, 
      name, 
      username,
      acceptTerms,
      profileVisibility = 'public',
      showEmail = false,
      showDreamCount = true,
      showBio = true,
    } = body;

    if (!email || !password || !name || !username || !acceptTerms) {
      return NextResponse.json(
        { error: 'Tüm alanları doldurunuz ve şartları kabul ediniz.' },
        { status: 400 }
      );
    }

    // Email kontrolü
    const existingUser = await prisma.user.findUnique({
      where: { email },
    });

    if (existingUser) {
      return NextResponse.json(
        { error: 'Bu email adresi zaten kullanılıyor.' },
        { status: 400 }
      );
    }

    // Username kontrolü
    if (username) {
      const existingUsername = await prisma.user.findUnique({
        where: { username },
      });

      if (existingUsername) {
        return NextResponse.json(
          { error: 'Bu kullanıcı adı zaten kullanılıyor.' },
          { status: 400 }
        );
      }
    }

    // Şifre hashleme
    const hashedPassword = await bcryptjs.hash(password, 10);

    // Kullanıcı oluşturma
    const user = await prisma.user.create({
      data: {
        email,
        password: hashedPassword,
        name,
        username,
        isPremium: false,
        dreamCount: 0,
        profileVisibility,
        showEmail,
        showDreamCount,
        showBio,
      },
    });

    return NextResponse.json({
      message: 'Hesap başarıyla oluşturuldu!',
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
      },
    });
  } catch (error) {
    console.error('Signup error:', error);
    return NextResponse.json(
      { error: 'Sunucu hatası. Lütfen tekrar deneyin.' },
      { status: 500 }
    );
  }
}
