
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { redirect } from 'next/navigation';
import HomePage from '@/components/home-page';

export default async function Page() {
  const session = await getServerSession(authOptions);

  // Eğer kullanıcı giriş yapmışsa dashboard'a yönlendir
  if (session) {
    redirect('/dashboard');
  }

  return <HomePage />;
}
