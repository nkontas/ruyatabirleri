import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  const updated = await prisma.user.updateMany({
    where: {
      email: {
        in: ['testkullanici@example.com', 'test@example.com', 'john@doe.com']
      }
    },
    data: {
      isAdmin: true
    }
  });
  
  console.log(`${updated.count} kullanıcı admin yapıldı`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
